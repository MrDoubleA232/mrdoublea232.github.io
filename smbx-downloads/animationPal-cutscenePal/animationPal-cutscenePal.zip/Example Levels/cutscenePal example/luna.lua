--[[


    PLEASE NOTE:

    Documentation for cutscenePal is provided within the cutscenePal file itself.
    Each function has a description of what it does and what arguments it can take.


]]

local animationPal = require("animationPal")
local cutscenePal = require("cutscenePal")

local handycam = require("handycam")
local easing = require("ext/easing")

-- Force the player's state
Player.setCostume(CHARACTER_MARIO,nil,true)
player:transform(CHARACTER_MARIO)
player.powerup = PLAYER_BIG
player.mount = MOUNT_NONE


-- Create and initialise a cutscene
local exampleScene = cutscenePal.newScene("exampleScene")


exampleScene.canSkip = true


local function spawnChuckActor()
    -- Spawn an actor.
    -- It is a "child" of the scene rather than a global one, so it will be removed when the scene ends.
    local actor = exampleScene:spawnChildActor(-199440,-200128)

    -- Set up properties for the actor
    actor.image = Graphics.loadImageResolved("chuck.png")
    actor.spriteOffset = vector(0,2)
    actor.spritePivotOffset = vector(0,-24)
    actor:setFrameSize(60,58) -- each frame is 56x54
    actor:setSize(32,48) -- hitbox size is 32x48

    actor.imageDirection = DIR_LEFT

    actor.useAutoFloor = true
    actor.gravity = 0.26
    actor.terminalVelocity = 8

    -- Set up an actor's animations, using the same arguments as animationPal.createAnimator.
    actor:setUpAnimator{
        animationSet = {
            idle = {1, defaultFrameX = 1},
            turn = {1,2,3,4,5, defaultFrameX = 1,frameDelay = 8,loops = false},

            run = {1,2, defaultFrameX = 2,frameDelay = 4},

            jump = {1, defaultFrameX = 3},
            clap = {2, defaultFrameX = 3},

            baseballPrepare = {1, defaultFrameX = 4},
            baseballThrow = {2, defaultFrameX = 4},
        },
        startAnimation = "idle",
    }

    -- Add it to the scene's data table (which is of course optional) and return.
    exampleScene.data.chuckActor = actor

    return actor
end

local function spawnBaseballActor(x,y)
    -- Spawn an actor.
    -- It is a "child" of the scene rather than a global one, so it will be removed when the scene ends.
    local actor = exampleScene:spawnChildActor(x,y)

    -- Set up properties for the actor
    actor.image = Graphics.loadImageResolved("baseball.png")
    actor:setFrameSize(16,16) -- each frame is 16x16
    actor:setSize(16,16) -- hitbox size is 16x16

    actor.priority = -46

    -- Set up an actor's animations, using the same arguments as animationPal.createAnimator.
    actor:setUpAnimator{
        animationSet = {
            idle = {1,2, frameDelay = 8},
        },
        startAnimation = "idle",
    }

    -- Return it
    return actor
end


function exampleScene:mainRoutineFunc()
    -- This function is where the bulk of the cutscene code goes.
    player.direction = DIR_RIGHT
    player.speedX = 0
    
    Routine.wait(0.25)

    -- Zoom in to a spot just to the right of the player
    handycam[1]:transition{
        ease = handycam.ease(easing.inOutQuad),time = 0.75,
        zoom = 2,xOffset = 64,yOffset = -48,
    }
    cutscenePal.waitUntilTransitionFinished() -- wait until the camera is done moving


    -- Spawn a chuck and have it walk in
    local chuck = spawnChuckActor()

    chuck:walkAndWait{
        goal = -199648,speed = 4,setDirection = true,
        walkAnimation = "run",stopAnimation = "idle",
    }

    Routine.wait(0.1)

    -- Have it talk. This supports both vanilla text boxes and littleDialogue.
    chuck:talkAndWait{
        "Hey! This is an example for cutscenePal, my cutscene library.",
        "I'm an 'actor' object, which is part of cutscenePal, meaning I can do a bunch of stuff.",
        "For instance...",
    }

    chuck:setAnimation("turn")
    chuck:waitUntilAnimationFinished()

    handycam[1]:transition{
        ease = handycam.ease(easing.inOutQuad),time = 0.75,
        targets = {chuck.centre},xOffset = 32,yOffset = -64,
    }

    -- Jump to the right
    chuck:jumpAndWait{
        goalX = -199520,goalY = -200128,setDirection = true,resetSpeed = true,setPosition = true,
        riseAnimation = "jump",landAnimation = "idle",
    }

    Routine.wait(0.1)

    chuck:setAnimation("turn")
    chuck:waitUntilAnimationFinished()
    
    Routine.wait(0.1)


    -- EXAMPLE:
    -- Jump and clap
    chuck.direction = DIR_LEFT

    self:runChildRoutine(function()
        -- This is important! You can run "child routines", which will run alongside the main routine
        -- and will automatically be aborted when the cutscene stops or is skipped.

        -- Clap after a bit
        Routine.wait(0.62)

        chuck:setAnimation("clap")
        chuck.speedY = -5
        SFX.play(91)
    end)

    chuck:jumpAndWait{
        speedX = 0,speedY = -7,
        riseAnimation = "jump",landAnimation = "idle",
    }

    
    -- EXAMPLE:
    -- Throwing a baseball
    Routine.wait(0.25)

    chuck:setAnimation("baseballPrepare")
    Routine.wait(0.2)

    -- Spawn a baseball actor
    local baseball = spawnBaseballActor(chuck.x + chuck.width*0.5 + 24*chuck.direction,chuck.y + chuck.height - 14)

    baseball.speedX = 2.75*chuck.direction

    chuck:setAnimation("baseballThrow")
    SFX.play(25)

    -- Run a child routine to remove the baseball actor eventually
    self:runChildRoutine(function()
        -- Wait until the baseball is off screen
        while ((baseball.x + baseball.width) > camera.x) do
            Routine.skip()
        end

        baseball:remove()
    end)

    -- Make the player duck by forcing their inputs
    self:runChildRoutine(function()
        Routine.wait(0.9)
        self.forcedKeys.down = true

        Routine.wait(0.5)
        self.forcedKeys.down = false
    end)

    Routine.wait(0.75)


    -- Camera move
    handycam[1]:transition{
        ease = handycam.ease(easing.inOutQuad),time = 0.75,
        targets = {player,chuck.centre},xOffset = 0,yOffset = -32,
    }
    cutscenePal.waitUntilTransitionFinished()


    -- EXAMPLE:
    -- Chuck runs into the player and... dies.
    Routine.wait(0.25)

    chuck:setAnimation("idle")
    Routine.wait(0.75)

    -- Run to the left
    chuck:setAnimation("run")
    chuck.direction = DIR_LEFT
    chuck.speedX = 4*chuck.direction

    -- Wait until the Chuck collides with the player
    while (not chuck:makeColliderBox():collide(player)) do
        Routine.skip()
    end

    -- Shake
    Defines.earthquake = 6
    SFX.play(37)

    -- Disable collision and fly off
    chuck:setAnimation("jump")
    chuck.useAutoFloor = false
    chuck.spriteRotationSpeed = 12
    chuck.speedX = 1.5
    chuck.speedY = -6

    Routine.wait(1.5)


    -- Camera returns to default
    handycam[1]:transition{
        ease = handycam.ease(easing.inOutQuad),time = 0.75,
        targets = {},zoom = 1,xOffset = 0,yOffset = 0,
    }
    cutscenePal.waitUntilTransitionFinished()


    -- Once this function ends, the cutscene will end automatically!
end

function exampleScene:stopFunc()
    -- This function is run whenever the cutscene stops, whether it ends naturally or it is skipped.
    handycam[1]:release() -- releases the camera from handycam's control. important if you're using handycam for the cutscene!
end


-- Trigger the cutscene using an event
function onEvent(eventName)
    if eventName == "example cutscene start" then
        exampleScene:start()
    end
end