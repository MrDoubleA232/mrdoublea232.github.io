local playerManager = require("playerManager")

playerManager.overrideCharacterLib(CHARACTER_ULTIMATERINKA,require("steve"))