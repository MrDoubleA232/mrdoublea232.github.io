local funkyBackground = require("funkyBackground")

local respawnRooms = require("respawnRooms")
local textplus = require("textplus")

player.powerup = PLAYER_SMALL


local roomNames = {
    ["beginning"] = "1. First Launch",
    ["claustrophobic"] = "2. Claustrophobic",
    ["swing"] = "3. Swing and a Miss",
    ["collisionAbuse"] = "4. CHAIN STUCK!",
    ["rescue"] = "5. Rescue Mission",
    ["spin"] = "6. Spin!",
    ["clawgrip"] = "7. Trick Shot",
    ["pilotSchool"] = "8. Baby Steps",
    ["flight"] = "9. Difficult Spikes",
    ["finale"] = "10. Snaking",
}


local mainFont = textplus.loadFont("nicefont.ini")

local restartLayout = textplus.layout("[Drop Item] Reset",nil,{font = mainFont,xscale = 2,yscale = 2})
local roomNameLayout


local function getDesiredResolution()
    local room = respawnRooms.currentRoom

    if room == nil then
        return nil
    end

    if room.tagMap["superTall"] then
        return 800,1200
    end

    if room.tagMap["thisWillBeSMBXIn2015"] then
        return 1066,600
    end

    if room.tagMap["snes"] then
        return 512,448
    end

    if room.tagMap["wholeRoom"] then
        return room.width,room.height
    end

    return 800,600
end

local function getRoomName()
    if respawnRooms.currentRoom ~= nil then
        return roomNames[respawnRooms.currentRoom.tagList[1]]
    end
end


local function setResolution()
    local currentWidth,currentHeight = Graphics.getMainFramebufferSize()
    local desiredWidth,desiredHeight = getDesiredResolution()

    if desiredWidth == nil or (currentWidth == desiredWidth and currentHeight == desiredHeight) then
        return
    end

    Graphics.setMainFramebufferSize(desiredWidth,desiredHeight)
    camera.width,camera.height = desiredWidth,desiredHeight
end

local function updateRoomName()
    local roomName = getRoomName()

    if roomName ~= nil then
        roomNameLayout = textplus.layout(roomName,nil,{font = mainFont,xscale = 2,yscale = 2})
    else
        roomNameLayout = nil
    end
end


function onStart()
    setResolution()
    Graphics.activateHud(false)
end


function onDraw()
    if Level.endState() == 0 then
        textplus.render{
            layout = restartLayout,priority = 5,
            x = 16,y = 16,
        }
        
        if roomNameLayout ~= nil then
            textplus.render{
                layout = roomNameLayout,priority = 5,
                x = 16,
                y = 16 + 4 + restartLayout.height,
            }
        end
    end
end

function onTick()
    if player.keys.dropItem == KEYS_PRESSED and not player:isDead() and Level.endState() == 0 and respawnRooms.respawnState == respawnRooms.RESPAWN_STATE.INACTIVE then
        respawnRooms.respawnState = respawnRooms.RESPAWN_STATE.DEATH_ANIM
        respawnRooms.respawnTimer = 0
        respawnRooms.respawnFade = 0

        respawnRooms.respawnPaused = false
    end

    -- Fix for some jank
    if player.section == 5 then
        local bounds = player.sectionObj.boundary

        player.x = math.clamp(player.x,bounds.left + 16,bounds.right - player.width - 16)
    end
end


function respawnRooms.onRoomEnter(room)
    setResolution()
    updateRoomName()
end

function onCameraUpdate()
    camera.width,camera.height = Graphics.getMainFramebufferSize()
end

function onExitLevel()
    Graphics.setMainFramebufferSize(800,600)
end