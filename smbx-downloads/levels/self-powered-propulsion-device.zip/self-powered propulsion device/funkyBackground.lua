local funkyBackground = {}


local iconImage = Graphics.loadImageResolved("background_icons.png")
local iconTypes = 3

local iconColors = {Color.fromHexRGB(0xAF2A80),Color.fromHexRGB(0xFFA800),Color.fromHexRGB(0x6F29AD)}


function funkyBackground.onDraw()
    local fixedRNG = RNG.new(3)

    local iconHeight = iconImage.height/iconTypes

    for ringIndex = 1,8 do
        local ringRadius = (ringIndex - 1)*80 + 64

        local ringRotationSpeed = fixedRNG:random(3,6)/(ringRadius^0.75)

        local maxIcons = math.sqrt(ringRadius)
        local iconCount = fixedRNG:randomInt(math.floor(maxIcons*0.5),maxIcons)

        for iconIndex = 1,iconCount do
            local rotation = (iconIndex - 1 + fixedRNG:random(0,0.5))/iconCount*360 + ringRotationSpeed*lunatime.tick()
            local offset = vector(0,-ringRadius):rotate(rotation)

            Graphics.drawBox{
                texture = iconImage,priority = -99,
                centred = true,

                color = fixedRNG:irandomEntry(iconColors).. 0.75,

                x = camera.width*0.5 + offset.x + fixedRNG:random(-16,16),
                y = camera.height*0.5 + offset.y + fixedRNG:random(-16,16),

                sourceHeight = iconHeight,
                sourceY = fixedRNG:randomInt(0,iconTypes - 1)*iconHeight,
            }
        end
    end

    for _,layer in ipairs(player.sectionObj.background.layers) do
        layer.uniforms.time = lunatime.tick()

        if layer.name == "fuzz" then
            layer.uniforms.perlinTexture = Graphics.sprites.hardcoded["53-1"].img

            --layer.uniforms.lightColor = Color.fromHexRGB(0xAF2A80)
            --layer.uniforms.darkColor = Color.fromHexRGB(0x18022F)
            layer.uniforms.lightColor = Color.fromHexRGB(0x350C27):lerp(Color.black,0.25)
            layer.uniforms.darkColor = Color.fromHexRGB(0x0A0114):lerp(Color.black,0.25)
        end
    end
end


function funkyBackground.onInitAPI()
    registerEvent(funkyBackground,"onDraw")
end


return funkyBackground