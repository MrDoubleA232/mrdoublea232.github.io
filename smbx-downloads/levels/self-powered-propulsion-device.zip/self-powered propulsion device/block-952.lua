local blockManager = require("blockManager")

local npcRemover = {}
local blockID = BLOCK_ID


local npcRemoverSettings = {
	id = blockID,
	
	passthrough = true,
}

blockManager.setBlockSettings(npcRemoverSettings)


function npcRemover.onInitAPI()
	registerEvent(npcRemover,"onTick")
end

function npcRemover.onTick()
	for _,npc in NPC.iterate() do
		if npc.despawnTimer > 0 and Colliders.FILTER_COL_NPC_DEF(npc) then
			local blocks = Colliders.getColliding{a = npc,b = blockID,btype = Colliders.BLOCK}

			if #blocks > 0 then
				npc:kill(HARM_TYPE_SPINJUMP)

				if npc:mem(0x122,FIELD_WORD) > 0 then
					-- Spawn effect
					local e = Effect.spawn(10,npc.x+(npc.width*0.5),npc.y+(npc.height*0.5))

					e.x = e.x - (e.width *0.5)
					e.y = e.y - (e.height*0.5)
				end
			end
		end
	end
end

return npcRemover