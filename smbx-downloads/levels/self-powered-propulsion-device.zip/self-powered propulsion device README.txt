Level name: Self-Powered Propulsion Device
Author: MrDoubleA


Credits:

Music: Dorkus64 - Main Menu (from Mindwave)
Mushroom sprite in background by Starshi


Minor side note: maybe this is stretching the "minimal Lua" rule slightly?
But, seen as the usage here is pretty much just for QOL/aesthetic purposes, I think it's within the spirit of the rule.
Also, the resolution thing is funny.