darknessBM
Made by MrDoubleA

-- HOW TO USE ---

1. Install the .plx file using Magic Patcher.
2. Set an event to run the "darknessBM" script when the level starts.
3. Open the "darknessSetup" script in the script editor.
4. Modify the settings there - there's notes in the script itself.