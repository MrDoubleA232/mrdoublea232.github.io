--[[

	Written by MrDoubleA
	Please give credit!

    Part of MrDoubleA's NPC Pack

]]

local npcManager = require("npcManager")
local npcutils = require("npcs/npcutils")

local ai = require("megaBlargg_ai")


local megaBlargg = {}
local npcID = NPC_ID

local megaBlarggSettings = table.join({
	id = npcID,

	bodyImage = Graphics.loadImageResolved("megaBlargg_body_blue.png"),
	eyesImage = Graphics.loadImageResolved("megaBlargg_eyes.png"),
	toothImage = Graphics.loadImageResolved("megaBlargg_tooth.png"),

	emergeSound = Misc.resolveSoundFile("megaBlargg_emerge"),

	eyeFrames = 3,

	liquidType = ai.LIQUID_TYPE.WATER,
},ai.sharedSettings)

npcManager.setNpcSettings(megaBlarggSettings)
npcManager.registerHarmTypes(npcID,
	{
		HARM_TYPE_NPC,
		HARM_TYPE_SWORD,
	},
	{}
)


ai.register(npcID)


return megaBlargg