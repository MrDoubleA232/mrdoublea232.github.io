--[[

	Written by MrDoubleA
	Please give credit!

    Part of MrDoubleA's NPC Pack

]]

local npcManager = require("npcManager")

local ai = require("yiDoor_ai")


local yiDoor = {}
local npcID = NPC_ID

local yiDoorSettings = table.join({
	id = npcID,
	
	gfxwidth = 128,
	gfxheight = 128,

	gfxoffsetx = 0,
	gfxoffsety = 0,
	
	width = 128,
	height = 128,

	closeEarthquake = 6,
},ai.sharedSettings)

npcManager.setNpcSettings(yiDoorSettings)
npcManager.registerHarmTypes(npcID,{},{})


ai.register(npcID)


return yiDoor