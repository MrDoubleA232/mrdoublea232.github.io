--[[

	Written by MrDoubleA
	Please give credit!

	Graphics made by and requested by FireSeraphim

    Part of MrDoubleA's NPC Pack

]]

local npcManager = require("npcManager")
local npcutils = require("npcs/npcutils")

local lineguide = require("lineguide")

local nid = {}


nid.sharedSettings = {
    gfxwidth = 76,
	gfxheight = 44,

	gfxoffsetx = 0,
	gfxoffsety = 26,
	
	width = 32,
	height = 12,
	
	frames = 8,
	framestyle = 0,
	framespeed = 8,
	
	speed = 1,
	
	npcblock = false,
	npcblocktop = false, --Misnomer, affects whether thrown NPCs bounce off the NPC.
	playerblock = false,
	playerblocktop = false, --Also handles other NPCs walking atop this NPC.

	nohurt = false,
	nogravity = false,
	noblockcollision = false,
	nofireball = true,
	noiceball = true,
	noyoshi = true,
	nowaterphysics = false,
	
	jumphurt = false,
	spinjumpsafe = false,
	harmlessgrab = false,
	harmlessthrown = false,


    platformOffsetX = 0,
    platformOffsetY = 12,

    jumpFrames = 7,
    jumpFrameSpeed = 2,

    jumpSound = Misc.resolveSoundFile("nid_jump"),
}


nid.idList = {}
nid.idMap  = {}

function nid.register(npcID)
	npcManager.registerEvent(npcID, nid, "onTickEndNPC")
    npcManager.registerEvent(npcID, nid, "onDrawNPC")

    table.insert(nid.idList,npcID)
    nid.idMap[npcID] = true
end

nid.platformIDList = {}
nid.platformIDMap = {}

function nid.registerPlatform(npcID)
    table.insert(nid.platformIDList,npcID)
    nid.platformIDMap[npcID] = true
end


local function platformIsValid(v,platformNPC)
    return (platformNPC.isValid and platformNPC.despawnTimer > 0 and platformNPC:mem(0x12C,FIELD_WORD) == 0)
end

local function getPlatformPosition(v,data,config,settings,id)
    local platformConfig = NPC.config[id]

    local x = v.x + v.width*0.5 + config.platformOffsetX*v.direction
    local y = v.y + config.platformOffsetY

    if platformConfig.playerblock or platformConfig.playerblocktop or platformConfig.npcblock then
        x = x + v.speedX
        y = y + v.speedY
    end

    return x,y
end


local function initialise(v,data,config,settings)
    data.initialized = true

    data.jumpCount = 0

    data.animationTimer = 0
    data.jumpTimer = 0
    data.jumpDuration = 0

    v.collisionGroup = "nid ".. v.uid


    if v.ai1 > 0 then
        local platformConfig = NPC.config[v.ai1]

        local x,y = getPlatformPosition(v,data,config,settings,v.ai1)

        local platformWidth = platformConfig.width
        local platformHeight = platformConfig.height

        if nid.platformIDMap[v.ai1] then
            platformWidth = platformWidth*settings.platformWidth
        end

        data.platformNPC = NPC.spawn(v.ai1,x - platformWidth*0.5,y - platformHeight,v.section,false,false)

        data.platformNPC.width = platformWidth
        data.platformNPC.height = platformHeight

        data.platformNPC.spawnWidth = platformWidth
        data.platformNPC.spawnHeight = platformHeight

        data.platformNPC.direction = v.direction
        data.platformNPC.friendly = v.friendly

        data.platformNPC.collisionGroup = v.collisionGroup
    end
end


local function getGravity(v,data,config)
	if config.nogravity then
		return 0
	end

	if v.underwater and not config.nowaterphysics then
		return Defines.npc_grav*0.2
	else
		return Defines.npc_grav
	end
end


local function handleAnimation(v,data,config,settings)
    local jumpFrames = config.jumpFrames
    local idleFrames = config.frames - jumpFrames

    local frame

    if data.jumpDuration > 0 then
        if data.jumpTimer <= data.jumpDuration*0.5 then -- jumping up
            frame = math.min(jumpFrames-1,math.floor(data.jumpTimer/config.jumpFrameSpeed)) + idleFrames
        else -- going down
            frame = math.clamp(math.floor((data.jumpDuration - data.jumpTimer)/config.jumpFrameSpeed),0,jumpFrames-1) + idleFrames
        end

        data.jumpTimer = data.jumpTimer + 1
        data.animationTimer = 0
    else
        frame = math.floor(data.animationTimer / config.framespeed) % idleFrames
        data.animationTimer = data.animationTimer + 1
    end

    v.animationFrame = npcutils.getFrameByFramestyle(v,{frame = frame})
end


function nid.onTickEndNPC(v)
	if Defines.levelFreeze then return end
	
	local data = v.data
	
	if v.despawnTimer <= 0 then
        if data.platformNPC ~= nil and platformIsValid(v,data.platformNPC) then
            data.platformNPC:kill(HARM_TYPE_VANISH)
        end

		data.initialized = false
		return
	end

    local config = NPC.config[v.id]
    local settings = v.data._settings

	if not data.initialized then
		initialise(v,data,config,settings)
	end

	
    if v:mem(0x12C,FIELD_WORD) == 0 and not v:mem(0x136,FIELD_BOOL) and v:mem(0x138,FIELD_WORD) == 0 then
        if config.canJump ~= nil and config.canJump(v,data,config,settings) and settings.jumpHorizontalDistance > 1 then
            -- Turn around
            if settings.jumpsBeforeTurnAround > 0 and data.jumpCount >= settings.jumpsBeforeTurnAround then
                v.direction = -v.direction
                data.jumpCount = 0
            end

            -- Find jump speed
            local diffX = settings.jumpHorizontalDistance*v.direction
            local diffY = -settings.jumpVerticalDistance

            v.speedX = (diffX/32)*settings.jumpSpeedBerBlock

            local t = math.abs(diffX / v.speedX)
            
            if v.underwater and not config.nowaterphysics then
                v.speedX = v.speedX * 2
            end

            v.speedY = diffY/t - getGravity(v,data,config)*t*0.5

            data.jumpTimer = 0
            data.jumpDuration = t

            if v.despawnTimer > 120 then
                SFX.play(config.jumpSound)
            end

            data.jumpCount = data.jumpCount + 1
        elseif v.collidesBlockBottom then
            data.jumpDuration = 0
            v.speedX = 0
            v:mem(0x18,FIELD_FLOAT,0)
        end
    else
        data.jumpDuration = 0
    end

    -- Update the platform NPC
    if data.platformNPC ~= nil and platformIsValid(v,data.platformNPC) then
        local platformConfig = NPC.config[data.platformNPC.id]

        local x,y = getPlatformPosition(v,data,config,settings,data.platformNPC.id)

        x = x - data.platformNPC.width*0.5
        y = y - data.platformNPC.height

        if platformConfig.playerblock or platformConfig.playerblocktop or platformConfig.npcblock then
            data.platformNPC.speedX = x - data.platformNPC.x
            data.platformNPC.speedY = y - data.platformNPC.y

            if platformConfig.speed ~= 0 then
                data.platformNPC.speedX = data.platformNPC.speedX/platformConfig.speed
            end

            data.platformNPC.dontMove = false
        else
            data.platformNPC.x = x
            data.platformNPC.y = y

            data.platformNPC.speedX = 0
            data.platformNPC.speedY = 0

            data.platformNPC.dontMove = true
        end

        data.platformNPC.spawnX = data.platformNPC.x
        data.platformNPC.spawnY = data.platformNPC.y
        data.platformNPC.spawnWidth = data.platformNPC.width
        data.platformNPC.spawnHeight = data.platformNPC.height
        data.platformNPC.spawnSpeedX = data.platformNPC.speedX
        data.platformNPC.spawnSpeedY = data.platformNPC.speedY

        -- Stop attaching to lineguides
        local lineguideData = v.data._basegame.lineguide

        if lineguideData ~= nil then
            lineguideData.state = lineguide.states.NORMAL
            lineguideData.attachCooldown = 2
        end

        data.platformNPC.noblockcollision = true

        data.platformNPC.despawnTimer = math.max(100,data.platformNPC.despawnTimer)
    else
        if data.platformNPC ~= nil and data.platformNPC.isValid then
            data.platformNPC.noblockcollision = false
            data.platformNPC.dontMove = false
        end

        data.platformNPC = nil
    end
	
	handleAnimation(v,data,config,settings)
end


local lowPriorityStates = table.map{1,3,4}

function nid.onDrawNPC(v)
    if v.despawnTimer <= 0 or v.isHidden then return end

    local config = NPC.config[v.id]
    local data = v.data

    local settings = v.data._settings

    if not data.initialized then
		initialise(v,data,config,settings)
	end

    if lowPriorityStates[v:mem(0x138,FIELD_WORD)] or v:mem(0x12C,FIELD_WORD) > 0 or config.foreground then
        return
    end

    npcutils.drawNPC(v,{priority = -44})
    npcutils.hideNPC(v)
end


function nid.onNPCHarm(eventObj,v,reason,culprit)
    if not nid.idMap[v.id] then return end

    local data = v.data

    -- If the platform is close enough to its top, it can't be killed via jumping
    if (reason == HARM_TYPE_JUMP or reason == HARM_TYPE_SPINJUMP) and type(culprit) == "Player" and data.platformNPC ~= nil and platformIsValid(v,data.platformNPC) then
        local distance = v.y - data.platformNPC.y

        if distance > 0 and distance <= 24 then
            eventObj.cancelled = true
        end
    end
end

function nid.onPostNPCKill(v,reason)
    if not nid.idMap[v.id] then return end

    local data = v.data

    -- Kill the platform
    if data.platformNPC ~= nil and platformIsValid(v,data.platformNPC) then
        local e = Effect.spawn(10,data.platformNPC.x + data.platformNPC.width*0.5,data.platformNPC.y + data.platformNPC.height*0.5)

        e.x = e.x - e.width *0.5
        e.y = e.y - e.height*0.5

        data.platformNPC:kill(HARM_TYPE_VANISH)
    end
end


function nid.onInitAPI()
    registerEvent(nid,"onNPCHarm")
    registerEvent(nid,"onPostNPCKill")
end


return nid