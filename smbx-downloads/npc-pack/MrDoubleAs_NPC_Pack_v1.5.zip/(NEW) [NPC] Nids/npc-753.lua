--[[

	Written by MrDoubleA
	Please give credit!

	Graphics made by and requested by FireSeraphim

    Part of MrDoubleA's NPC Pack

]]

local npcManager = require("npcManager")
local npcutils = require("npcs/npcutils")

local ai = require("nid_ai")


local nidPlatform = {}
local npcID = NPC_ID


local nidPlatformSettings = {
	id = npcID,
	
	gfxwidth = 96,
	gfxheight = 32,

	gfxoffsetx = 0,
	gfxoffsety = 0,
	
	width = 32,
	height = 32,
	
	frames = 1,
	framestyle = 0,
	framespeed = 8,

	npcblock = false,
	npcblocktop = true,
	playerblock = false,
	playerblocktop = true,

	nohurt = true,
	nogravity = true,
	noblockcollision = true,
	nofireball = true,
	noiceball = true,
	noyoshi = true,
	nowaterphysics = true,
	
	jumphurt = false,
	spinjumpsafe = false,
	harmlessgrab = true,
	harmlessthrown = true,

	ignorethrownnpcs = true,
	staticdirection = true,
	luahandlesspeed = true,
	nogliding = true,
}

npcManager.setNpcSettings(nidPlatformSettings)
npcManager.registerHarmTypes(npcID,{},{})


ai.registerPlatform(npcID)


function nidPlatform.onInitAPI()
	npcManager.registerEvent(npcID, nidPlatform, "onDrawNPC")
end

function nidPlatform.onDrawNPC(v)
	if v.despawnTimer <= 0 or v.isHidden then return end

	local config = NPC.config[v.id]
	local data = v.data

	local segmentWidth = config.gfxwidth/3
	local segmentCount = math.max(2,math.ceil(v.width/segmentWidth))

	for i = 1,segmentCount do
		local thisOffsetX = -(v.width - config.gfxwidth)*0.5
		local thisSourceX = 0
		local thisWidth = math.min(segmentWidth,v.width*0.5)

		if i == segmentCount then
			thisOffsetX = thisOffsetX + v.width - thisWidth
			thisSourceX = config.gfxwidth - thisWidth
		elseif i > 1 then
			thisOffsetX = thisOffsetX + thisWidth + (i-2)*segmentWidth
			thisSourceX = segmentWidth
			thisWidth = segmentWidth
		end

		npcutils.drawNPC(v,{xOffset = thisOffsetX,sourceX = thisSourceX,width = thisWidth})
	end

	--Colliders.getHitbox(v):Draw()

	npcutils.hideNPC(v)
end


return nidPlatform