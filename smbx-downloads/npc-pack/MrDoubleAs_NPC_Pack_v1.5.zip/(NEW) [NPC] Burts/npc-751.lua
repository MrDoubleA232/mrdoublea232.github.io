--[[

	Written by MrDoubleA
	Please give credit!

    Part of MrDoubleA's NPC Pack

]]

local npcManager = require("npcManager")
local npcutils = require("npcs/npcutils")

local burt = {}
local npcID = NPC_ID

local deathEffectID = (npcID)


local burtSettings = {
	id = npcID,
	
	gfxwidth = 64,
	gfxheight = 68,

	gfxoffsetx = 0,
	gfxoffsety = 8,
	
	width = 40,
	height = 40,
	
	frames = 5,
	framestyle = 1,
	framespeed = 8,
	
	speed = 1,
	
	npcblock = false,
	npcblocktop = true, --Misnomer, affects whether thrown NPCs bounce off the NPC.
	playerblock = false,
	playerblocktop = true, --Also handles other NPCs walking atop this NPC.

	nohurt = false,
	nogravity = false,
	noblockcollision = false,
	nofireball = true,
	noiceball = true,
	noyoshi = true,
	nowaterphysics = false,
	
	jumphurt = false,
	spinjumpsafe = false,
	harmlessgrab = false,
	harmlessthrown = false,


	shoeFrames = 3,
	shoeFramespeed = 4,

	squashAnimationValue = 0.25,
	squashAnimationDuration = 16,

	preJumpSquash = 0.25,

	stoodOnSquash = 0.15,

	preJumpTime = 16,

	jumpSound = Misc.resolveSoundFile("burts_jump"),

	isheavy = true,
}

npcManager.setNpcSettings(burtSettings)
npcManager.registerHarmTypes(npcID,
	{
		HARM_TYPE_FROMBELOW,
		HARM_TYPE_NPC,
		HARM_TYPE_PROJECTILE_USED,
		HARM_TYPE_LAVA,
		HARM_TYPE_HELD,
		HARM_TYPE_TAIL,
		HARM_TYPE_SPINJUMP,
		HARM_TYPE_OFFSCREEN,
		HARM_TYPE_SWORD
	},
	{
		[HARM_TYPE_JUMP]            = deathEffectID,
		[HARM_TYPE_FROMBELOW]       = deathEffectID,
		[HARM_TYPE_NPC]             = deathEffectID,
		[HARM_TYPE_PROJECTILE_USED] = deathEffectID,
		[HARM_TYPE_LAVA]            = {id=13, xoffset=0.5, xoffsetBack = 0, yoffset=1, yoffsetBack = 1.5},
		[HARM_TYPE_HELD]            = deathEffectID,
		[HARM_TYPE_TAIL]            = deathEffectID,
		[HARM_TYPE_SPINJUMP]        = deathEffectID,
	}
)


function burt.onInitAPI()
	npcManager.registerEvent(npcID, burt, "onTickEndNPC")
	npcManager.registerEvent(npcID, burt, "onDrawNPC")
end


local STATE_NORMAL = 0
local STATE_JUMP_ONTO = 1
local STATE_JUMPED_ON = 2
local STATE_LEAP = 3

local BEHAVIOUR_JUMP = 0
local BEHAVIOUR_JUMP_TURN = 1
local BEHAVIOUR_STAND = 2


local function initialise(v,data,config,settings)
	data.initialized = true

	data.state = STATE_NORMAL
	data.timer = 0

	data.burtBeingJumpedOn = nil
	data.burtsJumpingOnto = {}

	data.wasOnGround = v.collidesBlockBottom

	data.bodyFrame = npcutils.getFrameByFramestyle(v,{frame = 1})
	data.shoesFrame = npcutils.getFrameByFramestyle(v,{frame = config.frames - config.shoeFrames})

	data.bodyAnimationTimer = 0
	data.shoesAnimationTimer = 0

	data.squash = 0
	data.squashAnimationTimer = 0
end

local function handleAnimation(v,data,config)
	-- Body
	data.bodyFrame = (math.floor(data.bodyAnimationTimer / config.framespeed) % (config.frames - config.shoeFrames - 1)) + 1
	data.bodyFrame = npcutils.getFrameByFramestyle(v,{frame = data.bodyFrame})

	data.bodyAnimationTimer = data.bodyAnimationTimer + 1

	-- Shoes
	if v.collidesBlockBottom then
		data.shoesAnimationTimer = 0
		data.shoesFrame = 0
	else
		data.shoesFrame = math.min(math.floor(data.shoesAnimationTimer/config.shoeFramespeed) + 1,config.shoeFrames - 1)
		data.shoesAnimationTimer = data.shoesAnimationTimer + 1
	end
	
	data.shoesFrame = npcutils.getFrameByFramestyle(v,{frame = data.shoesFrame + config.frames - config.shoeFrames})
end


local function getGravity(v,data,config)
	if config.nogravity then
		return 0
	end

	if v.underwater and not config.nowaterphysics then
		return Defines.npc_grav*0.2
	else
		return Defines.npc_grav
	end
end

local function jumpTo(v,data,config,targetX,targetY)
	local diffX = targetX - v.x
	local diffY = targetY - v.y

	local speedX = math.clamp(diffX / 32,-6,6)
	
	if math.abs(speedX) > 0.5 then
		local t = math.abs(diffX / speedX)
		if v.underwater and not config.nowaterphysics then
			t = t * 2
		end

		v.speedX = speedX
		v.speedY = diffY/t - getGravity(v,data,config)*t*0.5

		data.squashAnimationTimer = config.squashAnimationDuration
		SFX.play(config.jumpSound)
	end
end


local function isStoodOn(v)
	for _,p in ipairs(Player.get()) do
		if p.standingNPC == v and p.deathTimer == 0 and not p:mem(0x13C,FIELD_BOOL) then
			return true
		end
	end

	return false
end


local function handlePreJumpSquash(v,data,config,settings,timeLeft)
	if timeLeft < settings.preJumpTime*0.5 and settings.preJumpTime > 1 then
		data.squash = math.max(data.squash,(1 - timeLeft/(settings.preJumpTime*0.5))*config.preJumpSquash)
	end
end


local checkingBurt

local function getDistance(a,b)
	return vector((a.x + a.width*0.5) - (b.x + b.width*0.5),(a.y + a.height*0.5) - (b.y + b.height*0.5)).length
end

local function getStandingOnTopCol(v)
	return Colliders.Box(v.x,v.y-1,v.width,2)
end

local function burtFilter(v,aboutTheGuyJumping)
	if not v.isValid or not Colliders.FILTER_COL_NPC_DEF(v) or v.despawnTimer <= 0 or not v.data.initialized then
		return false
	end

	if aboutTheGuyJumping then
		if v.data.state ~= STATE_JUMP_ONTO then
			return false
		end
	else
		-- Can't be lower than the checking burt
		if v.y+v.height-64 > checkingBurt.y+checkingBurt.height+0.1 then
			return false
		end

		if v.data.state == STATE_JUMP_ONTO then
			return false
		end
	end

	return true
end

local function checkForTopBurts(v,hasCheckedMap)
	hasCheckedMap[v] = true
	
	-- See if there's any more burts on top of this one, and if so, run this function for that one
	local burts = Colliders.getColliding{
		a = getStandingOnTopCol(v),
		b = npcID,
		btype = Colliders.NPC,
		filter = burtFilter,
	}

	for _,burt in ipairs(burts) do
		if not hasCheckedMap[burt] then
			return checkForTopBurts(burt,hasCheckedMap)
		end
	end

	return v
end

local function getBurtToJumpOn(v,data,config,settings)
	checkingBurt = v

	local burts = Colliders.getColliding{
		a = Colliders.Circle(v.x + v.width*0.5,v.y + v.height*0.5,settings.maxJumpOntoRadius),
		b = npcID,
		btype = Colliders.NPC,
		filter = burtFilter,
	}

	--Colliders.Circle(v.x + v.width*0.5,v.y + v.height*0.5,settings.maxJumpOntoRadius):Debug(true)

	local hasCheckedMap = {}

	local closestBurt
	local closestDistance = math.huge

	for _,burt in ipairs(burts) do
		if burt ~= v and (v.direction == DIR_LEFT and burt.x+burt.width*0.5 < v.x+v.width*0.5 or v.direction == DIR_RIGHT and burt.x+burt.width*0.5 > v.x+v.width*0.5) then
			local properBurt = checkForTopBurts(burt,hasCheckedMap)

			if properBurt ~= nil then
				local distance = getDistance(v,properBurt)

				if distance < closestDistance then
					closestBurt = properBurt
					closestDistance = distance
				end
			end
		end
	end

	return closestBurt
end


local function npcSolidFilter(v)
	if not Colliders.FILTER_COL_NPC_DEF(v) or v:mem(0x12C,FIELD_WORD) > 0 or v:mem(0x138,FIELD_WORD) > 0 then
		return false
	end

	local config = NPC.config[v.id]
	if config == nil then
		return false
	end

	if config.npcblock or config.playerblocktop then
		return true
	end

	return false
end

local function isAtCliff(v,data,config,settings)
	local col = Colliders.Box(v.x + settings.jumpHorizontalDistance*v.direction,v.y + v.height - settings.jumpVerticalDistance,v.width,settings.jumpVerticalDistance + 12)
	--col:Debug(true)

	local blocks = Colliders.getColliding{
		a = col,
		b = Block.SOLID.. Block.SEMISOLID.. Block.PLAYER,
		btype = Colliders.BLOCK,
	}

	if #blocks > 0 then
		return false
	end

	local npcs = Colliders.getColliding{
		a = col,
		btype = Colliders.NPC,
		filter = npcSolidFilter,
	}

	if #npcs > 0 then
		return false
	end

	return true
end


local function normalBehaviour(v,data,config,settings)
	if v.collidesBlockBottom then
		v.speedX = 0
		v:mem(0x18,FIELD_FLOAT,0)
	end


	if data.state == STATE_NORMAL then
		if settings.behaviourType == BEHAVIOUR_STAND then
			if RNG.randomInt(1,128) == 1 then
				data.squashAnimationTimer = config.squashAnimationDuration*0.5
			end
		elseif v.collidesBlockBottom and not isStoodOn(v) then
			data.timer = data.timer + 1

			handlePreJumpSquash(v,data,config,settings,settings.preJumpTime - data.timer)

			if data.timer >= settings.preJumpTime then
				local burt = getBurtToJumpOn(v,data,config,settings)

				if burt ~= nil and not v.dontMove then
					local distanceToBurt = getDistance(v,burt)
					local burtData = burt.data

					if burtData.state ~= STATE_JUMPED_ON then
						burtData.state = STATE_JUMPED_ON
						burtData.timer = 0

						burtData.burtsJumpingOnto = {}

						if burt.collidesBlockBottom then
							burt.speedX = 0
							burt.speedY = 0
						end
					end

					local insertIdx = 1

					for i,otherBurt in ipairs(burtData.burtsJumpingOnto) do
						if getDistance(burt,otherBurt) > distanceToBurt then
							insertIdx = i
							break
						end
					end

					table.insert(burtData.burtsJumpingOnto,insertIdx,v)

					data.state = STATE_JUMP_ONTO
					data.timer = 0
					data.burtBeingJumpedOn = burt
				elseif settings.behaviourType == BEHAVIOUR_JUMP_TURN and isAtCliff(v,data,config,settings) then
					v.direction = -v.direction
				else
					jumpTo(v,data,config,v.x + settings.jumpHorizontalDistance*v.direction,v.y - settings.jumpVerticalDistance)
				end

				data.timer = 0
			end
		else
			data.timer = 0
		end
	elseif data.state == STATE_JUMP_ONTO then
		local burt = data.burtBeingJumpedOn

		checkingBurt = v

		if burtFilter(burt,false) then
			local burtData = burt.data
			
			if v.collidesBlockBottom and data.timer <= 0 then
				local isTopBurt = true
				local canJump = true

				local lastBurt = burt

				checkingBurt = burt

				for _,otherBurt in ipairs(burtData.burtsJumpingOnto) do
					if burtFilter(otherBurt,true) then
						local isStanding = getStandingOnTopCol(lastBurt):collide(otherBurt)

						if isStanding == (otherBurt == v) then
							canJump = false
							break
						end

						if otherBurt == v then
							break
						else
							lastBurt = otherBurt
							isTopBurt = false
						end
					else
						break
					end
				end

				if canJump then
					--Colliders.getHitbox(lastBurt):Debug(true)
					jumpTo(v,data,config,lastBurt.x + lastBurt.width*0.5 - v.width*0.5,lastBurt.y - v.height - 8)

					data.timer = settings.preJumpTime
				end
			elseif v.collidesBlockBottom and data.timer > 0 then
				handlePreJumpSquash(v,data,config,settings,data.timer)
				data.timer = data.timer - 1
			end

			--Text.print(table.ifind(burtData.burtsJumpingOnto,v),v.x-camera.x,v.y-camera.y)

			v:mem(0x120,FIELD_BOOL,false)
		else
			data.state = STATE_NORMAL
			data.timer = 0
		end
	elseif data.state == STATE_JUMPED_ON then
		-- Delete an invalid burts that are trying to jump onto this one
		checkingBurt = v

		local noBurtsLeft = true
		local allAssembled = true

		local forceCancel = false

		local lastBurt = v

		local i = 1
		
		while (i <= #data.burtsJumpingOnto) do
			local burt = data.burtsJumpingOnto[i]

			if burtFilter(burt,true) then
				noBurtsLeft = false

				if not getStandingOnTopCol(lastBurt):collide(burt) then
					allAssembled = false
				end

				if getStandingOnTopCol(burt):collide(v) then
					forceCancel = true
					break
				end

				--getStandingOnTopCol(lastBurt):Draw()

				lastBurt = burt

				i = i + 1
			else
				table.remove(data.burtsJumpingOnto,i)
			end
		end

		if noBurtsLeft or forceCancel then
			data.state = STATE_NORMAL
			data.timer = 0
		elseif allAssembled then
			data.timer = data.timer + 1

			if data.timer >= 24 then
				-- Make everybody leap off!
				local delay = 0

				for i = #data.burtsJumpingOnto, 1, -1 do
					local burt = data.burtsJumpingOnto[i]
					
					burt.data.state = STATE_LEAP
					burt.data.timer = delay

					delay = delay + 48
				end

				data.state = STATE_LEAP
				data.timer = delay
			end
		else
			data.timer = 0
		end
	elseif data.state == STATE_LEAP then
		data.timer = data.timer - 1

		handlePreJumpSquash(v,data,config,settings,data.timer)

		if data.timer <= 0 then
			data.state = STATE_NORMAL
			data.timer = 0

			jumpTo(v,data,config,v.x + settings.leapHorizontalDistance*v.direction,v.y - settings.leapVerticalDistance)
		end
	end


	if data.wasOnGround ~= v.collidesBlockBottom then
		--data.squashAnimationTimer = config.squashAnimationDuration
	end
end


function burt.onTickEndNPC(v)
	if Defines.levelFreeze then return end
	
	local data = v.data
	
	if v.despawnTimer <= 0 then
		data.initialized = false
		return
	end

	local config = NPC.config[v.id]
	local settings = v.data._settings

	if not data.initialized then
		initialise(v,data,config,settings)
	end


	if isStoodOn(v) then
		data.squash = math.min(config.stoodOnSquash,data.squash + 0.05)
	elseif data.squashAnimationTimer > 0 then
		local t = data.squashAnimationTimer/config.squashAnimationDuration
		
		data.squash = math.cos(t*math.pi*2)*config.squashAnimationValue*t
		data.squashAnimationTimer = data.squashAnimationTimer - 1
	elseif data.squash > 0 then
		data.squash = math.max(0,data.squash - 0.05)
	elseif data.squash < 0 then
		data.squash = math.min(0,data.squash + 0.05)
	end
	
	if v:mem(0x12C,FIELD_WORD) == 0 and not v:mem(0x136,FIELD_BOOL) and v:mem(0x138,FIELD_WORD) == 0 then
		normalBehaviour(v,data,config,settings)
	end

	data.wasOnGround = v.collidesBlockBottom

	handleAnimation(v,data,config)
end


local lowPriorityStates = table.map{1,3,4}

function burt.onDrawNPC(v)
	if v.despawnTimer <= 0 or v.isHidden then return end

	local config = NPC.config[v.id]
	local data = v.data

	local settings = v.data._settings

	if not data.initialized then
		initialise(v,data,config,settings)
	end


	local texture = Graphics.sprites.npc[v.id].img
	if texture == nil then
		return
	end


	if data.shoesSprite == nil then
		local totalFrames = npcutils.getTotalFramesByFramestyle(v)

		data.shoesSprite = Sprite{texture = texture,frames = totalFrames,pivot = Sprite.align.BOTTOM}
		data.bodySprite = Sprite{texture = texture,frames = totalFrames,pivot = Sprite.align.BOTTOM}

		data.bodySprite.transform:setParent(data.shoesSprite.transform)
	end


	local priority = -45
	if lowPriorityStates[v:mem(0x138,FIELD_WORD)] then
		priority = -75
	elseif v:mem(0x12C,FIELD_WORD) > 0 then
		priority = -30
	elseif config.foreground then
		priority = -15
	end


	data.shoesSprite.x = v.x + v.width*0.5 + config.gfxoffsetx
	data.shoesSprite.y = v.y + v.height + config.gfxoffsety

	data.bodySprite.scale.x = 1 + data.squash
	data.bodySprite.scale.y = 1 - data.squash

	data.bodySprite:draw{frame = data.bodyFrame+1,priority = priority,sceneCoords = true}
	data.shoesSprite:draw{frame = data.shoesFrame+1,priority = priority,sceneCoords = true}

	npcutils.hideNPC(v)
end


return burt