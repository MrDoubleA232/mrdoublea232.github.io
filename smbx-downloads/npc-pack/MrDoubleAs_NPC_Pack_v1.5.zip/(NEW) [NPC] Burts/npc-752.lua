--[[

	Written by MrDoubleA
	Please give credit!

    Part of MrDoubleA's NPC Pack

]]

local npcManager = require("npcManager")
local npcutils = require("npcs/npcutils")

local burtBoss = {}
local npcID = NPC_ID

local burtBossSettings = {
	id = npcID,

	gfxoffsetx = 0,
	gfxoffsety = 4,
	
	width = 208,
	height = 240,
	
	speed = 1,
	
	npcblock = false,
	npcblocktop = false, --Misnomer, affects whether thrown NPCs bounce off the NPC.
	playerblock = false,
	playerblocktop = false, --Also handles other NPCs walking atop this NPC.

	nohurt = false,
	nogravity = false,
	noblockcollision = false,
	nofireball = false,
	noiceball = true,
	noyoshi = true,
	nowaterphysics = false,
	
	jumphurt = false,
	spinjumpsafe = false,
	harmlessgrab = false,
	harmlessthrown = false,


	staticdirection = true,


	introPantsPullUpSpeed = 0.0025,
	introPantsStartHeight = 0.35,
	introTurnSpeed = 24,
	introWaitTime = 24,

	turnRedPreTime = 32,
	turnRedTime = 64,
	turnRedAfterTime = 16,

	bounceSpeed = 24,
	bounceTime = 160,
	bounceRotationSpeed = 10,

	squashAnimationValue = 0.2,
	squashAnimationDuration = 24,

	preJumpSquash = 0.2,

	turnAnimationDuration = 12,


	jumpSound = Misc.resolveSoundFile("burts_jump"),
	stompSound = Misc.resolveSoundFile("burts_stomp"),
	hurtSound = Misc.resolveSoundFile("burts_hurt"),
	bounceSound = Misc.resolveSoundFile("burts_bounce"),
	bouncedOnSound = Misc.resolveSoundFile("burts_bouncedOn"),


	bodyImage = Graphics.loadImageResolved("burts_bossBody.png"),
	bodyOffsetX = 0,
	bodyOffsetY = -13,

	handImage = Graphics.loadImageResolved("burts_bossHand.png"),
	handOffsetX = 66,
	handOffsetY = -130,
	handTurnOffsetX = 40,
	handTurnScale = 0.4375,

	blushImage = Graphics.loadImageResolved("burts_bossBlush.png"),
	blushOffsetX = 28,
	blushOffsetY = -218,
	blushTurnOffsetX = 42,
	blushTurnScale = 0.5,

	eyesImage = Graphics.loadImageResolved("burts_bossEyes.png"),
	eyesOffsetX = -3,
	eyesOffsetY = -262,
	eyesTurnOffsetX = 4,
	eyesTurnScale = 1,

	hairImage = Graphics.loadImageResolved("burts_bossHair.png"),
	hairOffsetX = 50,
	hairOffsetY = -262,
	hairTurnOffsetX = -52,
	hairTurnScale = 1,

	noseImage = Graphics.loadImageResolved("burts_bossShoeNose.png"),
	noseOffsetX = -74,
	noseOffsetY = -238,
	noseTurnOffsetX = 38,
	noseTurnScale = 0.67,

	shoesImage = Graphics.loadImageResolved("burts_bossShoeNose.png"),
	shoesOffsetX = 8,
	shoesOffsetY = -18,

	shoesStandRotation = 180,
	shoesJumpRotation = 245,
	shoesJumpShake = 10,
}

npcManager.setNpcSettings(burtBossSettings)
npcManager.registerHarmTypes(npcID,
	{
		HARM_TYPE_JUMP,
		HARM_TYPE_FROMBELOW,
		HARM_TYPE_NPC,
		HARM_TYPE_PROJECTILE_USED,
		HARM_TYPE_LAVA,
		HARM_TYPE_HELD,
		HARM_TYPE_OFFSCREEN,
		HARM_TYPE_SWORD
	},
	{
		[HARM_TYPE_LAVA] = {id=13, xoffset=0.5, xoffsetBack = 0, yoffset=1, yoffsetBack = 1.5},
	}
)


function burtBoss.onInitAPI()
	npcManager.registerEvent(npcID, burtBoss, "onTickEndNPC")
	npcManager.registerEvent(npcID, burtBoss, "onDrawNPC")

	registerEvent(burtBoss,"onNPCHarm")
end


local STATE_INTRO_BEGIN   = 0
local STATE_INTRO_PULL_UP = 1
local STATE_INTRO_FINISH  = 2
local STATE_STAND         = 3
local STATE_JUMP          = 4
local STATE_HURT          = 5
local STATE_TURN_RED      = 6
local STATE_BOUNCE        = 7

local DEFEAT_TYPE_ALL    = 0
local DEFEAT_TYPE_BOUNCE = 1
local DEFEAT_TYPE_MAGIC  = 2
local DEFEAT_TYPE_NONE   = 3


local fadeShader


local function getHealthPantsHeight(health,settings)
	return (settings.pantsMaxHeight/100) * (health/settings.health)
end


local function initialise(v,data,config,settings)
	data.initialized = true

	data.health = settings.health
	data.healthLerpValue = 0 -- this value is 0 at full health, and 1 at no health

	data.turnDirection = v.direction
	data.turnTimer = 0

	data.squash = 0
	data.scale = 1

	data.rotation = 0

	data.redFade = 0
	data.turnValue = 0

	data.squashAnimationTimer = 0

	data.shoesRotation = config.shoesStandRotation

	data.bounceSpeed = vector.zero2

	if settings.haveIntro then
		data.state = STATE_INTRO_BEGIN
		data.pantsHeight = config.introPantsStartHeight
	else
		data.state = STATE_STAND
		data.pantsHeight = getHealthPantsHeight(data.health,settings)
	end

	data.timer = 0


	-- Graphical stuff
	data.mainTransform = Transform(vector.zero2,0,vector.one2) -- all sprites are parented to this transform

	data.bodySprite = Sprite{texture = config.bodyImage,frames = 3,pivot = Sprite.align.BOTTOM}
	data.bodySprite.transform:setParent(data.mainTransform)

	data.handSprite = Sprite{texture = config.handImage,frames = 2,pivot = Sprite.align.CENTRE}
	data.handSprite.transform:setParent(data.mainTransform)

	data.blushSprite = Sprite{texture = config.blushImage,pivot = Sprite.align.CENTRE}
	data.blushSprite.transform:setParent(data.mainTransform)

	data.eyesSprite = Sprite{texture = config.eyesImage,frames = 2,pivot = Sprite.align.CENTRE}
	data.eyesSprite.transform:setParent(data.mainTransform)

	data.noseSprite = Sprite{texture = config.noseImage,pivot = Sprite.align.CENTRE}
	data.noseSprite.transform:setParent(data.mainTransform)

	data.hairSprite = Sprite{texture = config.hairImage,pivot = Sprite.align.CENTRE}
	data.hairSprite.transform:setParent(data.mainTransform)

	data.shoeSprites = {}

	for i = 1,2 do
		local sprite = Sprite{texture = config.shoesImage,pivot = Sprite.align.RIGHT}
		sprite.transform:setParent(data.mainTransform)

		data.shoeSprites[i] = sprite
	end

	if fadeShader == nil then
		fadeShader = Shader()
		fadeShader:compileFromFile(nil,"burts_bossFade.frag")
	end
end


local stateFunctions = {}


-- Intro states
stateFunctions[STATE_INTRO_BEGIN] = function(v,data,config,settings)
	data.timer = data.timer + 1

	if data.timer >= config.introWaitTime then
		data.state = STATE_INTRO_PULL_UP
		data.timer = 0
	end
end

stateFunctions[STATE_INTRO_PULL_UP] = function(v,data,config,settings)
	local maxHeight = getHealthPantsHeight(data.health,settings)

	data.timer = data.timer + 1
	data.turnValue = (-math.cos(data.timer/config.introTurnSpeed*math.pi*2) + 1) * 0.5

	if data.pantsHeight < maxHeight then
		data.pantsHeight = math.min(maxHeight,data.pantsHeight + config.introPantsPullUpSpeed)
	elseif data.pantsHeight > maxHeight then
		data.pantsHeight = math.max(maxHeight,data.pantsHeight - config.introPantsPullUpSpeed)
	else
		data.state = STATE_INTRO_FINISH
		data.timer = 0
	end
end

stateFunctions[STATE_INTRO_FINISH] = function(v,data,config,settings)
	data.timer = data.timer + 1

	data.turnValue = math.max(0,data.turnValue - 0.1)

	if data.turnValue == 0 and data.timer >= config.introWaitTime then
		data.state = STATE_STAND
		data.timer = 0
	end
end


-- Normal state functions
stateFunctions[STATE_STAND] = function(v,data,config,settings)
	local preJumpTime = math.lerp(settings.preJumpTimeHigh,settings.preJumpTimeLow,data.healthLerpValue)

	data.shoesRotation = config.shoesStandRotation

	if v.collidesBlockBottom then
		data.timer = data.timer + 1

		if preJumpTime > 1 then
			data.squash = data.timer/preJumpTime*config.preJumpSquash
		else
			data.squash = config.preJumpSquash
		end

		if data.timer >= preJumpTime then
			data.state = STATE_JUMP
			data.timer = 0

			v.speedX = math.lerp(settings.jumpSpeedXHigh,settings.jumpSpeedXLow,data.healthLerpValue) * v.direction
			v.speedY = math.lerp(settings.jumpSpeedYHigh,settings.jumpSpeedYLow,data.healthLerpValue)

			data.squashAnimationTimer = config.squashAnimationDuration

			SFX.play(config.jumpSound)
		end
	else
		data.timer = 0
		data.squash = 0
	end
end

stateFunctions[STATE_JUMP] = function(v,data,config,settings)
	if v.collidesBlockBottom then
		data.state = STATE_STAND
		data.timer = 0

		SFX.play(config.stompSound)
		Defines.earthquake = 5

		return
	end

	data.timer = data.timer + 1

	if v.speedY < 0 then
		local t = data.timer/8

		if t < 1 then
			data.shoesRotation = math.lerp(config.shoesStandRotation,config.shoesJumpRotation,t)
		else
			data.shoesRotation = config.shoesJumpRotation + math.sin((t - 1)*6)*config.shoesJumpShake
		end
	else
		data.shoesRotation = math.max(config.shoesStandRotation,data.shoesRotation - 3.5)
	end
end


-- Hurt states
stateFunctions[STATE_HURT] = function(v,data,config,settings)
	if v.collidesBlockBottom then
		if data.timer == 0 then
			data.squashAnimationTimer = config.squashAnimationDuration

			SFX.play(config.stompSound)
			Defines.earthquake = 5
		end

		local minPantsHeight = getHealthPantsHeight(data.health,settings)

		data.timer = data.timer + 1

		if data.timer >= settings.hurtStandTime then
			if data.health > 0 then
				data.state = STATE_STAND
			else
				data.state = STATE_TURN_RED
			end

			data.timer = 0

			data.pantsHeight = minPantsHeight
		elseif data.timer >= settings.hurtStandTime*0.5 then
			data.pantsHeight = math.max(minPantsHeight,data.pantsHeight - 1/(settings.hurtStandTime*0.5))
		end
	else
		data.timer = 0
	end

	data.shoesRotation = config.shoesStandRotation
end


-- Defeated stuff
stateFunctions[STATE_TURN_RED] = function(v,data,config,settings)
	data.timer = data.timer + 1
	data.redFade = math.clamp((data.timer - config.turnRedPreTime) / config.turnRedTime)

	if data.timer >= config.turnRedPreTime+config.turnRedTime+config.turnRedAfterTime then
		if settings.haveDefeatedBounce then
			data.state = STATE_BOUNCE
			data.timer = 0

			data.bounceSpeed = vector(0,-config.bounceSpeed):rotate(RNG.random(0,360))

			v.noblockcollision = true
			v.friendly = true

			SFX.play(config.bounceSound)
		else
			if v.despawnTimer > 120 then
				local effectID = 10
				local effectConfig = Effect.config[effectID][1]

				local effectCountX = math.floor(v.width /effectConfig.width  + 0.5)
				local effectCountY = math.floor(v.height/effectConfig.height + 0.5)

				local effectsTotalWidth  = effectCountX*effectConfig.width
				local effectsTotalHeight = effectCountY*effectConfig.height

				for x = 0,effectCountX-1 do
					for y = 0,effectCountY-1 do
						Effect.spawn(
							effectID,
							v.x + v.width *0.5 - effectsTotalWidth *0.5 + x*effectConfig.width,
							v.y + v.height*0.5 - effectsTotalHeight*0.5 + y*effectConfig.height
						)
					end
				end

				SFX.play(41)
			end

			v:kill(HARM_TYPE_VANISH)
		end
	end
end

stateFunctions[STATE_BOUNCE] = function(v,data,config,settings)
	data.timer = data.timer + 1
	data.scale = math.cos(data.timer/config.bounceTime*math.pi*0.5)

	if data.timer >= config.bounceTime then
		SFX.play(41)

		v:kill(HARM_TYPE_VANISH)

		return
	end

	local width = v.width*data.scale
	local height = v.height*data.scale
	local x = v.x + v.width*0.5 - width*0.5
	local y = v.y + v.height*0.5 - height*0.5

	-- Find the closest camera
	local closestDistance = math.huge
	local closestCamera

	for _,c in ipairs(Camera.get()) do
		if (c.idx == 1 or c.isSplit) then
			local distance = vector((c.x + c.width*0.5) - x,(c.y + c.height*0.5) - y).length

			if distance < closestDistance then
				closestDistance = distance
				closestCamera = c
			end
		end
	end

	-- Bouncin' around
	if closestDistance < 1024 then
		local bounceBaseRotation

		if x <= closestCamera.x then -- left side
			bounceBaseRotation = 90
		elseif x+width >= closestCamera.x+closestCamera.width then -- right side
			bounceBaseRotation = -90
		elseif y <= closestCamera.y then -- top side
			bounceBaseRotation = 180
		elseif y+height >= closestCamera.y+closestCamera.height then
			bounceBaseRotation = 0
		end

		if bounceBaseRotation ~= nil then
			data.bounceSpeed = vector(0,-config.bounceSpeed):rotate(bounceBaseRotation + RNG.random(-75,75))

			SFX.play(config.bounceSound)
		end
	end


	v.x = v.x + data.bounceSpeed.x
	v.y = v.y + data.bounceSpeed.y

	data.rotation = data.rotation + config.bounceRotationSpeed


	-- Spawn trail
	if data.timer%2 == 0 then
		local e = Effect.spawn(10,v.x + v.width*0.5,v.y + v.height*0.5)

		e.x = e.x - e.width *0.5
		e.y = e.y - e.height*0.5
	end


	if config.nogravity then
		v.speedY = 0
	elseif v.underwater and not config.nowaterphysics then
		v.speedY = -Defines.npc_grav*0.2
	else
		v.speedY = -Defines.npc_grav
	end
end



function burtBoss.onTickEndNPC(v)
	if Defines.levelFreeze then return end
	
	local data = v.data
	
	if v.despawnTimer <= 0 then
		data.initialized = false
		return
	end

	local config = NPC.config[v.id]
	local settings = v.data._settings

	if not data.initialized then
		initialise(v,data,config,settings)
	end


	data.healthLerpValue = 1 - (data.health/settings.health)

	-- Squash
	if data.squashAnimationTimer > 0 then
		local t = data.squashAnimationTimer/config.squashAnimationDuration
		
		data.squash = math.cos(t*math.pi*2)*config.squashAnimationValue*t
		data.squashAnimationTimer = data.squashAnimationTimer - 1
	elseif data.squash > 0 then
		data.squash = math.max(0,data.squash - 0.05)
	elseif data.squash < 0 then
		data.squash = math.min(0,data.squash + 0.05)
	end

	-- Normal behaviour
	if v:mem(0x12C,FIELD_WORD) == 0 and not v:mem(0x136,FIELD_BOOL) and v:mem(0x138,FIELD_WORD) == 0 then
		if v.collidesBlockBottom then
			v.speedX = 0
			v:mem(0x18,FIELD_FLOAT,0)
		end

		if v:mem(0x120,FIELD_BOOL) then
			if data.state == STATE_JUMP then
				v.direction = -v.direction
			else
				v.speedX = 0
				v:mem(0x18,FIELD_FLOAT,0)
			end
		end

		stateFunctions[data.state](v,data,config,settings)
	end

	-- Turn animation
	if data.turnDirection ~= v.direction then
		data.turnDirection = v.direction
		data.turnTimer = 1
	end

	if data.turnTimer > 0 then
		local t = data.turnTimer/(config.turnAnimationDuration*0.5)

		data.turnTimer = data.turnTimer + 1

		if t < 1 then
			data.turnValue = t
		elseif t < 2 then
			data.turnValue = 1 - (t - 1)
		else
			data.turnTimer = 0
		end
	end

	-- No despawning
	v.despawnTimer = math.max(100,v.despawnTimer)
end


local lowPriorityStates = table.map{1,3,4}

function burtBoss.onDrawNPC(v)
	if v.despawnTimer <= 0 or v.isHidden then return end

	local config = NPC.config[v.id]
	local data = v.data

	local settings = v.data._settings

	if not data.initialized then
		initialise(v,data,config,settings)
	end


	local opacity = 1

	if v:mem(0x156,FIELD_WORD) > 0 then
		opacity = math.sin(lunatime.tick()*math.pi*0.25)*0.1 + 0.9
	end

	local pivotOffsetX = 0
	local pivotOffsetY = 0

	if data.state == STATE_BOUNCE then
		pivotOffsetY = config.bodyOffsetY - data.bodySprite.height*0.5
	end


	local priority = -45
	if lowPriorityStates[v:mem(0x138,FIELD_WORD)] then
		priority = -75
	elseif v:mem(0x12C,FIELD_WORD) > 0 then
		priority = -30
	elseif config.foreground then
		priority = -15
	end


	local direction = v.direction
	if data.turnTimer > 0 and data.turnTimer <= config.turnAnimationDuration*0.5 then
		direction = -data.turnDirection
	end


	data.mainTransform.position.x = v.x + v.width*0.5 + config.gfxoffsetx + pivotOffsetX
	data.mainTransform.position.y = v.y + v.height + config.gfxoffsety + pivotOffsetY

	data.mainTransform.scale.x = (1 + data.squash)*data.scale*-direction
	data.mainTransform.scale.y = (1 - data.squash)*data.scale

	data.mainTransform.rotation = data.rotation


	-- Draw hair
	data.hairSprite.x = config.hairOffsetX + config.hairTurnOffsetX*data.turnValue - pivotOffsetX
	data.hairSprite.y = config.hairOffsetY - pivotOffsetY

	data.hairSprite.scale.x = math.lerp(1,config.hairTurnScale,data.turnValue)

	data.hairSprite:draw{color = Color.white.. opacity,priority = priority,sceneCoords = true}


	-- Draw body
	data.bodySprite.x = config.bodyOffsetX - pivotOffsetX
	data.bodySprite.y = config.bodyOffsetY - pivotOffsetY

	data.bodySprite:draw{
		color = Color.white.. opacity,priority = priority,sceneCoords = true,
		shader = fadeShader,uniforms = {
			cutoffPoint = 1 - data.pantsHeight,
			cutoffAbove = 0,

			frameA = 0,
			frameB = 1,
			frameFade = data.redFade,

			frames = data.bodySprite.frames,
		},
	}


	-- Draw blush
	data.blushSprite.x = config.blushOffsetX + config.blushTurnOffsetX*data.turnValue - pivotOffsetX
	data.blushSprite.y = config.blushOffsetY - pivotOffsetY

	data.blushSprite.scale.x = math.lerp(1,config.blushTurnScale,data.turnValue)

	data.blushSprite:draw{color = Color.white.. opacity,priority = priority,sceneCoords = true}

	
	-- Draw hand
	data.handSprite.x = config.handOffsetX + config.handTurnOffsetX*data.turnValue - pivotOffsetX
	data.handSprite.y = config.handOffsetY - pivotOffsetY

	data.handSprite.scale.x = math.lerp(1,config.handTurnScale,data.turnValue)

	data.handSprite:draw{
		color = Color.white.. opacity,priority = priority,sceneCoords = true,
		shader = fadeShader,uniforms = {
			cutoffPoint = 1,
			cutoffAbove = 0,

			frameA = 0,
			frameB = 1,
			frameFade = data.redFade,

			frames = data.handSprite.frames,
		},
	}


	-- Draw eyes
	data.eyesSprite.x = config.eyesOffsetX + config.eyesTurnOffsetX*data.turnValue - pivotOffsetX
	data.eyesSprite.y = config.eyesOffsetY - pivotOffsetY

	data.eyesSprite.scale.x = math.lerp(1,config.eyesTurnScale,data.turnValue)

	data.eyesSprite:draw{color = Color.white.. opacity,priority = priority,sceneCoords = true,frame = (data.redFade >= 1 and 2) or 1}


	-- Draw nose
	data.noseSprite.x = config.noseOffsetX + config.noseTurnOffsetX*data.turnValue - pivotOffsetX
	data.noseSprite.y = config.noseOffsetY - pivotOffsetY

	data.noseSprite.scale.x = math.lerp(1,config.noseTurnScale,data.turnValue)

	data.noseSprite:draw{color = Color.white.. opacity,priority = priority,sceneCoords = true}


	-- Draw pants
	data.bodySprite:draw{
		color = Color.white.. opacity,priority = priority,sceneCoords = true,
		shader = fadeShader,uniforms = {
			cutoffPoint = 1 - data.pantsHeight,
			cutoffAbove = 1,

			frameA = 2,
			frameB = 2,
			frameFade = 0,

			frames = data.bodySprite.frames,
		},
	}

	-- Draw shoes
	for i,sprite in ipairs(data.shoeSprites) do
		local shoeDirection = (i - 1)*2 - 1

		sprite.x = config.shoesOffsetX*shoeDirection - pivotOffsetX
		sprite.y = config.shoesOffsetY - pivotOffsetY

		sprite.rotation = data.shoesRotation*shoeDirection
		sprite.scale.x = shoeDirection

		sprite:draw{color = Color.white.. opacity,priority = priority,sceneCoords = true}
	end
end


local function doStandardHarm(v,data,config,settings,damage)
	data.state = STATE_HURT
	data.timer = 0

	data.health = math.max(0,data.health - damage)

	data.turnValue = 0

	v.speedX = settings.hurtSpeedX * -v.direction
	v.speedY = settings.hurtSpeedY
	v.collidesBlockBottom = false

	v:mem(0x156,FIELD_WORD,settings.hurtInvincibilityTime)

	SFX.play(config.hurtSound)
end


function burtBoss.onNPCHarm(eventObj,v,reason,culprit)
	if v.id ~= npcID or reason == HARM_TYPE_VANISH or v.despawnTimer <= 0 then return end

	local config = NPC.config[v.id]
	local data = v.data

	local settings = v.data._settings

	if not data.initialized then
		initialise(v,data,config,settings)
	end

	eventObj.cancelled = true


	-- Bounce on it
	if reason == HARM_TYPE_JUMP or reason == HARM_TYPE_SPINJUMP then
		if data.squashAnimationTimer <= config.squashAnimationDuration*0.5 then
			data.squashAnimationTimer = config.squashAnimationDuration
		end

		SFX.play(config.bouncedOnSound)

		return
	end


	if v:mem(0x156,FIELD_WORD) > 0 or data.health <= 0 then
		return
	end

	data.pantsHeight = getHealthPantsHeight(data.health,settings)

	if type(culprit) == "NPC" and culprit.id == 13 then
		if settings.fireballDamage >= 1 then
			doStandardHarm(v,data,config,settings,settings.fireballDamage)
		elseif settings.fireballDamage > 0 then
			data.health = math.max(0,data.health - settings.fireballDamage)
			SFX.play(9)

			v:mem(0x156,FIELD_WORD,math.min(8,settings.hurtInvincibilityTime))

			if data.health <= 0 then
				doStandardHarm(v,data,config,settings,0)
			else
				data.pantsHeight = getHealthPantsHeight(data.health,settings)
			end
		end
	else
		if culprit ~= nil then
			if culprit.x+culprit.width*0.5 < v.x+v.width*0.5 then
				v.direction = DIR_LEFT
			else
				v.direction = DIR_RIGHT
			end
		end

		doStandardHarm(v,data,config,settings,1)
	end
end


return burtBoss