--[[

	Written by MrDoubleA
	Please give credit!

    Part of MrDoubleA's NPC Pack

]]

local npcManager = require("npcManager")
local npcutils = require("npcs/npcutils")

local ai = require("swingingClaw_ai")

local swingingClaw = {}
local npcID = NPC_ID

local swingingClawSettings = table.join({
	id = npcID,

	npcReleaseBehaviour = ai.NPC_RELEASE_WHEN_CLOSE,
},ai.sharedSettings)

npcManager.setNpcSettings(swingingClawSettings)
npcManager.registerHarmTypes(npcID,{},{})

ai.register(npcID)

return swingingClaw