--[[

	Written by MrDoubleA
	Please give credit!

    Part of MrDoubleA's NPC Pack

]]

local npcManager = require("npcManager")
local npcutils = require("npcs/npcutils")

local verletrope = require("verletrope")
local lineguide = require("lineguide")

local playerManager = require("playerManager")

local swingingClaw = {}
local npcID = NPC_ID


swingingClaw.npcBlacklist = table.map{
	13,265,266,
}

swingingClaw.npcWhitelist = {}


swingingClaw.NPC_RELEASE_WHEN_CLOSE = 0
swingingClaw.NPC_NEVER_RELEASE = 1

swingingClaw.objectCaughtMap = {}


swingingClaw.idList = {}
swingingClaw.idMap = {}

swingingClaw.sharedSettings = {
	gfxwidth = 80,
	gfxheight = 48,

	gfxoffsetx = 0,
	gfxoffsety = 0,
	
	width = 32,
	height = 32,
	
	frames = 1,
	framestyle = 0,
	framespeed = 8,
	
	speed = 1,
	
	npcblock = false,
	npcblocktop = false, --Misnomer, affects whether thrown NPCs bounce off the NPC.
	playerblock = false,
	playerblocktop = false, --Also handles other NPCs walking atop this NPC.

	nohurt = true,
	nogravity = true,
	noblockcollision = true,
	nofireball = true,
	noiceball = true,
	noyoshi = true,
	nowaterphysics = true,
	
	jumphurt = true,
	spinjumpsafe = false,
	harmlessgrab = true,
	harmlessthrown = true,

	ignorethrownnpcs = true,
	notcointransformable = true,
	--isstationary = true,


	boltGFXOffsetX = 0,
	boltGFXOffsetY = 0,
	boltOffsetX = 0,
	boltOffsetY = 4,

	chainGFXOffsetX = 0,
	chainGFXOffsetY = 0,
	chainDistance = 16,

	clawGFXOffsetX = 0,
	clawGFXOffsetY = 16,
	clawWidthThreshold = 40,

	catchOffsetX = 0,
	catchOffsetY = 16,
	catchWidth = 16,
	catchHeight = 24,

	holdingOffsetX = 0,
	holdingOffsetY = 8,

	playerDropDistance = 64,
	catchCooldown = 24,
	dropCooldown = 48,

	playerAcceleration = 0.15,

	catchSound = Misc.resolveSoundFile("swingingClaw_catch"),
	dropSound = Misc.resolveSoundFile("swingingClaw_drop"),

	debug = false,
}

function swingingClaw.register(npcID)
	npcManager.registerEvent(npcID, swingingClaw, "onTickNPC")
	npcManager.registerEvent(npcID, swingingClaw, "onDrawNPC")
	npcManager.registerEvent(npcID, swingingClaw, "onCameraDrawNPC")

    lineguide.registerNpcs(npcID)

    table.insert(swingingClaw.idList,npcID)
    swingingClaw.idMap[npcID] = true
end


local allowedForcedStates = table.map{
	FORCEDSTATE_NONE,FORCEDSTATE_POWERUP_BIG,FORCEDSTATE_POWERDOWN_SMALL,FORCEDSTATE_POWERUP_FIRE,FORCEDSTATE_POWERUP_LEAF,
	FORCEDSTATE_POWERUP_TANOOKI,FORCEDSTATE_POWERUP_HAMMER,FORCEDSTATE_POWERUP_ICE,FORCEDSTATE_POWERDOWN_FIRE,
	FORCEDSTATE_POWERDOWN_ICE,FORCEDSTATE_TANOOKI_POOF,FORCEDSTATE_INVISIBLE,
}


local function stopLineguideAttach(v)
    local lineguideData = v.data._basegame.lineguide

    if lineguideData ~= nil then
        lineguideData.state = lineguide.states.NORMAL
        lineguideData.attachCooldown = 2
    end
end

local function setCatchHitbox(v,data,config)
	local clawSegment = data.rope.segments[#data.rope.segments]
	local col = data.catchHitbox

	col.width = config.catchWidth
	col.height = config.catchHeight
	col.x = clawSegment.position.x + config.catchOffsetX - col.width*0.5
	col.y = clawSegment.position.y + config.catchOffsetY - col.height*0.5
end

local function canCatchObject(v,data,config,a)
	if not a.isValid or a == v then
		return false
	end

	if type(a) == "Player" then
		if a.deathTimer > 0 or a:mem(0x13C,FIELD_BOOL) or a.isMega or not allowedForcedStates[a.forcedState] then
			return false
		end
	else
		if a:mem(0x12C,FIELD_WORD) > 0 or a:mem(0x138,FIELD_WORD) > 0 then
			return false
		end

		if not swingingClaw.npcWhitelist[a.id] and a.id ~= v.ai1 then
			if swingingClaw.npcBlacklist[a.id] then
				return false
			end

			local config = NPC.config[a.id]

			--[[if config.nogravity or config.noblockcollision or a.noblockcollision or config.nohurt then
				return false
			end]]

			if config.ignorethrownnpcs or config.noblockcollision or a.noblockcollision then
				return false
			end
		end
	end

	return true
end

local function getObjectToCatch(v,data,config)
	for _,p in ipairs(Player.get()) do
		if canCatchObject(v,data,config,p) and not swingingClaw.objectCaughtMap[p] and p.forcedState == FORCEDSTATE_NONE and data.catchHitbox:collide(p) then
			return p
		end
	end

	local npcs = Colliders.getColliding{a = data.catchHitbox,btype = Colliders.NPC}

	for _,n in ipairs(npcs) do
		if canCatchObject(v,data,config,n) and not swingingClaw.objectCaughtMap[n] then
			return n
		end
	end

	return nil
end

local function getObjectGravity(a)
	if type(a) == "Player" then
		local gravity = Defines.player_grav

		if a:mem(0x34,FIELD_WORD) > 0 then
			gravity = gravity*0.1
		elseif playerManager.getBaseID(a.character) == CHARACTER_LUIGI then
			gravity = gravity*0.9
		end

		return gravity
	else
		local config = NPC.config[a.id]

		if config.nogravity then
			return 0
		end

		local gravity = Defines.npc_grav

		if a.underwater and not config.nowaterphysics then
			gravity = gravity*0.2
		end

		return gravity
	end
end


local function releaseCaughtObject(v,data,config)
	local a = data.caughtObject

	if a.isValid then
		data.catchCooldownObject = a
		data.catchCooldown = config.catchCooldown

		if type(a) == "Player" then
            a.speedX = math.clamp(a.speedX,-Defines.player_runspeed,Defines.player_runspeed)
			a:mem(0x04,FIELD_WORD,0)
			a:mem(0x18,FIELD_BOOL,true) -- peach float
        elseif type(a) == "NPC" then
            a.speedX = math.clamp(a.speedX,-8,8)
		end
	end

	swingingClaw.objectCaughtMap[a] = nil
	data.caughtObject = nil

    SFX.play(config.dropSound)
end

local function playerJump(v,data,config, a,spinjump)
	if not a.keys.down then
		a:mem(0x11C,FIELD_WORD,Defines.jumpheight)

		if playerManager.getBaseID(a.character) == CHARACTER_LUIGI then
			a:mem(0x11C,FIELD_WORD,a:mem(0x11C,FIELD_WORD) + 3)
		elseif playerManager.getBaseID(a.character) == CHARACTER_TOAD then
			a:mem(0x00,FIELD_BOOL,true) -- tanooki double jump
		end

		if spinjump then
			a:mem(0x11C,FIELD_WORD,a:mem(0x11C,FIELD_WORD) - 6)
			a:mem(0x50,FIELD_BOOL,true)

			SFX.play(33)
		else
			SFX.play(1)
		end
	end

	releaseCaughtObject(v,data,config)
end

local spinjumpingCharacters = table.map{CHARACTER_MARIO,CHARACTER_LUIGI,CHARACTER_TOAD}

local function handleCaughtObject(v,data,config)
	local a = data.caughtObject

	if not canCatchObject(v,data,config,a) then
		releaseCaughtObject(v,data,config)
		return
	end

	if type(a) == "Player" then
		if a:mem(0x12E,FIELD_BOOL) then
			local settings = PlayerSettings.get(playerManager.getBaseID(a.character),a.powerup)

			a.y = a.y + a.height - settings.hitboxHeight
			a.height = settings.hitboxHeight
			a:mem(0x12E,FIELD_BOOL,false)
		end

		if a:mem(0x11C,FIELD_WORD) > 0 then
			releaseCaughtObject(v,data,config)
			return
		end

		if a:mem(0x34,FIELD_WORD) > 0 then -- underwater
			if a:mem(0x38,FIELD_WORD) >= 15 then -- swimming
				releaseCaughtObject(v,data,config)
				return
			end
        else
            if a.keys.altJump == KEYS_PRESSED and spinjumpingCharacters[a.character] then
				playerJump(v,data,config, a,true)
				return
			end

			if a.keys.jump == KEYS_PRESSED or a.keys.altJump == KEYS_PRESSED then
				playerJump(v,data,config, a,false)
				return
            end

		    if not a:isOnGround() and playerManager.getBaseID(a.character) == CHARACTER_LINK then
                if a.keys.left then
                    a.direction = DIR_LEFT
                elseif a.keys.right then
                    a.direction = DIR_RIGHT
                end

                a:mem(0x160,FIELD_WORD,2)
            end
		end

		a:mem(0x04,FIELD_WORD,1) -- prevent ducking
		a:mem(0x3C,FIELD_BOOL,false)
		a:mem(0x50,FIELD_BOOL,false)

		a:mem(0x18,FIELD_BOOL,false) -- peach float
		a:mem(0x1C,FIELD_WORD,0)
	else
		if data.dropCooldown <= 0 and config.npcReleaseBehaviour == swingingClaw.NPC_RELEASE_WHEN_CLOSE then
			for _,p in ipairs(Player.get()) do
				if p.forcedState == FORCEDSTATE_NONE and p.deathTimer == 0 and not p:mem(0x13C,FIELD_BOOL)
				and math.abs((p.x + p.width*0.5) - (a.x + a.width*0.5)) <= config.playerDropDistance
				and (p.y + p.height) > a.y
				then
					releaseCaughtObject(v,data,config)
					return
				end
			end
		end

		a:mem(0x136,FIELD_BOOL,true)
	end

	local clawSegment = data.rope.segments[#data.rope.segments]
	local distance = vector((clawSegment.position.x + config.holdingOffsetX) - (a.x + a.width*0.5),(clawSegment.position.y + config.holdingOffsetY) - a.y)

	if distance.length > 32 then
		releaseCaughtObject(v,data,config)
		return
	end

	a.speedX = distance.x
	a.speedY = distance.y - getObjectGravity(a) + 0.001

	if type(a) == "Player" then
		if a:isOnGround() then
			a.speedY = math.min(0,a.speedY)
		else
			if a.keys.left then
				a.speedX = a.speedX - config.playerAcceleration
			elseif a.keys.right then
				a.speedX = a.speedX + config.playerAcceleration
			end

			a:mem(0x138,FIELD_FLOAT,a.speedX)
			a.speedX = 0

			-- If the speed is slow enough, vanilla stuff will force it to 0.
			-- So, in a """fix""" for that, I presenteth unto thou: this.
			--[[if math.abs(a.speedX) < 0.18 then
				a.x = a.x + a.speedX
				a.speedX = 0
			end]]
		end
	elseif type(a) == "NPC" then
		stopLineguideAttach(a)
	end
end

local function shouldPauseRope(v,data,config)
	if type(data.caughtObject) == "Player" then
		if data.caughtObject.forcedState ~= FORCEDSTATE_NONE then
			return true
		end
	end

	return false
end


local function initialisePreSpawnStuff(v)
	local settings = v.data._settings
	local config = NPC.config[v.id]
	local data = v.data

	data.spawnBoundMargin = math.max(v.width,v.height) + settings.chainCount*config.chainDistance + 32
end

local function initialise(v,data,config)
	local settings = v.data._settings

	local chainCount = settings.chainCount + 2
	local startPos = vector(v.x + v.width*0.5 + config.boltOffsetX,v.y + v.height*0.5 + config.boltOffsetY)
	local endPos = startPos + vector(0,chainCount*config.chainDistance) + settings.attachedSpawnOffset

	data.rope = verletrope.Rope(startPos,endPos,chainCount,7,nil,true)
	data.rope.segmentLength = config.chainDistance

	data.catchHitbox = Colliders.Box(0,0,0,0)
	setCatchHitbox(v,data,config)

	data.catchCooldownObject = nil
	data.catchCooldown = 0
	data.dropCooldown = 0

	if v.ai1 > 0 then
		local a = NPC.spawn(v.ai1,data.catchHitbox.x + data.catchHitbox.width*0.5,data.catchHitbox.y + data.catchHitbox.height*0.5,v.section,false,true)

        swingingClaw.objectCaughtMap[a] = v
		data.caughtObject = a
	end

	data.initialized = true
end


function swingingClaw.onTickNPC(v)
	if Defines.levelFreeze then return end
	
	local data = v.data
	
	if v.despawnTimer <= 0 then
		data.initialized = false
		return
	end

	local config = NPC.config[v.id]

	if not data.initialized then
		initialise(v,data,config)
	end

	npcutils.applyLayerMovement(v)

	local lineguideData = v.data._basegame.lineguide

	if lineguideData ~= nil then
        if lineguideData.state == lineguide.states.FALLING then
            if v.underwater then
                v.speedY = math.min(1.6, v.speedY + Defines.npc_grav*0.2)
            else
                v.speedY = math.min(8, v.speedY + Defines.npc_grav)
            end
        end
    end

	
	-- Update the rope
	local clawSegment = data.rope.segments[#data.rope.segments]
	local a = data.caughtObject

	data.rope.segments[1].position = vector(v.x + v.width*0.5 + config.boltOffsetX,v.y + v.height*0.5 + config.boltOffsetY)

	if v.underwater then
		data.rope.gravity = Defines.npc_grav*0.2
	else
		data.rope.gravity = Defines.npc_grav
	end

	if a ~= nil and canCatchObject(v,data,config,a) then
		clawSegment.position = vector(a.x + a.width*0.5 - config.holdingOffsetX,a.y - config.holdingOffsetY)
	end

	if not shouldPauseRope(v,data,config) then
		data.rope:update()
	end

	setCatchHitbox(v,data,config)

	-- Handle already caught objects/catching new ones
	data.catchCooldown = math.max(0,data.catchCooldown - 1)
	data.dropCooldown = math.max(0,data.dropCooldown - 1)

	if a ~= nil then
		handleCaughtObject(v,data,config)
	else
		local newCaughtObject = getObjectToCatch(v,data,config)

		if newCaughtObject ~= nil and (data.catchCooldown <= 0 or data.catchCooldownObject ~= newCaughtObject) then
			data.caughtObject = newCaughtObject
			data.dropCooldown = config.dropCooldown
			SFX.play(config.catchSound)

			clawSegment.position = clawSegment.position + vector(newCaughtObject.speedX,newCaughtObject.speedY)

			newCaughtObject.x = clawSegment.position.x + config.catchOffsetX - newCaughtObject.width*0.5
			newCaughtObject.y = clawSegment.position.y + config.catchOffsetY

			swingingClaw.objectCaughtMap[newCaughtObject] = v

			if type(newCaughtObject) == "Player" then
				newCaughtObject:mem(0x11C,FIELD_WORD,0) -- stop jump force
				newCaughtObject:mem(0x10,FIELD_WORD,0) -- stop fairy form
			end

			handleCaughtObject(v,data,config)
		end
	end
end


local function drawNPC(v,data,config,frame,x,y)
	local texture = Graphics.sprites.npc[v.id].img

	local priority = -54
	if config.foreground then
		priority = -16
	end

	local width = config.gfxwidth
	local height = config.gfxheight

	Graphics.drawImageToSceneWP(texture,x - width*0.5 + config.gfxoffsetx,y - height*0.5,0,height*frame,width,height,priority)
end

function swingingClaw.onDrawNPC(v)
	if v.despawnTimer <= 0 then return end

	local config = NPC.config[v.id]
	local data = v.data

	if not data.initialized then
		initialise(v,data,config)
	end

	-- Chains
	for i,segment in ipairs(data.rope.segments) do
		if i > 1 and i < #data.rope.segments then
			drawNPC(v,data,config, 1,segment.position.x + config.chainGFXOffsetX,segment.position.y + config.chainGFXOffsetY)
		end
	end

	-- Draw bolt
	drawNPC(v,data,config, 0,v.x + v.width*0.5 + config.boltGFXOffsetX,v.y + v.height*0.5 + config.boltGFXOffsetY)

	-- Draw claw
	local clawSegment = data.rope.segments[#data.rope.segments]
	local clawFrame = 2
	
	if data.caughtObject ~= nil and canCatchObject(v,data,config,data.caughtObject) then
		if data.caughtObject.width <= config.clawWidthThreshold then
			clawFrame = clawFrame + 1
		else
			clawFrame = clawFrame + 2
		end
	end

	drawNPC(v,data,config, clawFrame,clawSegment.position.x + config.clawGFXOffsetX,clawSegment.position.y + config.clawGFXOffsetY)


	npcutils.hideNPC(v)


	if config.debug then
		for i = 1,#data.rope.segments do
			local a = data.rope.segments[i]
			local b = data.rope.segments[i + 1]

			--[[if b ~= nil then
				local x1 = a.position.x
				local y1 = a.position.y
				local x2 = b.position.x
				local y2 = b.position.y
				local rotation = math.atan(y2 - y1,x2 - x1)

				Graphics.glDraw{
					vertexCoords = {
						x1 - math.sin(rotation),y1 - math.cos(rotation),
						x2 - math.sin(rotation),y2 - math.cos(rotation),
						x1 + math.sin(rotation),y1 + math.cos(rotation),
						x2 + math.sin(rotation),y2 + math.cos(rotation),
					},
					primitive = Graphics.GL_TRIANGLE_STRIP,
					color = Color.red,sceneCoords = true,
				}
			end]]

			Graphics.drawCircle{
				color = Color.green,sceneCoords = true,
				x = a.position.x,y = a.position.y,radius = 4,
			}
		end

		data.catchHitbox:draw()
	end
end

function swingingClaw.onCameraDrawNPC(v,camIdx)
	local c = Camera(camIdx)
	local data = v.data

	if data.spawnBoundMargin == nil then
		initialisePreSpawnStuff(v)
	end

	local spawnBoundMargin = data.spawnBoundMargin
	local x = v.x + v.width*0.5
	local y = v.y + v.height*0.5

	if c.x+c.width > (x - spawnBoundMargin) and c.y+c.height > (y - spawnBoundMargin) and (x + spawnBoundMargin) > c.x and (y + spawnBoundMargin) > c.y then
		-- On camera, so activate (based on this  https://github.com/smbx/smbx-legacy-source/blob/master/modGraphics.bas#L517)
		local resetOffset = (0x126 + (camIdx - 1)*2)

		if v:mem(resetOffset, FIELD_BOOL) or v:mem(0x124,FIELD_BOOL) then
			if not v:mem(0x124,FIELD_BOOL) then
				v:mem(0x14C,FIELD_WORD,camIdx)
			end

			v.despawnTimer = 180
			v:mem(0x124,FIELD_BOOL,true)
		end

		v:mem(0x126,FIELD_BOOL,false)
		v:mem(0x128,FIELD_BOOL,false)
	end

	--[[Graphics.drawBox{
		color = Color.red.. 0.1,sceneCoords = true,
		x = x - spawnBoundMargin,
		y = y - spawnBoundMargin,
		width = spawnBoundMargin*2,
		height = spawnBoundMargin*2,
	}]]
end


return swingingClaw