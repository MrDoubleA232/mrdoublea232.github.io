--[[

	Written by MrDoubleA
	Please give credit!

    Part of MrDoubleA's NPC Pack

]]

local npcManager = require("npcManager")
local npcutils = require("npcs/npcutils")

local numberPlatform = {}
local npcID = NPC_ID


local disappearEffect = (npcID)


local numberPlatformSettings = {
	id = npcID,
	
	gfxwidth = 64,
	gfxheight = 64,

	gfxoffsetx = 0,
	gfxoffsety = 0,
	
	width = 64,
	height = 56,
	
	frames = 2,
	framestyle = 0,
	framespeed = 8,
	
	speed = 1,
	
	npcblock = false,
	npcblocktop = true, --Misnomer, affects whether thrown NPCs bounce off the NPC.
	playerblock = false,
	playerblocktop = true, --Also handles other NPCs walking atop this NPC.

	nohurt = true,
	nogravity = true,
	noblockcollision = true,
	nofireball = true,
	noiceball = true,
	noyoshi = true,
	nowaterphysics = true,
	
	jumphurt = false,
	spinjumpsafe = false,
	harmlessgrab = false,
	harmlessthrown = false,

	ignorethrownnpcs = true,



	numberFrames = 10,
	numberWidth = 32,
	numberGap = 20,

	numberColors = {
		Color.fromHexRGB(0xBD2900),
		Color.fromHexRGB(0xFF5A00),
		Color.fromHexRGB(0xA57384),
		Color.fromHexRGB(0x7B5A63),
	},

	disappearEffect = disappearEffect,

	pressedSound = Misc.resolveSoundFile("numberPlatform_pressed"),
	disappearSound = Misc.resolveSoundFile("numberPlatform_disappear"),
	countdownSound = Misc.resolveSoundFile("numberPlatform_countdown"),
}

npcManager.setNpcSettings(numberPlatformSettings)
npcManager.registerHarmTypes(npcID,{},{})


function numberPlatform.onInitAPI()
	npcManager.registerEvent(npcID, numberPlatform, "onTickEndNPC")
	npcManager.registerEvent(npcID, numberPlatform, "onDrawNPC")
end


local function initialise(v,data,config,settings)
	data.initialized = true

	data.counter = settings.counter or 1

	data.pressed = false

	data.animationTimer = 0
end

local function handleAnimation(v,data,config)
	if data.pressed then
		data.animationTimer = math.min((config.frames - 2)*config.framespeed + 1,data.animationTimer + 1)
	else
		data.animationTimer = math.max(0,data.animationTimer - 1)
	end

	local frame = math.min(config.frames,math.ceil(data.animationTimer/config.framespeed))

	v.animationFrame = npcutils.getFrameByFramestyle(v,{frame = frame})
end


function numberPlatform.onTickEndNPC(v)
	if Defines.levelFreeze then return end
	
	local data = v.data
	
	if v.despawnTimer <= 0 then
		data.initialized = false
		return
	end

	local settings = v.data._settings
	local config = NPC.config[v.id]

	if not data.initialized then
		initialise(v,data,config,settings)
	end


	npcutils.applyLayerMovement(v)


	local isPressed = false

	if v:mem(0x12C,FIELD_WORD) == 0 and not v:mem(0x136,FIELD_BOOL) and v:mem(0x138,FIELD_WORD) == 0 then
		for _,p in ipairs(Player.get()) do
			if p.deathTimer == 0 and not p:mem(0x13C,FIELD_BOOL) then
				if p.standingNPC == v or (p:isOnGround() and p.x+p.width > v.x and p.x < v.x+v.width and p.y+p.height >= v.y-0.01 and p.y+p.height <= v.y+0.1) then
					isPressed = true
					break
				end
			end
		end
	end

	if isPressed and not data.pressed then
		-- Just got onto platform
		SFX.play(config.pressedSound)
	elseif not isPressed and data.pressed then
		-- Just got off of platform
		data.counter = data.counter - 1

		if data.counter > 0 then
			SFX.play(config.countdownSound)
		else
			v:kill(HARM_TYPE_VANISH)

			SFX.play(config.disappearSound)

			Effect.spawn(config.disappearEffect,v.x + v.width*0.5,v.y + v.height*0.5)
		end
	end

	data.pressed = isPressed

	handleAnimation(v,data,config)
end


local lowPriorityStates = table.map{1,3,4}

function numberPlatform.onDrawNPC(v)
	if v.despawnTimer <= 0 or v.isHidden then return end

	local config = NPC.config[v.id]
	local data = v.data

	local settings = v.data._settings

	if not data.initialized then
		initialise(v,data,config,settings)
	end


	local texture = Graphics.sprites.npc[v.id].img
	if texture == nil then
		return
	end


	local priority = -45
	if lowPriorityStates[v:mem(0x138,FIELD_WORD)] then
		priority = -75
	elseif v:mem(0x12C,FIELD_WORD) > 0 then
		priority = -30
	elseif config.foreground then
		priority = -15
	end

	npcutils.drawNPC(v,{frame = v.animationFrame,priority = priority})

	-- Draw number
	local text = tostring(math.max(1,data.counter))
	local textWidth = (#text - 1)*config.numberGap + config.numberWidth

	local frameOffset = npcutils.getTotalFramesByFramestyle(v)

	local textColor = config.numberColors[math.clamp(data.counter,1,#config.numberColors)]

	for i = 1,#text do
		local frame = string.byte(text[i]) - 48 + frameOffset

		local width = config.gfxwidth
		local height = config.gfxheight

		local x = v.x + v.width*0.5 - width*0.25 + config.gfxoffsetx - textWidth*0.5 + (i-1)*config.numberGap
		local y = v.y + v.height - height + config.gfxoffsety

		Graphics.drawBox{
			texture = texture,priority = priority,color = textColor,sceneCoords = true,
			x = x,y = y,width = width,height = height,
			sourceX = 0,sourceY = frame*height,
			sourceWidth = width,sourceHeight = height,
		}
	end


	npcutils.hideNPC(v)
end


return numberPlatform