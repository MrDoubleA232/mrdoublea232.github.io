--[[

	Written by MrDoubleA
	Please give credit!

	Sprite and concept by Sonikku: https://www.smwcentral.net/?p=section&a=details&id=25408

    Part of MrDoubleA's NPC Pack

]]

local npcManager = require("npcManager")
local npcutils = require("npcs/npcutils")

local slopedMole = {}


slopedMole.idList = {}
slopedMole.idMap  = {}


function slopedMole.register(npcID)
	npcManager.registerEvent(npcID, slopedMole, "onTickNPC")

    table.insert(slopedMole.idList,npcID)
    slopedMole.idMap[npcID] = true
end


slopedMole.activeInstances = {}


local function initialise(v,data,config)
    -- Create block
    if data.block ~= nil and data.block.isValid then
        data.block:delete()
    end

    v.collisionGroup = "slopedMole ".. v.uid

    data.block = Block.spawn(config.blockID,v.x,v.y)
    data.block.width = v.width
    data.block.height = v.height - config.blockOffset
    data.block.collisionGroup = v.collisionGroup

    table.insert(slopedMole.activeInstances,{v,data.block})

    data.initialized = true
end


local function getSlopeBlockCollider(block)
    if Block.SLOPE_LR_FLOOR_MAP[block.id] then
        return Colliders.Tri(block.x,block.y, {4,block.height}, {block.width - 4,block.height}, {block.width - 4,8})
    elseif Block.SLOPE_RL_FLOOR_MAP[block.id] then
        return Colliders.Tri(block.x,block.y, {block.width - 4,block.height}, {4,block.height}, {4,8})
    end
end


function slopedMole.onTickNPC(v)
	if Defines.levelFreeze then return end
	
	local data = v.data
	
	if v.despawnTimer <= 0 then
        data.initialized = false
		return
	end

    local config = NPC.config[v.id]

	if not data.initialized then
		initialise(v,data,config)
	end

    if v:mem(0x12C,FIELD_WORD) == 0 then
        if v.speedX >= config.speed then -- slow down
            v.speedX = math.max(config.speed,v.speedX - config.deceleration)
        elseif v.speedX <= -config.speed then -- slow down
            v.speedX = math.min(-config.speed,v.speedX + config.deceleration)
        elseif not v:mem(0x136,FIELD_BOOL) then -- normal speed
            v.speedX = config.speed*v.direction
        end
    end

	if data.block ~= nil and data.block.isValid then
        if v:mem(0x12C,FIELD_WORD) == 0 and not v:mem(0x136,FIELD_BOOL) then
            if player.keys.dropItem then
                v.speedY = -8
            end

            local speedX = v.speedX
            local speedY = v.speedY

            if v.dontMove then
                speedX = 0
            end

            speedX = speedX + v:mem(0x5C,FIELD_FLOAT)

            data.block:translate((v.x + speedX) - data.block.x,(v.y + speedY) - data.block.y)
            data.block.speedX = speedX
            data.block.speedY = speedY
            data.block.isHidden = false

            -- Fix some collision bugs with moving slopes
            local harmCollider = getSlopeBlockCollider(data.block)

            harmCollider.y = harmCollider.y - math.min(0,speedY)

            for _,p in ipairs(Player.get()) do
                if p:mem(0x48,FIELD_WORD) == data.block.idx then
                    p.speedY = math.abs(p.speedX + speedX)*(data.block.height/data.block.width)*4 + 4 + speedY
                elseif Colliders.collide(p,harmCollider) then
                    p:harm()
                end
            end

            --Colliders.getHitbox(data.block):draw()
            --harmCollider:draw(Color.red.. 0.8)
        else
            data.block.isHidden = true
        end
    end
end


local hiddenBlocks = {}

function slopedMole.onTick()
    for i = #slopedMole.activeInstances, 1, -1 do
        local instance = slopedMole.activeInstances[i]
        local v = instance[1]
        local b = instance[2]

        if not v.isValid or not b.isValid or not slopedMole.idMap[v.id] or v.despawnTimer <= 0 then
            if b.isValid then
                b:delete()
            end

            table.remove(slopedMole.activeInstances,i)
        end
    end
end

function slopedMole.onDraw()
    for _,instance in ipairs(slopedMole.activeInstances) do
        local v = instance[1]
        local b = instance[2]

        if b.isValid and not b.isHidden then
            table.insert(hiddenBlocks,b)
            b.isHidden = true
        end
    end
end

function slopedMole.onDrawEnd()
    for i = 1,#hiddenBlocks do
        local b = hiddenBlocks[i]

        if b.isValid then
            b.isHidden = false
        end

        hiddenBlocks[i] = nil
    end
end


function slopedMole.onInitAPI()
    registerEvent(slopedMole,"onTick")
    registerEvent(slopedMole,"onDraw")
    registerEvent(slopedMole,"onDrawEnd")
end


return slopedMole