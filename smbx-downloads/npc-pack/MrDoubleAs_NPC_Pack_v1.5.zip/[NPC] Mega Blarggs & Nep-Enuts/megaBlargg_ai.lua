--[[

	Written by MrDoubleA
	Please give credit!

    Part of MrDoubleA's NPC Pack

]]

local npcManager = require("npcManager")
local npcutils = require("npcs/npcutils")

local megaBlargg = {}


local DEBUG_MODE = {
	DISABLED      = 0,
	SHAPE_TEST    = 1,
	RENDER_TEST   = 2,
	COLLIDER_TEST = 3,
}

local STATE = {
	HIDDEN    = 0,
	EMERGE    = 1,
	WAIT      = 2,
	CHASE     = 3,
	SUBMERGE  = 4,
}

local EMERGE_BEHAVIOUR = {
	COMES_CLOSE = 0,
	PASSES_BY   = 1,
	ALWAYS_OUT  = 2,
}


megaBlargg.LIQUID_TYPE = {
	LAVA = 0,
	WATER = 1,
}


megaBlargg.debugMode = DEBUG_MODE.DISABLED


local MAX_HEIGHT = 400
local RENDER_STEP = 2
local COLLIDER_STEP = 16


megaBlargg.sharedSettings = {
	gfxoffsetx = 0,
	gfxoffsety = 0,
	
	width = 256,
	height = 320,
	
	frames = 1,
	framestyle = 0,
	framespeed = 8,
	
	speed = 1,
	
	npcblock = false,
	npcblocktop = false, --Misnomer, affects whether thrown NPCs bounce off the NPC.
	playerblock = false,
	playerblocktop = false, --Also handles other NPCs walking atop this NPC.

	nohurt = true,
	nogravity = true,
	noblockcollision = true,
	nofireball = true,
	noiceball = true,
	noyoshi = true,
	nowaterphysics = true,

	ignorethrownnpcs = true,
	
	jumphurt = true,
	spinjumpsafe = false,
	harmlessgrab = false,
	harmlessthrown = false,


	idleAnimationLength = 32,

	fireballDamage = 0.2,
	iceballDamage = 0.2,
	hammerDamage = 0.4,


	aboveSubmergedDistance = 160,
	submergedHeightScale = 0.6,
	
	emergeLength = 80,


	beforeBlinkTimeMin = 24,
	beforeBlinkTimeMax = 128,
	blinkLength = 16,

	eyePositionX1 = -0.05,
	eyePositionY1 = 0.825,
	eyePositionX2 = -0.015,
	eyePositionY2 = 0.825,

	tooth1PositionX1 = -0.225,
	tooth1PositionY1 = 0.59,
	tooth1PositionX2 = -0.2,
	tooth1PositionY2 = 0.58,

	tooth2PositionX1 = 0.05,
	tooth2PositionY1 = 0.53,
	tooth2PositionX2 = 0.06,
	tooth2PositionY2 = 0.49,

	toothCount = 2,
}


megaBlargg.idList = {}
megaBlargg.idMap  = {}

function megaBlargg.register(npcID)
	npcManager.registerEvent(npcID, megaBlargg, "onTickNPC")
    npcManager.registerEvent(npcID, megaBlargg, "onDrawNPC")

	table.insert(megaBlargg.idList,npcID)
	megaBlargg.idMap[npcID] = true
end


function megaBlargg.onInitAPI()
	registerEvent(megaBlargg,"onNPCHarm")
end


function megaBlargg.harm(v,damage)
	local config = NPC.config[v.id]
	local data = v.data

	if not data.initialized then
		return
	end

	if data.flashTimer > 0 or (data.state == STATE.SUBMERGE or data.state == STATE.HIDDEN or data.state == STATE.EMERGE) then
		return
	end

	data.health = math.max(0,data.health - damage)

	if data.health >= 0.01 then
		SFX.play(9)

		data.flashTimer = 40
	else
		data.state = STATE.SUBMERGE
		data.timer = 0

		v.speedX = 0

		data.flashTimer = 80

		SFX.play(39)
	end
end


local function sinLerp(a,b,t)
	return math.lerp(a,b, math.sin(t * math.pi * 0.5))
end

function megaBlargg.generateShape(v)
    local leftList = {}
    local rightList = {}
    
    local config = NPC.config[v.id]
	local data = v.data

	local fullWidth = v.width * data.widthMultiplier
	local fullHeight = v.height * data.heightMultiplier

	local animationProgress = (data.animationTimer / config.idleAnimationLength)

    -- Generate bottom
	local bottomHeight = math.lerp(fullHeight * 0.3,fullHeight * 0.25,animationProgress)
	local bottomTopWidth = math.lerp(fullWidth*0.75,fullWidth*0.8,animationProgress)

	for i = 1, bottomHeight do
		local width = sinLerp(fullWidth,bottomTopWidth, i / bottomHeight)

		table.insert(leftList,-width*0.5)
		table.insert(rightList,width*0.5)
	end

    -- Generate mouth
	local mouthHeight = math.lerp(fullHeight * 0.35,fullHeight * 0.4,animationProgress)
	local mouthLeft = math.lerp(fullWidth * 0.19,fullWidth * 0.165,animationProgress)

	for i = 1, mouthHeight do
		--table.insert(leftList, sinLerp(-fullWidth * 0.3,mouthLeft, (i / mouthHeight)*2))
		--table.insert(leftList, math.lerp(-fullWidth * 0.3,mouthLeft,((i / mouthHeight) ^ 2)	))
		local a = ((i - 1)/mouthHeight - 0.5) * 2

		table.insert(leftList, math.lerp(mouthLeft,-fullWidth*0.3,a*a))
		table.insert(rightList, sinLerp(bottomTopWidth,fullWidth*0.6, i / mouthHeight) * 0.5)
	end

	-- Generate lip(?)
	local lipHeight = math.lerp(fullHeight * 0.075,fullHeight * 0.05,animationProgress)
	local lipOffset = math.lerp(0,fullHeight*0.035,animationProgress)

	for i = 1, lipHeight do
		table.insert(leftList, sinLerp(-fullWidth*0.35 + lipOffset,-fullWidth*0.37 + lipOffset, (i / lipHeight) * 2))
		table.insert(rightList, sinLerp(fullWidth*0.24,fullWidth*0.6*0.5, 1 - (i / lipHeight)))
	end

	-- Generate head
	local headHeight = math.lerp(fullHeight * 0.075,fullHeight * 0.1,animationProgress)

	for i = 1, headHeight do
		table.insert(leftList, sinLerp(-fullWidth*0.125,-fullWidth*0.35 + lipOffset, 1 - (i / headHeight)))
		table.insert(rightList, sinLerp(fullWidth*0.08,fullWidth*0.24, 1 - (i / headHeight)))
	end

	

	if data.submergedDistance > 0 then
		for index,left in ipairs(leftList) do
			local newIndex = index + math.floor(data.submergedDistance + 0.5)

			leftList[index] = leftList[newIndex]
			rightList[index] = rightList[newIndex]
		end
	end


    return leftList,rightList
end


function megaBlargg.generateCollider(v)
	local data = v.data


	data.leftList,data.rightList = megaBlargg.generateShape(v)


	local actualHeight = #data.leftList
	
	local points = {}
	local rightPoints = {}

	local pointCount = 0

	if actualHeight > 0 then
		local totalLength = math.ceil(actualHeight / COLLIDER_STEP) * COLLIDER_STEP

		for y = 0, totalLength, COLLIDER_STEP do
			local actualY = math.min(actualHeight,y + 1)

			local left = data.leftList[actualY]
			local right = data.rightList[actualY]

			points[pointCount + 1] = {left,-actualY}
			rightPoints[pointCount + 1] = {right,-actualY}

			pointCount = pointCount + 1
		end

		-- Append the right list to the left one
		for i = pointCount, 1, -1 do
			points[pointCount + 1] = rightPoints[i]
			pointCount = pointCount + 1
		end
	else
		for i = 1,3 do
			table.insert(points,{0,0})
			pointCount = pointCount + 1
		end
	end


	return Colliders.Poly(v.x + v.width*0.5,v.y + v.height,table.unpack(points))
end


local function doSubmergeStuff(v,data,config,t)
	data.submergedDistance = math.lerp(v.height - config.aboveSubmergedDistance,0, t)
	data.heightMultiplier = math.lerp(0.7,1, t)
end

local function canContinueMoving(v,data,config)
	local col = Colliders.getHitbox(v)

	col.height = 8
	col.y = col.y + v.height - col.height

	col.width = 1

	if v.direction == DIR_LEFT then
		col.x = v.x - col.width
	else
		col.x = v.x + v.width
	end

	
	if config.liquidType == megaBlargg.LIQUID_TYPE.LAVA then
		local blocks = Colliders.getColliding{a = col,b = Block.LAVA,btype = Colliders.BLOCK}

		if #blocks > 0 then
			return true
		end
	elseif config.liquidType == megaBlargg.LIQUID_TYPE.WATER then
		for _,liquid in ipairs(Liquid.getIntersecting(col.x,col.y,col.x+col.width,col.y+col.height)) do
			if not liquid.isHidden and not liquid.isQuicksand then
				return true
			end
		end	
	end


	-- Not in anything
	return false
end



local function initialize(v,data,config,settings)
	data.initialized = true


	data.widthMultiplier = -v.direction
	data.heightMultiplier = 1


	if settings.emergeBehaviour == EMERGE_BEHAVIOUR.ALWAYS_OUT then
		data.state = STATE.WAIT
		data.timer = 0

		if v.despawnTimer > 100 then
			SFX.play(config.emergeSound)
		end

		doSubmergeStuff(v,data,config,1)
	else
		data.state = STATE.HIDDEN
		data.timer = 0

		doSubmergeStuff(v,data,config,0)
	end

	data.playerApproachSide = 0


	data.flashTimer = 0


	data.animationTimer = 0
	data.animationDirection = 1
	data.animationSpeed = 1

	data.blinkWaitTimer = RNG.randomInt(config.beforeBlinkTimeMin,config.beforeBlinkTimeMax)
	data.blinkTimer = 0

	data.eyeFrame = 1


	data.collider = megaBlargg.generateCollider(v)

	data.health = settings.health

	v.section = Section.getIdxFromCoords(v) -- redigit
end


function megaBlargg.onTickNPC(v)
	if Defines.levelFreeze then return end
	
	local data = v.data
	
	if v.despawnTimer <= 0 then
		data.initialized = false
		return
	end

	local config = NPC.config[v.id]
	local settings = v.data._settings

	if not data.initialized then
		initialize(v,data,config,settings)
	end



	data.widthMultiplier = -v.direction



	-- State behaviour
	if data.state == STATE.HIDDEN then
		local emerge = false
		
		data.animationSpeed = 0.5

		for _,p in ipairs(Player.get()) do
			local distance = (p.x + p.width*0.5) - (v.x + v.width*0.5)

			local isClose = (math.abs(distance) <= settings.nearbyDistance)

			if settings.emergeBehaviour == EMERGE_BEHAVIOUR.COMES_CLOSE then
				if isClose then
					emerge = true

					v.direction = math.sign(distance)

					break
				end
			elseif settings.emergeBehaviour == EMERGE_BEHAVIOUR.PASSES_BY then
				if data.playerApproachSide == 0 and isClose then
					data.playerApproachSide = math.sign(distance)
				elseif data.playerApproachSide == -math.sign(distance) and not isClose then
					emerge = true

					v.direction = math.sign(distance)

					break
				end
			end
		end


		if data.timer > 0 then
			data.timer = data.timer - 1

			emerge = (data.timer == 0)
		end


		if emerge then
			data.state = STATE.EMERGE
			data.timer = 0

			SFX.play(config.emergeSound)
		end
	elseif data.state == STATE.EMERGE then
		data.timer = data.timer + 1
		data.animationSpeed = 2

		local t = math.clamp(data.timer / config.emergeLength)

		doSubmergeStuff(v,data,config,t)

		if t >= 1 then
			data.state = STATE.WAIT
			data.timer = 12
		end
	elseif data.state == STATE.SUBMERGE then
		data.timer = data.timer + 1
		data.animationSpeed = 0.6

		local t = 1 - math.clamp(data.timer / config.emergeLength)

		doSubmergeStuff(v,data,config,t)

		if t <= 0 then
			data.state = STATE.HIDDEN

			data.health = settings.health

			data.playerApproachSide = 0

			if settings.emergeBehaviour == EMERGE_BEHAVIOUR.ALWAYS_OUT then
				data.timer = 64
			else
				data.timer = 0
			end
		end
	elseif data.state == STATE.WAIT then
		data.timer = data.timer - 1

		data.animationSpeed = 1

		if data.timer <= 0 then
			data.state = STATE.CHASE
			data.timer = 0

			local p = npcutils.getNearestPlayer(v)
			
			v.direction = math.sign((p.x + p.width*0.5) - (v.x + v.width*0.5))

			if v.direction == 0 then
				if p.speedX ~= 0 then
					v.direction = math.sign(p.speedX)
				else
					v.direction = RNG.irandomEntry{DIR_LEFT,DIR_RIGHT}
				end
			end

			if canContinueMoving(v,data,config) then
				v.speedX = v.direction * settings.chaseSpeed
			else
				v.speedX = 0
			end
		end
	elseif data.state == STATE.CHASE then
		data.animationSpeed = 1.25

		if canContinueMoving(v,data,config) or v.speedX == 0 then
			local shouldSubmerge = true

			for _,p in ipairs(Player.get()) do
				local distance = (p.x + p.width*0.5) - (v.x + v.width*0.5)

				if math.sign(distance) == v.direction or math.abs(distance) < settings.nearbyDistance then
					shouldSubmerge = false
					break
				end
			end

			if shouldSubmerge then
				data.state = STATE.SUBMERGE
				data.timer = 0

				v.speedX = 0
			end
		else
			v.speedX = 0
		end
	end



	-- Idle animation
	data.animationTimer = data.animationTimer + data.animationDirection*data.animationSpeed

	if (data.animationDirection == 1 and data.animationTimer >= config.idleAnimationLength) or (data.animationDirection == -1 and data.animationTimer <= 0) then
		data.animationDirection = -data.animationDirection
	end

	-- Eye animations
	data.blinkWaitTimer = math.max(0,data.blinkWaitTimer - 1)

	if data.blinkWaitTimer <= 0 then
		local frames = (config.eyeFrames * 2) - 3

		data.eyeFrame = math.floor((data.blinkTimer / config.blinkLength) * frames) + 1
		if data.eyeFrame >= (config.eyeFrames + 1) then
			data.eyeFrame = data.eyeFrame - (data.eyeFrame - config.eyeFrames) - 1
		end

		if data.blinkTimer >= config.blinkLength then
			data.blinkWaitTimer = RNG.randomInt(config.beforeBlinkTimeMin,config.beforeBlinkTimeMax)
			data.blinkTimer = 0
		else
			data.blinkTimer = data.blinkTimer + 1
		end
	else
		data.eyeFrame = 1
	end


	data.flashTimer = math.max(0,data.flashTimer - 1)


	-- Collider stuff
	data.collider = megaBlargg.generateCollider(v)

	-- Hurt player
	for _,p in ipairs(Player.get()) do
		if data.collider:collide(p) then
			p:harm()
		end
	end

	-- Hurt NPC's
	local npcs = Colliders.getColliding{a = data.collider,btype = Colliders.NPC}

	for _,npc in ipairs(npcs) do
		if v ~= npc and npc:mem(0x136,FIELD_BOOL) then
			if npc.id == 13 then -- fireball
				megaBlargg.harm(v,config.fireballDamage)
				npc:harm(HARM_TYPE_PROJECTILE_USED)
			elseif npc.id == 265 then -- iceball
				megaBlargg.harm(v,config.iceballDamage)
				npc:harm(HARM_TYPE_PROJECTILE_USED)
			elseif npc.id == 171 then
				megaBlargg.harm(v,config.hammerDamage)
			else
				if NPC.SHELL_MAP[npc.id] then
					npc:harm(HARM_TYPE_NPC)
				else
					npc:harm(HARM_TYPE_PROJECTILE_USED)
				end

				megaBlargg.harm(v,1)
			end
		end
	end
end


local bodyShader = Shader()
bodyShader:compileFromFile(nil, Misc.resolveFile("megaBlargg_body.frag"), {MAX_HEIGHT = MAX_HEIGHT,RENDER_STEP = RENDER_STEP})

local function drawDebug(v,leftList,rightList,x,y)
	for index,left in ipairs(leftList) do
		local right = rightList[index]

		local color = Color.blue

		if left > right then
			color = Color.red
		end

		Graphics.drawBox{x = v.x + v.width*0.5 + left + x,y = v.y + v.height - (index - 1) + y,width = -left + right,height = 1,color = color.. 0.5,sceneCoords = true}
	end
end

function megaBlargg.onDrawNPC(v)
    if v.despawnTimer <= 0 or v.isHidden then return end

	local config = NPC.config[v.id]
	local data = v.data

	if not data.initialized then
		initialize(v,data,config,v.data._settings)
	end


    local leftList,rightList = megaBlargg.generateShape(v)


	if megaBlargg.debugMode == DEBUG_MODE.SHAPE_TEST then
		drawDebug(v,leftList,rightList,0,0)
		return
	elseif megaBlargg.debugMode == DEBUG_MODE.RENDER_TEST then
		drawDebug(v,leftList,rightList,v.width,0)
	elseif megaBlargg.debugMode == DEBUG_MODE.COLLIDER_TEST then
		data.collider:Draw(Color.blue.. 0.8)
	end


	local priority = -86
	local animationProgress = (data.animationTimer / config.idleAnimationLength)


	-- Draw teeth
	data.toothSprites = data.toothSprites or {}

	for i = 1, config.toothCount do
		if data.toothSprites[i] == nil then
			data.toothSprites[i] = Sprite{texture = config.toothImage,pivot = Sprite.align.TOP}
		end

		local sprite = data.toothSprites[i]

		sprite.x = v.x + v.width*0.5                                            + math.lerp(config["tooth".. i.. "PositionX1"],config["tooth".. i.. "PositionX2"],animationProgress)*v.width *data.widthMultiplier
		sprite.y = v.y + v.height  + data.submergedDistance - sprite.height*0.5 - math.lerp(config["tooth".. i.. "PositionY1"],config["tooth".. i.. "PositionY2"],animationProgress)*v.height*data.heightMultiplier

		sprite:draw{priority = priority,sceneCoords = true}
	end


	-- Change the left/right lists so that they can be passed into the shader
	for i = #leftList + 1, MAX_HEIGHT do
		leftList[i] = 0
		rightList[i] = 0
	end

	for i = MAX_HEIGHT + 1, #leftList do
		leftList[i] = nil
		rightList[i] = nil
	end


	-- Draw body
	local npcWidth = (v.width * math.abs(data.widthMultiplier))

	Graphics.drawBox{
		texture = config.bodyImage,priority = priority,sceneCoords = true,
		x = v.x + v.width*0.5 - npcWidth*0.5,y = v.y + v.height - MAX_HEIGHT,
		width = npcWidth,height = MAX_HEIGHT,sourceWidth = npcWidth,sourceHeight = MAX_HEIGHT,
		shader = bodyShader,uniforms = {
			leftList = leftList,rightList = rightList,

			bodyImageSize = vector(config.bodyImage.width,config.bodyImage.height),
			npcWidth = npcWidth,

			flash = (((data.flashTimer % 8) >= 2) and 1) or 0,
		},
	}

    -- Draw eyes
	if data.eyeSprite == nil then
		data.eyeSprite = Sprite{texture = config.eyesImage,frames = config.eyeFrames,pivot = Sprite.align.CENTRE}
	end

	data.eyeSprite.x = v.x + v.width*0.5                          + math.lerp(config.eyePositionX1,config.eyePositionX2,animationProgress)*v.width *data.widthMultiplier
	data.eyeSprite.y = v.y + v.height    + data.submergedDistance - math.lerp(config.eyePositionY1,config.eyePositionY2,animationProgress)*v.height*data.heightMultiplier

	data.eyeSprite:draw{frame = data.eyeFrame,priority = priority,sceneCoords = true}
end


function megaBlargg.onNPCHarm(eventObj,v,reason,culprit)
	if not megaBlargg.idMap[v.id] then return end

	if culprit ~= nil then
		local data = v.data

		if data.initialized and not data.collider:collide(culprit) then
			eventObj.cancelled = true
			return
		end
	end

	megaBlargg.harm(v,1)
	eventObj.cancelled = true
end


return megaBlargg