--[[

	Written by MrDoubleA
	Please give credit!

    Part of MrDoubleA's NPC Pack

]]

local npcManager = require("npcManager")
local npcutils = require("npcs/npcutils")

local lamp = {}
local npcID = NPC_ID

local lampSettings = {
	id = npcID,
	
	gfxwidth = 16,
	gfxheight = 16,

	gfxoffsetx = 0,
	gfxoffsety = 0,
	
	width = 16,
	height = 16,
	
	frames = 3,
	framestyle = 0,
	framespeed = 8,
	
	speed = 1,
	
	npcblock = false,
	npcblocktop = false, --Misnomer, affects whether thrown NPCs bounce off the NPC.
	playerblock = false,
	playerblocktop = false, --Also handles other NPCs walking atop this NPC.

	nohurt = true,
	nogravity = false,
	noblockcollision = false,
	nofireball = true,
	noiceball = true,
	noyoshi = true,
	nowaterphysics = true,
	ignorethrownnpcs = true,
	notcointransformable = true,
	
	jumphurt = true,
	spinjumpsafe = false,
	harmlessgrab = false,
	harmlessthrown = false,

	
	lightradius = 128,
	lightbrightness = 2,
	lightoffsetx = 0,
	lightoffsety = 0,
	lightcolor = Color.fromHexRGB(0xF88010),
	lightflicker = true,



	swingSounds = { -- The sound played while the lamp is swinging. Can be nil for none, a number for a vanilla sound, a sound effect object/string for a custom sound, or a table containing sound effects.
		SFX.open(Misc.resolveSoundFile("lamp_swing_1")),
		SFX.open(Misc.resolveSoundFile("lamp_swing_2")),
		SFX.open(Misc.resolveSoundFile("lamp_swing_3")),
		SFX.open(Misc.resolveSoundFile("lamp_swing_4")),
		SFX.open(Misc.resolveSoundFile("lamp_swing_5")),
		SFX.open(Misc.resolveSoundFile("lamp_swing_6")),
		SFX.open(Misc.resolveSoundFile("lamp_swing_7")),
	},
	hitSounds = { -- The sound played when the lamp gets hit. Can be nil for none, a number for a vanilla sound, a sound effect object/string for a custom sound, or a table containing sound effects.
		SFX.open(Misc.resolveSoundFile("lamp_hit_1")),
		SFX.open(Misc.resolveSoundFile("lamp_hit_2")),
		SFX.open(Misc.resolveSoundFile("lamp_hit_3")),
		SFX.open(Misc.resolveSoundFile("lamp_hit_4")),
		SFX.open(Misc.resolveSoundFile("lamp_hit_5")),
	},

	hitBlockSound = 3, -- The sound played when a block is hit. Can be nil for none, a number for a vanilla sound, a sound effect object/string for a custom sound, or a table containing sound effects.
}

npcManager.setNpcSettings(lampSettings)
npcManager.registerHarmTypes(npcID,{HARM_TYPE_OFFSCREEN},{})


local function playSFX(sfx,volume)
	if type(sfx) == "table" then
		return playSFX(RNG.irandomEntry(sfx),volume)
	else
		return SFX.play(sfx,volume)
	end
end


local colBox = Colliders.Box(0,0,0,0)
local function findBlockBottom(block,position)
	if (not Block.SOLID_MAP[block.id] and not Block.SEMISOLID_MAP[block.id]) or Block.SIZEABLE_MAP[block.id] then
		return nil
	end


	local slopeDirection = Block.config[block.id].ceilingslope

	if slopeDirection ~= 0 then
		local distanceFromTip = ((block.x+(block.width/2))-((block.width/2)*slopeDirection))-position

		return block.y+(math.clamp(math.abs(distanceFromTip)/block.width,0,1)*block.height)
	end

	if Block.SEMISOLID_MAP[block.id] then
		return block.y+(block.height*0.25)
	end


	return block.y+block.height
end

local function findBlock(v)
	local data = v.data

	local sectionTop = v.sectionObj.origBoundary.top
	local lowestBlock,lowestBlockBottom

	colBox.x = v.x+(v.width/2)
	colBox.y = sectionTop
	colBox.width = 0.01
	colBox.height = (v.y-sectionTop)


	for _,block in ipairs(Colliders.getColliding{a = colBox,btype = Colliders.BLOCK}) do
		local bottom = findBlockBottom(block,v.x+(v.width/2))

		if bottom ~= nil and (lowestBlock == nil or bottom > lowestBlockBottom) then
			lowestBlock = block
			lowestBlockBottom = bottom
		end
	end


	if lowestBlock ~= nil then
		data.block = lowestBlock
		data.anchor = vector(v.x+(v.width/2),lowestBlockBottom)

		v.layerName = lowestBlock.layerName
	else
		data.block = nil
		data.anchor = vector(v.x+(v.width/2),sectionTop)
	end

	data.length = math.max(0,(v.y+(v.height/2))-data.anchor.y)
end


local function initialise(v,data)
	if data.animationTimer then return end

	data.sideOfAnchor = 0
	data.animationTimer = 0

	data.canBeHit = true

	-- Find a block to hang on to
	findBlock(v)
end

local function collidingWithBlock(v,includeBottom)
	return (
		   v:mem(0x0C,FIELD_WORD) > 0 -- Left
		or v:mem(0x0E,FIELD_WORD) > 0 -- Above
		or v:mem(0x10,FIELD_WORD) > 0 -- Right
		or (v:mem(0x0E,FIELD_WORD) > 0 and includeBottom)) -- Below
end


local function hitNPC(v,culprit)
	local config = NPC.config[v.id]
	local data = v.data

	if not data.canBeHit then
		return
	end

	
	local speed = 0
	if culprit == nil then
		speed = 4*v.direction
	elseif math.abs(culprit.speedX) >= 1 then
		speed = culprit.speedX
	end

	v.speedX = (speed/64)*math.min(96,data.length)
	playSFX(config.hitSounds,0.25)

	data.canBeHit = false -- The lamp cannot be hit again until it swings at least once
end



function lamp.onInitAPI()
	npcManager.registerEvent(npcID,lamp,"onTickEndNPC")
	npcManager.registerEvent(npcID,lamp,"onDrawNPC")
end

function lamp.onTickEndNPC(v)
	if Defines.levelFreeze then return end
	
	local config = NPC.config[v.id]
	local data = v.data
	
	if v.despawnTimer <= 0 or v.isHidden then
		data.animationTimer = nil
		return
	end

	initialise(v,data)

	--[[if v:mem(0x12C, FIELD_WORD) > 0    --Grabbed
	or v:mem(0x136, FIELD_BOOL)        --Thrown
	or v:mem(0x138, FIELD_WORD) > 0    --Contained within
	then return end]]
	
	-- Update anchor position
	local layerSpeed = vector(npcutils.getLayerSpeed(v))

	--npcutils.applyLayerMovement(v)
	data.anchor = data.anchor + layerSpeed


	-- Get knocked around by the player
	local distance = vector(v.x+v.width*0.5, v.y+v.height*0.5)-data.anchor
	local speed = vector(v.speedX, v.speedY)
	if (distance+speed).length > data.length and not collidingWithBlock(v,true) then
		speed = ((distance+speed):normalise()*data.length)-distance
		v.speedX = speed.x
		v.speedY = speed.y
	end

	v.speedX = v.speedX * (1-(1/data.length))


	for _,p in ipairs(Player.get()) do
		if (p.deathTimer == 0 and not player:mem(0x13C,FIELD_BOOL)) and Colliders.collide(v,p) then
			hitNPC(v,p)
		end
	end


	-- Sounds
	local sideOfAnchor = math.sign(distance.x)

	if sideOfAnchor ~= data.sideOfAnchor then
		data.sideOfAnchor = sideOfAnchor
		data.canBeHit = true

		if math.abs(v.speedX) > 0.1 then
			playSFX(config.swingSounds,math.min(0.75,math.abs(v.speedX)*2))
		end
	end

	if (not config.noblockcollision and not v.noblockcollision) and collidingWithBlock(v,false) then
		playSFX(config.hitBlockSound,0.5)
	end

	-- Make other NPCs not bounce off of the lamp
	if v:mem(0x120,FIELD_BOOL) and (not v.collidesBlockLeft and not v.collidesBlockRight) then -- Hit an NPC
		if v.direction == DIR_LEFT then
			colBox.x = (v.x-1)+v.speedX
		else
			colBox.x = (v.x+v.width)+v.speedX
		end
		colBox.y = v.y
		colBox.width = 1
		colBox.height = v.height

		for _,npc in ipairs(Colliders.getColliding{a = colBox,btype = Colliders.NPC}) do
			npc:mem(0x120,FIELD_BOOL,false)
		end

		v:mem(0x120,FIELD_BOOL,false)
	end


	data.animationTimer = data.animationTimer + 1
	v.animationFrame = math.floor(data.animationTimer/config.framespeed)%(config.frames/3)
end


--[[function lamp.onNPCHarm(eventObj,v,reason,culprit)
	if v.id ~= npcID or reason == HARM_TYPE_OFFSCREEN then return end

	hitNPC(v,culprit)

	eventObj.cancelled = true
end]]


-- Drawing stuff
do
	local tableinsert = table.insert
	local function tableMultiInsert(tbl,...)
		for _,value in ipairs{...} do
			tableinsert(tbl,value)
		end
	end


	local v2mt = getmetatable(vector.zero2)
	local function fastv2(x,y)
		return setmetatable({x,y},v2mt)
	end

	local function addElement(v,vertexCoords,textureCoords,type,distance,cutoff,rotation)
		if cutoff <= 0 then return end

		local config = NPC.config[v.id]
		local data = v.data

		local totalFrames = npcutils.getTotalFramesByFramestyle(v)
		local width,height = config.gfxwidth,(config.gfxheight*cutoff)

		local horizontal = fastv2(1,0):rotate(rotation)
		local vertical   = fastv2(0,1):rotate(rotation)

		local topLeft     = (data.anchor-(horizontal*width*0.5)+(vertical*(distance       )))
		local topRight    = (data.anchor+(horizontal*width*0.5)+(vertical*(distance       )))
		local bottomLeft  = (data.anchor-(horizontal*width*0.5)+(vertical*(distance+height)))
		local bottomRight = (data.anchor+(horizontal*width*0.5)+(vertical*(distance+height)))

		tableMultiInsert(vertexCoords,
			topLeft.x    ,topLeft.y    , -- top left
			topRight.x   ,topRight.y   , -- top right
			bottomLeft.x ,bottomLeft.y , -- bottom left
			bottomLeft.x ,bottomLeft.y , -- bottom left
			topRight.x   ,topRight.y   , -- top right
			bottomRight.x,bottomRight.y  -- bottom right
		)

		local frame = (v.animationFrame+(config.frames*(type/3)))

		local sourceTop    = (frame/totalFrames)
		local sourceBottom = ((frame+cutoff)/totalFrames)

		tableMultiInsert(textureCoords,
			0,sourceTop   , -- top left
			1,sourceTop   , -- top right
			0,sourceBottom, -- bottom left
			0,sourceBottom, -- bottom left
			1,sourceTop   , -- top right
			1,sourceBottom  -- bottom right
		)
	end

	local function getVertexCoords(v)
		local config = NPC.config[v.id]
		local data = v.data

		local distance = (data.anchor-vector(v.x+(v.width/2),v.y+(v.height/2)))
		local rotation = math.deg(math.atan2(distance.y,distance.x))+90


		local vertexCoords,textureCoords = {},{}

		-- Chain
		for step=0,(distance.length/config.gfxheight) do
			local cutoff = math.min(1,(distance.length/config.gfxheight)-step)

			addElement(v,vertexCoords,textureCoords,2,step*config.gfxheight,cutoff,rotation)
		end

		-- The lamp itself
		addElement(v,vertexCoords,textureCoords,0,distance.length-(config.gfxheight/2),1,rotation)

		-- The "anchor"(?)
		if data.block ~= nil and not Block.SEMISOLID_MAP[data.block.id] then
			addElement(v,vertexCoords,textureCoords,1,0,1,0)
		end

		return vertexCoords,textureCoords
	end

	function lamp.onDrawNPC(v)
		if v.despawnTimer <= 0 or v.isHidden then return end

		local config = NPC.config[v.id]
		local data = v.data

		initialise(v,data)

		local vertexCoords,textureCoords = getVertexCoords(v)
		local priority = (config.foreground and -15) or -75

		Graphics.glDraw{
			texture = Graphics.sprites.npc[v.id].img,
			vertexCoords = vertexCoords,
			textureCoords = textureCoords,
			priority = priority-0.01,
			sceneCoords = true,
		}

		npcutils.hideNPC(v)
	end
end

return lamp