--[[

	Written by MrDoubleA
	Please give credit!

	Part of MrDoubleA's NPC Pack

]]

local blockManager = require("blockManager")
local ai = require("crumblingBlock_ai")

local crumblingBlock = {}
local blockID = BLOCK_ID


local effectID = (blockID - 1)


local crumblingBlockSettings = table.join({
	id = blockID,

	outlineImage = Graphics.loadImageResolved("crumblingBlock_outline_vertical.png"),
	isVertical = true,

	effectID = effectID,
},ai.sharedSettings)

blockManager.setBlockSettings(crumblingBlockSettings)

ai.register(blockID)

return crumblingBlock