--[[

	Written by MrDoubleA
	Please give credit!

	Sprites made by Askywalker: https://www.spriters-resource.com/custom_edited/mariocustoms/sheet/132423/

    Part of MrDoubleA's NPC Pack

]]

local npcManager = require("npcManager")
local npcutils = require("npcs/npcutils")

local blockutils = require("blocks/blockutils")
local whistle = require("npcs/ai/whistle")


local blockhopper = {}
local npcID = NPC_ID

local blockhopperSettings = {
	id = npcID,
	
	gfxwidth = 36,
	gfxheight = 16,

	gfxoffsetx = 0,
	gfxoffsety = 0,
	
	width = 32,
	height = 32,
	
	frames = 8,
	framestyle = 1,
	framespeed = 8,
	
	speed = 1,
	
	npcblock = false,
	npcblocktop = false, --Misnomer, affects whether thrown NPCs bounce off the NPC.
	playerblock = false,
	playerblocktop = false, --Also handles other NPCs walking atop this NPC.

	nohurt = false,
	nogravity = false,
	noblockcollision = false,
	nofireball = false,
	noiceball = false,
	noyoshi = false,
	nowaterphysics = false,
	
	jumphurt = false,
	spinjumpsafe = false,
	harmlessgrab = false,
	harmlessthrown = false,


	feetHitboxHeight = 12,
	headHitboxHeight = 8,

	footWalkExtraOffsets = {[2] = -2,[4] = -2},
	footWalkOffset = 2,
	footGFXOffsetX = 0,
	footGFXOffsetY = 2,
	
	forwardAngle = 12,
	turnSpeed = 4,

	wakeJumpSpeed = -5,

	walkSpeed = 1.2,

	preJumpTime = 16,
	preJumpSquash = 0.25,

	headFrontFrames     = 1,
	headFrontFrameSpeed = 8,
	headSideFrames      = 1,
	headSideFrameSpeed  = 8,
	feetFrontFrames     = 1,
	feetFrontFrameSpeed = 8,
	feetWalkFrames      = 4,
	feetWalkFrameSpeed  = 8,
	feetAirFrames       = 1,
	feetAirFrameSpeed   = 8,

	blockFillColor = Color.fromHexRGB(0x000000),
	
	priority = -46,
	--priority = -22,
}

npcManager.setNpcSettings(blockhopperSettings)
npcManager.registerHarmTypes(npcID,
	{
		HARM_TYPE_JUMP,
		--HARM_TYPE_FROMBELOW,
		HARM_TYPE_NPC,
		HARM_TYPE_PROJECTILE_USED,
		HARM_TYPE_LAVA,
		HARM_TYPE_HELD,
		--HARM_TYPE_TAIL,
		HARM_TYPE_SPINJUMP,
		--HARM_TYPE_OFFSCREEN,
		--HARM_TYPE_SWORD,
	},
	{
		--[HARM_TYPE_JUMP]            = 10,
		--[HARM_TYPE_FROMBELOW]       = 10,
		--[HARM_TYPE_NPC]             = 10,
		--[HARM_TYPE_PROJECTILE_USED] = 10,
		--[HARM_TYPE_LAVA]            = {id=13, xoffset=0.5, xoffsetBack = 0, yoffset=1, yoffsetBack = 1.5},
		--[HARM_TYPE_HELD]            = 10,
		--[HARM_TYPE_TAIL]            = 10,
		--[HARM_TYPE_SPINJUMP]        = 10,
		--[HARM_TYPE_OFFSCREEN]       = 10,
		--[HARM_TYPE_SWORD]           = 10,
	}
)


function blockhopper.onInitAPI()
	npcManager.registerEvent(npcID, blockhopper, "onTickNPC")
	npcManager.registerEvent(npcID, blockhopper, "onDrawNPC")
	npcManager.registerEvent(npcID, blockhopper, "onCameraDrawNPC")

	registerEvent(blockhopper,"onTickEnd")
	registerEvent(blockhopper,"onDrawEnd")
end


local STATE_SLEEP       = 0
local STATE_WAKE        = 1
local STATE_WALK        = 2
local STATE_FALL_ASLEEP = 3
local STATE_PRE_JUMP    = 4

local LEDGEBEHAVIOUR_NOTHING = 0
local LEDGEBEHAVIOUR_TURN    = 1
local LEDGEBEHAVIOUR_JUMP    = 2

local VISUALEFFECT_3D_FILL    = 0
local VISUALEFFECT_3D_NO_FILL = 1
local VISUALEFFECT_SIMPLE     = 2



local takenBlocksMap = {}
local activeBlocks = {}


local function blockIsAdjacent(blockA,blockB)
	return (blockA.x-2 < blockB.x+blockB.width and blockA.x+blockA.width+2 > blockB.x and blockA.y-2 < blockB.y+blockB.height and blockA.y+blockA.height+2 > blockB.y)
end

local function playerIsOnBlock(p,b)
	return (b.x < p.x+p.width and b.x+b.width > p.x and p.y+p.height-2 < b.y and p.y+p.height+2 > b.y)
end


local function addBlock(v,data,candidates,b)
	local offsetX = (b.x + b.width*0.5) - (v.x + v.width*0.5)
	local offsetY = (b.y + b.height*0.5) - (v.y + v.height)

	table.insert(data.blockData,{
		block = b,
		owner = v,
		offsetX = offsetX,
		offsetY = offsetY,
		shakeX = 0,
		shakeY = 0,
		hiddenByDespawn = false,
		visualEffect = data.blockVisualsMap[b.id],
	})

	data.minOffsetX = math.min(data.minOffsetX,offsetX)
	data.minOffsetY = math.min(data.minOffsetY,offsetY)
	data.maxOffsetX = math.max(data.maxOffsetX,offsetX)
	data.maxOffsetY = math.max(data.maxOffsetY,offsetY)

	b.collisionGroup = v.collisionGroup

	takenBlocksMap[b] = true

	for _,c in ipairs(candidates) do
		if not takenBlocksMap[c] and blockIsAdjacent(b,c) then
			addBlock(v,data,candidates,c)
		end
	end
end

local function findBlocks(v,data,config,settings)
	data.blockData = {}
	data.centreBlock = nil

	-- Find candidates
	local bounds = v.sectionObj.origBoundary
	local candidates = {}

	for _,b in Block.iterateIntersecting(bounds.left - 256,bounds.top - 256,bounds.right + 256,bounds.bottom + 256) do
		if data.canHaveBlockMap[b.id] and b.layerName == v.layerName and not b:mem(0x5A,FIELD_BOOL) then
			local col = Colliders.Box(b.x+4,b.y+4,b.width-8,b.height-8)

			if data.centreBlock == nil and not takenBlocksMap[b] and col:collide(v) then -- close to centre
				data.centreBlock = b
			end

			table.insert(candidates,b)
		end
	end

	-- Find blocks to "control"
	if data.centreBlock ~= nil then
		-- Change size
		v.x = data.centreBlock.x + 1
		v.y = data.centreBlock.y
		v.width = data.centreBlock.width - 2
		v.height = data.centreBlock.height

		data.minOffsetX = math.huge
		data.minOffsetY = math.huge
		data.maxOffsetX = -math.huge
		data.maxOffsetY = -math.huge

		addBlock(v,data,candidates,data.centreBlock)
	else
		data.minOffsetX = 0
		data.minOffsetY = 0
		data.maxOffsetX = 0
		data.maxOffsetY = 0
	end
end


local function initialiseBlocks(v,data)
	local settings = v.data._settings
	local config = NPC.config[v.id]

	v.collisionGroup = "blockHopper ".. v.uid

	if data.canHaveBlockMap == nil then
		data.canHaveBlockMap = {}
		data.blockVisualsMap = {}

		for _,blockSetting in ipairs(settings.canHaveBlocks) do
			if blockSetting.blockID > 0 then
				data.canHaveBlockMap[blockSetting.blockID] = true
				data.blockVisualsMap[blockSetting.blockID] = blockSetting.visualEffect
			end
		end
	end

	findBlocks(v,data,config,settings)

	data.blocksInitialised = true
end


local function initialise(v,data,config,settings)
	if not data.blocksInitialised then
		initialiseBlocks(v,data)
	end

	-- Add blocks to active blocks list
	for _,blockData in ipairs(data.blockData) do
		if blockData.block.isValid then
			if blockData.hiddenByDespawn then
				blockData.hiddenByDespawn = false
				blockData.block.isHidden = false
			end
			
			table.insert(activeBlocks,blockData)
		end
	end


	data.state = STATE_SLEEP
	data.timer = 0

	data.openProgress = 0

	data.graphicDirection = v.direction
	--data.angle = config.forwardAngle*v.direction
	data.angle = 0

	data.animationTimer = 0
	data.headFrame = 0
	data.feetFrame = config.feetFrontFrames + config.feetWalkFrames

	data.footOffset = 0
	data.blockShake = 0

	data.scaleX = 1
	data.scaleY = 1

	data.initialized = true
end


local function getFrame(v,data,config,frames,frameSpeed,frameOffset)
	local frame = (math.floor(data.animationTimer/frameSpeed)%frames) + frameOffset

	return npcutils.getFrameByFramestyle(v,{frame = frame,direction = data.graphicDirection})
end

local function handleAnimation(v,data,config)
	local facingFront = (math.abs(data.angle) < config.forwardAngle*0.5)
	local headFrames = config.headFrontFrames + config.headSideFrames

	if data.angle ~= 0 then
		data.graphicDirection = math.sign(data.angle)
	end
	
	if facingFront then
		data.headFrame = getFrame(v,data,config,config.headFrontFrames,config.headFrontFrameSpeed,0)
		data.feetFrame = getFrame(v,data,config,config.feetFrontFrames,config.feetFrontFrameSpeed,headFrames)

		data.footOffset = config.footWalkOffset*data.openProgress
	else
		data.headFrame = getFrame(v,data,config,config.headSideFrames,config.headSideFrameSpeed,config.headFrontFrames)

		if v.collidesBlockBottom then -- on ground
			data.feetFrame = getFrame(v,data,config,config.feetWalkFrames,config.feetWalkFrameSpeed,headFrames + config.feetFrontFrames)

			-- Foot offset
			local frameIndex = (math.floor(data.animationTimer/config.feetWalkFrameSpeed) % config.feetWalkFrames) + 1

			data.footOffset = (config.footWalkOffset + (config.footWalkExtraOffsets[frameIndex] or 0))*data.openProgress
		else
			data.feetFrame = getFrame(v,data,config,config.feetAirFrames,config.feetAirFrameSpeed,headFrames + config.feetFrontFrames + config.feetWalkFrames)
		end
	end

	if data.state == STATE_PRE_JUMP then
		data.animationTimer = 0
	else
		data.animationTimer = data.animationTimer + 1
	end
end


local function getPlayerDistance(v)
	local n = npcutils.getNearestPlayer(v)
	local distance = vector((n.x + n.width*0.5) - (v.x + v.width*0.5),(n.y + n.height*0.5) - (v.y + v.height*0.5))

	return distance.length
end


local function getBlockGoal(v,data,config,blockData)
	local b = blockData.block

	local goalX = v.x + v.width*0.5 + blockData.offsetX
	local goalY = v.y + v.height + blockData.offsetY - config.feetHitboxHeight*data.openProgress

	if b ~= data.centreBlock then
		goalY = goalY - config.headHitboxHeight*data.openProgress
	end

	return goalX,goalY
end

local function isStoodOn(v,data,config)
	for _,p in ipairs(Player.get()) do
		if p.forcedState == FORCEDSTATE_NONE and p.deathTimer == 0 and not p:mem(0x13E,FIELD_BOOL) and p:isOnGround() then
			for _,blockData in ipairs(data.blockData) do
				local b = blockData.block

				if b.isValid and not b.isHidden and not b:mem(0x5A,FIELD_BOOL) and playerIsOnBlock(p,b) then
					return true
				end
			end
		end
	end

	return false
end


local function solidBlockFilter(b,v)
    local solidConfig = Block.config[b.id]

    if solidConfig.passthrough then
        return false
    end

    -- NPC/player filter
    if solidConfig.npcfilter < 0 or solidConfig.npcfilter == v.id then
        return false
    end

    return true
end

local function solidNPCFilter(n,v)
    local solidConfig = NPC.config[n.id]

    if n:mem(0x12C,FIELD_WORD) > 0 then
        return
    end

    if solidConfig.npcblock or solidConfig.playerblocktop then
        return true
    end
    
    return false
end


local function isAtLedge(v,data,config)
	if not v.collidesBlockBottom then
		return false
	end

	local col = Colliders.Box(v.x + v.width*0.5 + v.direction*6 - 4,v.y + v.height - 4,8,24)

	--col:draw()

	-- Solid NPC's
	local npcs = Colliders.getColliding{a = col,btype = Colliders.NPC}

	for _,n in ipairs(npcs) do
		if solidNPCFilter(n,v) then
			return false
		end
	end

	-- Solid blocks
	local blocks = Colliders.getColliding{a = col,btype = Colliders.BLOCK}

	for _,b in ipairs(blocks) do
		if solidBlockFilter(b,v) then
			return false
		end
	end

	return true
end


function blockhopper.onTickNPC(v)
	if Defines.levelFreeze then return end
	
	local data = v.data
	

	if not data.blocksInitialised then
		initialiseBlocks(v,data)
	end


	if v.despawnTimer <= 0 then
		if data.initialized then
			for _,blockData in ipairs(data.blockData) do
				local b = blockData.block
		
				if b.isValid and not b.isHidden then
					blockData.hiddenByDespawn = true
					b.isHidden = true
				end
			end

			data.initialized = false
		end

		return
	end


	local settings = v.data._settings
	local config = NPC.config[v.id]

	if not data.initialized then
		initialise(v,data,config,settings)
	end


	local goalAngle = config.forwardAngle*v.direction


	-- State behaviour
	if v.heldIndex > 0 or v.isProjectile or v.forcedState > 0 then
		data.state = STATE_WALK
		data.timer = 0
		data.openProgress = 1
	end

	if data.state == STATE_SLEEP then
		local wake = whistle.getActive()

		if v.collidesBlockBottom then
			v.speedX = 0

			if settings.wakeDistance > 0 then
				local distance = getPlayerDistance(v)
	
				if distance <= settings.wakeDistance then
					wake = true
				elseif distance <= settings.wakeDistance*1.5 then
					data.blockShake = 1
				end
			end

			wake = wake or (settings.wakeWhenWalkedOn and isStoodOn(v,data,config))
		end

		if wake then
			data.state = STATE_WAKE
			data.timer = 0

			v.speedY = config.wakeJumpSpeed
		end

		goalAngle = 0
	elseif data.state == STATE_WAKE then
		data.openProgress = math.min(1,data.openProgress + 0.1)
		goalAngle = 0

		if v.collidesBlockBottom then
			data.state = STATE_WALK
			data.timer = 0
		end
	elseif data.state == STATE_WALK then
		if v.collidesBlockBottom then
			v.speedX = config.walkSpeed*v.direction

			if settings.sleepDistance > 0 and not whistle.getActive() and getPlayerDistance(v) > settings.sleepDistance and not isStoodOn(v,data,config) then
				data.state = STATE_FALL_ASLEEP
				data.timer = 0
			else
				data.timer = data.timer + 1

				if (settings.jumpInterval > 0 and data.timer >= settings.jumpInterval)
				or (settings.ledgeBehaviour == LEDGEBEHAVIOUR_JUMP and isAtLedge(v,data,config))
				then
					data.state = STATE_PRE_JUMP
					data.timer = 0
				elseif settings.ledgeBehaviour == LEDGEBEHAVIOUR_TURN and isAtLedge(v,data,config) then
					v.direction = -v.direction
				end
			end
		end
	elseif data.state == STATE_FALL_ASLEEP then
		if v.collidesBlockBottom then
			v.speedX = 0
		end

		data.openProgress = math.max(0,data.openProgress - 0.2)
		goalAngle = 0

		if data.openProgress <= 0 then
			data.state = STATE_SLEEP
			data.timer = 0
		end
	elseif data.state == STATE_PRE_JUMP then
		if v.collidesBlockBottom then
			data.timer = data.timer + 1
			v.speedX = 0

			local t = data.timer/config.preJumpTime

			if t >= 1 then
				data.state = STATE_WALK
				data.timer = 0

				data.scaleX = 1
				data.scaleY = 1

				v.speedX = settings.jumpSpeedX*v.direction
				v.speedY = settings.jumpSpeedY
				
				SFX.play(24)
			else
				data.scaleX = 1 + t*config.preJumpSquash
				data.scaleY = 1 - t*config.preJumpSquash
			end
		else
			data.timer = 0
		end
	end


	if goalAngle > data.angle then
		data.angle = math.min(goalAngle,data.angle + config.turnSpeed)
	elseif goalAngle < data.angle then
		data.angle = math.max(goalAngle,data.angle - config.turnSpeed)
	end


	-- Update blocks
	for _,blockData in ipairs(data.blockData) do
		local b = blockData.block

		if b.isValid then
			local goalX,goalY = getBlockGoal(v,data,config,blockData)

			goalX = goalX + v.speedX - b.width*0.5
			goalY = goalY + v.speedY - b.height*0.5

			local distanceX = goalX - b.x
			local distanceY = goalY - b.y

			b.speedX = distanceX
			b.speedY = distanceY

			if b.speedX == 0 then
				b.speedX = 0.001 -- helps fix some slight jank
			end

			if b.layerSpeedX == 0 and b.layerSpeedY == 0 then
				b:translate(distanceX,distanceY)
			end

			blockData.shakeX = RNG.random(-data.blockShake,data.blockShake)
			--blockData.shakeY = RNG.random(-data.blockShake,data.blockShake)
		end
	end

	data.blockShake = math.max(0,data.blockShake - 0.5)

	
	local newHeight = (config.feetHitboxHeight + config.headHitboxHeight)*data.openProgress

	if data.centreBlock ~= nil and data.centreBlock.isValid and not data.centreBlock.isHidden then
		local newWidth = data.centreBlock.width - 2

		v.x = v.x + (v.width - newWidth)*0.5
		v.width = newWidth

		newHeight = newHeight + data.centreBlock.height
	else
		v:kill(HARM_TYPE_NPC)
	end

	v.y = v.y + v.height - newHeight
	v.height = newHeight

	handleAnimation(v,data,config)
end


local drawVC = {}
local drawTC = {}
local drawArgs = {vertexCoords = drawVC,textureCoords = drawTC,sceneCoords = true}
local drawVertexCount = 0
local drawOldVertexCount = 0

local hiddenBlocks = {}


local function addQuadToDraw(x,y,width,height,sourceX,sourceY,sourceWidth,sourceHeight)
	-- Vertex coords
	do
		--local x1 = math.floor(x - width*0.5 + 0.5)
		--local y1 = math.floor(y - height*0.5 + 0.5)
		--local x2 = math.floor(x1 + width + 0.5)
		--local y2 = math.floor(y1 + height + 0.5)
		local x1 = x - width*0.5
		local y1 = y - height*0.5
		local x2 = x1 + width
		local y2 = y1 + height

		drawVC[drawVertexCount+1 ] = x1 -- top left
		drawVC[drawVertexCount+2 ] = y1
		drawVC[drawVertexCount+3 ] = x2 -- top right
		drawVC[drawVertexCount+4 ] = y1
		drawVC[drawVertexCount+5 ] = x1 -- bottom left
		drawVC[drawVertexCount+6 ] = y2
		drawVC[drawVertexCount+7 ] = x2 -- top right
		drawVC[drawVertexCount+8 ] = y1
		drawVC[drawVertexCount+9 ] = x1 -- bottom left
		drawVC[drawVertexCount+10] = y2
		drawVC[drawVertexCount+11] = x2 -- bottom right
		drawVC[drawVertexCount+12] = y2
	end

	-- Texture coords
	local texture = drawArgs.texture

	if texture ~= nil then
		local x1 = sourceX/texture.width
		local y1 = sourceY/texture.height
		local x2 = (sourceX + sourceWidth)/texture.width
		local y2 = (sourceY + sourceHeight)/texture.height

		drawTC[drawVertexCount+1 ] = x1 -- top left
		drawTC[drawVertexCount+2 ] = y1
		drawTC[drawVertexCount+3 ] = x2 -- top right
		drawTC[drawVertexCount+4 ] = y1
		drawTC[drawVertexCount+5 ] = x1 -- bottom left
		drawTC[drawVertexCount+6 ] = y2
		drawTC[drawVertexCount+7 ] = x2 -- top right
		drawTC[drawVertexCount+8 ] = y1
		drawTC[drawVertexCount+9 ] = x1 -- bottom left
		drawTC[drawVertexCount+10] = y2
		drawTC[drawVertexCount+11] = x2 -- bottom right
		drawTC[drawVertexCount+12] = y2
	end

	drawVertexCount = drawVertexCount + 12
end

local function finishDraw()
	if drawVertexCount <= 0 then
		return
	end

	-- Clear out old vertices from past draw
	for i = drawVertexCount+1,drawOldVertexCount do
		drawVC[i] = nil
		drawTC[i] = nil
	end

	drawOldVertexCount = drawVertexCount
	drawVertexCount = 0

	-- Draw
	Graphics.glDraw(drawArgs)
end


local function drawBlock(v,data,config,settings,blockData)
	local b = blockData.block

	if not b.isValid or b.isHidden or b:mem(0x5A,FIELD_BOOL) then
		return
	end

	-- Draw
	local texture = Graphics.sprites.block[b.id].img

	if texture == nil then
		return
	end

	-- Some general calculations first
	local blockConfig = Block.config[b.id]

	local sourceX = 0
	local sourceY = blockutils.getBlockFrame(b.id)*blockConfig.height

	local width = b.width*data.scaleX
	local height = b.height*data.scaleY

	local frontWidth,sideWidth

	if data.angle ~= 0 and blockData.visualEffect ~= VISUALEFFECT_SIMPLE then
		frontWidth = math.cos(math.rad(data.angle))*width
		sideWidth = math.sin(math.rad(data.angle))*width
	else
		frontWidth = width
		sideWidth = 0
	end

	local x,y = getBlockGoal(v,data,config,blockData)

	x = math.floor(x + blockData.shakeX + 0.5)
	y = math.floor(y + blockData.shakeY + b.height - height + b:mem(0x56,FIELD_WORD) + data.footOffset + 0.5)

	-- Find priority to use
	local relativeX = 0

	if data.minOffsetX ~= data.maxOffsetX then
		relativeX = math.clamp((blockData.offsetX - data.minOffsetX) / (data.maxOffsetX - data.minOffsetX))
		
		if sideWidth > 0 then
			relativeX = 1 - relativeX
		end
	end

	drawArgs.priority = config.priority + (relativeX - 1)*0.05

	-- Draw a black (or whatever color you set!) background inside the block
	if blockData.visualEffect == VISUALEFFECT_3D_FILL and sideWidth ~= 0 and config.blockFillColor.a > 0 then
		drawArgs.texture = nil
		drawArgs.color = config.blockFillColor

		addQuadToDraw(x,y,width,height)
		finishDraw()
	end

	-- Draw front/side
	drawArgs.texture = texture
	drawArgs.color = nil

	if frontWidth ~= 0 then
		local frontX = x + sideWidth*0.5

		addQuadToDraw(frontX,y,math.abs(frontWidth),height,sourceX,sourceY,b.width,b.height)
	end

	if sideWidth ~= 0 then
		local sideX = x - frontWidth*0.5*math.sign(sideWidth)

		addQuadToDraw(sideX,y,math.abs(sideWidth),height,sourceX,sourceY,b.width,b.height)
	end

	finishDraw()


	-- Hide block
	table.insert(hiddenBlocks,b)
	b.isHidden = true
end


function blockhopper.onDrawNPC(v)
	if v.despawnTimer <= 0 then return end

	local settings = v.data._settings
	local config = NPC.config[v.id]
	local data = v.data

	if not data.initialized then
		initialise(v,data,config,settings)
	end

	-- Draw blocks
	for _,blockData in ipairs(data.blockData) do
		drawBlock(v,data,config,settings,blockData)
	end

	-- Draw rest
	if data.openProgress > 0 or data.centreBlock == nil then
		local width = config.gfxwidth*data.scaleX
		local height = config.gfxheight*data.scaleY

		drawArgs.texture = Graphics.sprites.npc[v.id].img
		drawArgs.priority = config.priority - 0.1

		-- Loop runs once for feet, once for head
		for i = 1,2 do
			local x = v.x + v.width*0.5 + config.gfxoffsetx
			local y = v.y + v.height - height*0.5 + config.gfxoffsety
			local frame = 0

			if i == 1 then
				x = x + config.footGFXOffsetX
				y = y + config.footGFXOffsetY
				frame = data.feetFrame
			else
				y = y - v.height + config.headHitboxHeight + data.footOffset
				frame = data.headFrame
			end

			local sourceX = 0
			local sourceY = frame*config.gfxheight

			addQuadToDraw(x,y,width,height,sourceX,sourceY,config.gfxwidth,config.gfxheight)
		end

		finishDraw()

		--Colliders.getHitbox(v):draw()

		--npcutils.drawNPC(v,{priority = priority,applyFrameStyle = false,frame = data.feetFrame,xOffset = config.footGFXOffsetX,yOffset = config.footGFXOffsetY})
		--npcutils.drawNPC(v,{priority = priority,applyFrameStyle = false,frame = data.headFrame,yOffset = config.headHitboxHeight - v.height + data.footOffset})
	end

	npcutils.hideNPC(v)
end

function blockhopper.onCameraDrawNPC(v,camIdx)
	local c = Camera(camIdx)
	local data = v.data

	if not data.blocksInitialised then
		initialiseBlocks(v,data)
	end

	local x = v.x + v.width*0.5
	local y = v.y + v.height

	if c.x+c.width > (x + data.minOffsetX - 16) and c.y+c.height > (y + data.minOffsetY - 16) and (x + data.maxOffsetX + 16) > c.x and (y + data.maxOffsetY + 16) > c.y then
		-- On camera, so activate (based on this  https://github.com/smbx/smbx-legacy-source/blob/master/modGraphics.bas#L517)
		local resetOffset = (0x126 + (camIdx - 1)*2)

		if v:mem(resetOffset, FIELD_BOOL) or v:mem(0x124,FIELD_BOOL) then
			if not v:mem(0x124,FIELD_BOOL) then
				v:mem(0x14C,FIELD_WORD,camIdx)
			end

			v.despawnTimer = 180
			v:mem(0x124,FIELD_BOOL,true)
		end

		v:mem(0x126,FIELD_BOOL,false)
		v:mem(0x128,FIELD_BOOL,false)
	end
end


function blockhopper.onDrawEnd()
	for i = 1,#hiddenBlocks do
		local b = hiddenBlocks[i]

		if b.isValid then
			b.isHidden = false
		end

		hiddenBlocks[i] = nil
	end
end



local function updateBlock(blockData)
	local b = blockData.block
	local v = blockData.owner
	
	if not b.isValid then
		return true
	end

	if not v.isValid or v.id ~= npcID then
		b:remove(true)
		return true
	end

	if not v.data.initialized then
		local goalX,goalY = getBlockGoal(v,v.data,NPC.config[v.id],blockData)

		goalX = goalX - b.width*0.5
		goalY = goalY - b.height*0.5

		b.speedX = 0
		b.speedY = 0

		b:translate(goalX - b.x,goalY - b.y)

		return true
	end

	return false
end

function blockhopper.onTickEnd()
	local i = 1

	while (true) do
		local blockData = activeBlocks[i]

		if blockData == nil then -- end of list
			break
		end

		if updateBlock(blockData) then
			table.remove(activeBlocks,i)
		else
			i = i + 1
		end
	end
end


return blockhopper