--[[

	Written by MrDoubleA
	Please give credit!

    Part of MrDoubleA's NPC Pack

]]

local npcManager = require("npcManager")
local npcutils = require("npcs/npcutils")

local ai = require("milde_ai")


local milde = {}
local npcID = NPC_ID

local deathEffectID = {id = 294,xoffsetBack = 0,yoffsetBack = 0}
local popEffectID = (npcID)

local splitID = 0
local splitCount = 0


local mildeSettings = table.join({
	id = npcID,
	
	frames = 7,
	framestyle = 1,
	framespeed = 8,

	gfxwidth = 32,
	gfxheight = 32,

	width = 32,
	height = 32,

	gfxoffsetx = 0,
	gfxoffsety = 2,


	speed = 1,
	isheavy = false,
	noyoshi = false,
	noiceball = false,
	health = 1,

	squashFrames = 2,

	squashDuration = 8,
	squashHeight = 16,
	squashScaleX = 1,
	squashScaleY = 1,

	squashSpeedExtraWidth = 48,
	squashSpeedSpeedX = 2,
	squashSpeedSpeedY = -4,

	splitID = splitID,
	splitCount = splitCount,

	popEffectID = popEffectID,
	popEffectScale = 1,

	stunTime = 16,

	mildeSize = ai.SIZE.SMALL,
},ai.sharedSettings)

npcManager.setNpcSettings(mildeSettings)
npcManager.registerHarmTypes(npcID,
	{
		HARM_TYPE_FROMBELOW,
		HARM_TYPE_NPC,
		HARM_TYPE_PROJECTILE_USED,
		HARM_TYPE_LAVA,
		HARM_TYPE_HELD,
		HARM_TYPE_TAIL,
		HARM_TYPE_OFFSCREEN,
		HARM_TYPE_SWORD
	},
	{
		[HARM_TYPE_JUMP]            = deathEffectID,
		[HARM_TYPE_FROMBELOW]       = deathEffectID,
		[HARM_TYPE_NPC]             = deathEffectID,
		[HARM_TYPE_PROJECTILE_USED] = deathEffectID,
		[HARM_TYPE_HELD]            = deathEffectID,
		[HARM_TYPE_TAIL]            = deathEffectID,
		[HARM_TYPE_LAVA]            = {id=13, xoffset=0.5, xoffsetBack = 0, yoffset=1, yoffsetBack = 1.5},
		[HARM_TYPE_SPINJUMP]        = 10,
	}
)


ai.register(npcID)


return milde