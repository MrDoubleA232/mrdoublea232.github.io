--[[

	Written by MrDoubleA
	Please give credit!

    Part of MrDoubleA's NPC Pack

]]

local npcManager = require("npcManager")
local npcutils = require("npcs/npcutils")

local ai = require("milde_ai")


local milde = {}
local npcID = NPC_ID

local deathEffectID = 294
local popEffectID = (npcID - 2)

local splitID = (npcID - 1)
local splitCount = 2


local mildeSettings = table.join({
	id = npcID,
	
	frames = 7,
	framestyle = 1,
	framespeed = 8,

	gfxwidth = 128,
	gfxheight = 128,

	width = 96,
	height = 102,

	gfxoffsetx = 0,
	gfxoffsety = 2,


	speed = 1.25,
	weight = 4,
	noyoshi = true,
	noiceball = true,
	health = 5,

	squashFrames = 1,

	squashDuration = 32,
	squashHeight = 102,
	squashScaleX = 2,
	squashScaleY = 0.35,

	squashSpeedExtraWidth = 96,
	squashSpeedSpeedX = 3.5,
	squashSpeedSpeedY = -5,

	stunTime = 16,

	splitID = splitID,
	splitCount = splitCount,

	popEffectID = popEffectID,
	popEffectScale = 2,

	mildeSize = ai.SIZE.GIANT,
},ai.sharedSettings)

npcManager.setNpcSettings(mildeSettings)
npcManager.registerHarmTypes(npcID,
	{
		HARM_TYPE_FROMBELOW,
		HARM_TYPE_NPC,
		HARM_TYPE_PROJECTILE_USED,
		HARM_TYPE_LAVA,
		HARM_TYPE_HELD,
		HARM_TYPE_TAIL,
		HARM_TYPE_OFFSCREEN,
		HARM_TYPE_SWORD
	},
	{
		[HARM_TYPE_JUMP]            = deathEffectID,
		[HARM_TYPE_FROMBELOW]       = deathEffectID,
		[HARM_TYPE_NPC]             = deathEffectID,
		[HARM_TYPE_PROJECTILE_USED] = deathEffectID,
		[HARM_TYPE_HELD]            = deathEffectID,
		[HARM_TYPE_TAIL]            = deathEffectID,
		[HARM_TYPE_LAVA]            = {id=13, xoffset=0.5, xoffsetBack = 0, yoffset=1, yoffsetBack = 1.5},
		[HARM_TYPE_SPINJUMP]        = 10,
	}
)


ai.register(npcID)


return milde