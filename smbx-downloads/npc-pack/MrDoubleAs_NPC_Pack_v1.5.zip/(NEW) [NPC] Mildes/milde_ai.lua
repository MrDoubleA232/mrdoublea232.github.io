--[[

	Written by MrDoubleA
	Please give credit!

    Part of MrDoubleA's NPC Pack

]]

local npcManager = require("npcManager")
local npcutils = require("npcs/npcutils")

local clearpipeNPC = require("npcs/ai/clearpipeNPC")
local clearpipe = require("blocks/ai/clearpipe")

local milde = {}


milde.SIZE = {
    SMALL = 1,
    BIG   = 2,
    GIANT = 3,
}


milde.sharedSettings = {
	npcblock = false,
	npcblocktop = false, --Misnomer, affects whether thrown NPCs bounce off the NPC.
	playerblock = false,
	playerblocktop = false, --Also handles other NPCs walking atop this NPC.

	nohurt = false,
	nogravity = false,
	noblockcollision = false,
	nofireball = false,
	noiceball = false,
	noyoshi = false,
	nowaterphysics = false,
	
	jumphurt = false,
	spinjumpsafe = false,
	harmlessgrab = false,
	harmlessthrown = false,

    luahandlesspeed = true,

    mildeCliffturn = true,

    bounceSound = Misc.resolveSoundFile("milde_bounce"),
    popSound = Misc.resolveSoundFile("milde_pop"),
}


milde.idList = {}
milde.idMap  = {}


function milde.register(npcID)
	npcManager.registerEvent(npcID, milde, "onTickEndNPC")
    npcManager.registerEvent(npcID, milde, "onDrawNPC")

    table.insert(milde.idList,npcID)
    milde.idMap[npcID] = true


    local config = NPC.config[npcID]

    --config:setDefaultProperty("chuckchargefunction",milde.chuckInteraction)
    --config:setDefaultProperty("chuckbatfunction",milde.batInteraction)

    if config.mildeSize <= milde.SIZE.BIG then
        clearpipe.registerNPC(npcID)

        clearpipeNPC.onTickFunctions[npcID] = milde.clearpipeNPCOnTick
    end
end


local STATE = {
    WALK = 0,
    SQUASH = 1,
}


local function initailise(v,data,config)
    data.initialized = true

    data.state = STATE.WALK
    data.timer = 0

    data.scaleX = 1
    data.scaleY = 1

    data.animationTimer = 0

    data.temporarilyFriendly = false

    data.squashSide = 0

    data.inChargeKnockback = false

    data.health = config.health

    data.forceSquashing = data.forceSquashing or false
end


local function playerCanSquash(p)
    return (
        p.forcedState == FORCEDSTATE_NONE
        and p.deathTimer == 0
        --and not p:isOnGround()
    )
end

local function playerHasForce(p)
    return (
        p:mem(0x5C,FIELD_BOOL)
    )
end


local function getGravity(v,config)
    local gravity = Defines.npc_grav

    if config.nogravity then
        gravity = 0
    elseif v.underwater and not config.nowaterphysics then
        gravity = gravity * 0.2
    end

    return gravity
end


local function updateHitboxSize(v,data,config)
    local newWidth = config.width
    local newHeight = config.height

    local widthChangePivot = 0.5
    local heightChangePivot = 1

    if data.state == STATE.SQUASH then
        newWidth = newWidth * data.scaleX
        newHeight = config.squashHeight * data.scaleY

        if data.squashSide ~= 0 then
            widthChangePivot = (data.squashSide*0.5 + 0.5)
            --heightChangePivot = 0.5
        end
    end

    v.x = v.x + (v.width - newWidth)*widthChangePivot
    v.width = newWidth

    v.y = v.y + (v.height - newHeight)*heightChangePivot
    v.height = newHeight
end


local function setDontHarmPlayer(v)
    v:mem(0x130,FIELD_WORD, npcutils.getNearestPlayer(v).idx)
    v:mem(0x12E,FIELD_WORD, 30)
end


local function doPop(v,data,config)
    -- Split
    if (config.splitID ~= nil and config.splitID > 0) and (config.splitCount ~= nil and config.splitCount > 0) then
        for i = 0,config.splitCount - 1 do
            local side = math.sign(i/(config.splitCount - 1) - 0.5)
            local friendly = (v.friendly and not data.temporarilyFriendly)

            local npc = NPC.spawn(config.splitID, v.x + v.width*0.5 + side*4,v.y + v.height - NPC.config[config.splitID].height*0.5, v.section,false,true)


            if data.squashSide ~= 0 then
                npc.direction = -data.squashSide
            elseif side == 0 then
                npc.direction = v.direction
            else
                npc.direction = side
            end

            if milde.idMap[npc.id] and not friendly then
                initailise(v,npc.data,NPC.config[npc.id])

                npc.friendly = true
                npc.data.temporarilyFriendly = true
            else
                npc.friendly = friendly
            end

            npc.layerName = v.layerName
            npc.noMoreObjInLayer = v.noMoreObjInLayer
            npc.dontMove = v.dontMove

            npc.speedX = config.squashSpeedSpeedX * side
            npc.speedY = config.squashSpeedSpeedY
            npc:mem(0x136,FIELD_BOOL,true)

            if data.squashSide == -side then
                npc.speedX = 0
            end
        end
    end

    -- Everything flies away!
    local width = config.width + config.squashSpeedExtraWidth*2
    local height = config.height
    local x = v.x + v.width*0.5 - width*0.5
    local y = v.y + v.height - height

    local col = Colliders.Box(x,y,width,height)
    local npcs = Colliders.getColliding{a = col,b = NPC.HITTABLE,btype = Colliders.NPC}

    for _,npc in ipairs(npcs) do
        if npc.x+npc.width*0.5 < col.x+col.width*0.5 then
            npc.direction = DIR_LEFT
            npc.speedX = -config.squashSpeedSpeedX
        else
            npc.direction = DIR_RIGHT
            npc.speedX = config.squashSpeedSpeedX
        end

        npc.speedY = config.squashSpeedSpeedY
        npc:mem(0x136,FIELD_BOOL,true)
        setDontHarmPlayer(npc)
    end

    -- Spawn pop effect
    local e = Effect.spawn(config.popEffectID,v.x + v.width*0.5,v.y + v.height*0.5)

    e.width  = e.width  * config.popEffectScale
    e.height = e.height * config.popEffectScale

    e.x = e.x - e.width *0.5
    e.y = e.y - e.height*0.5

    
    v:kill(HARM_TYPE_VANISH)
    SFX.play(config.popSound)
end


local function solidFilter(v,solid)
    local solidType = type(solid)

    if solidType == "Block" then
        local solidConfig = Block.config[solid.id]

        if solid.isHidden or solid:mem(0x5A,FIELD_BOOL) then
            return false
        end

        if solidConfig.passthrough then
            return false
        end

        -- NPC filter
        if solidConfig.npcfilter < 0 or solidConfig.npcfilter == v.id then
            return false
        end

        return true
    elseif solidType == "NPC" then
        local solidConfig = NPC.config[solid.id]

        if solid.despawnTimer <= 0 or solid.isGenerator or solid.friendly or solid:mem(0x12C,FIELD_WORD) > 0 then
            return
        end

        if solidConfig.npcblock or solidConfig.playerblocktop then -- why do NPC's also use playerblocktop
            return true
        end

        return false
    end
end

local function shouldCliffturn(v,data,config)
    -- Making good cliffturning is surprisingly difficult
    if not v.collidesBlockBottom then
        return false
    end

    local width = v.width * 0.8
    local height = 24

    local x
    local y = v.y + v.height + 2

    if v.direction == DIR_LEFT then
        x = v.x + v.width*0.75 - width
    else
        x = v.x + v.width*0.25
    end


    --Colliders.Box(x,y,width,height):Draw(Color.purple.. 0.5)


    for _,block in Block.iterateIntersecting(x,y,x + width,y + height + 128) do
        if solidFilter(v,block) then
            local extraHeight = 0
            if Block.SLOPE_LR_FLOOR_MAP[block.id] or Block.SLOPE_RL_FLOOR_MAP[block.id] then
                extraHeight = (block.height / block.width) * 16
            end

            if (y + height + extraHeight) > block.y then
                --Colliders.getHitbox(block):Draw()
                return false
            end
        end
    end

    for _,npc in NPC.iterateIntersecting(x,y,x + width,y + height) do
        if solidFilter(v,npc) then
            return false
        end
    end

    return true
end


local function handleAnimation(v,data,config)
    local squashFrames = config.squashFrames
    local walkFrames = config.frames - squashFrames

    local frame = 0

    if data.state ~= STATE.SQUASH then
        if walkFrames > 1 then
            frame = math.floor(data.animationTimer / config.framespeed) % (walkFrames*2 - 2)

            if frame >= walkFrames then
                frame = walkFrames - (frame - walkFrames) - 2
            end
        end

        if data.state == STATE.WALK and not v:mem(0x136,FIELD_BOOL) then
            data.animationTimer = data.animationTimer + 1
        end
    else
        frame = (math.min(squashFrames - 1,math.floor((data.timer / config.squashDuration) * squashFrames))) + walkFrames
    end

    v.animationFrame = npcutils.getFrameByFramestyle(v,{frame = frame})
end


function milde.onTickEndNPC(v)
	if Defines.levelFreeze then return end
	
	local data = v.data
	
	if v.despawnTimer <= 0 then
		data.initialized = false
        v.noblockcollision = false
		return
	end

    local config = NPC.config[v.id]

	if not data.initialized then
		initailise(v,data,config)
	end


    if data.inChargeKnockback then
        if (v.collidesBlockLeft or v.collidesBlockRight) and v:mem(0x120,FIELD_BOOL) then
            data.state = STATE.SQUASH
            data.timer = 0

            data.inChargeKnockback = false
            data.squashSide = (v.collidesBlockLeft and -1) or 1
            v:mem(0x136,FIELD_BOOL,false)
        end
    end


	if v:mem(0x12C, FIELD_WORD) > 0    --Grabbed
	or v:mem(0x136, FIELD_BOOL)        --Thrown
	or v:mem(0x138, FIELD_WORD) > 0    --Contained within
	then
        handleAnimation(v,data,config)
        return
    end


    data.inChargeKnockback = false


    if data.state == STATE.SQUASH then
        v.friendly = true
        data.temporarilyFriendly = true
    elseif data.temporarilyFriendly then
        v.friendly = false
        data.temporarilyFriendly = false
    end


    if not v.friendly or data.state == STATE.SQUASH then
        for _,p in ipairs(Player.get()) do
            local npcSpeedY = v.speedY
            local playerSpeedY = p.speedY

            local playerCol = Colliders.getHitbox(p)
            local npcCol = Colliders.getHitbox(v)

            local extraHeight = 0

            if not data.forceSquashing then
                playerCol.y = playerCol.y + playerSpeedY
                npcCol.y = npcCol.y + npcSpeedY

                if v:mem(0x22,FIELD_WORD) > 0 then
                    local slope = Block(v:mem(0x22,FIELD_WORD))

                    if slope.isValid then
                        extraHeight = extraHeight + (slope.height / slope.width) * 8
                    end
                end
            end

            npcCol.y = npcCol.y - extraHeight
            npcCol.height = npcCol.height + extraHeight


            if playerCanSquash(p) and (p.y+p.height-p.speedY <= v.y-v.speedY+extraHeight or data.forceSquashing) and Colliders.collide(playerCol,npcCol) then
                local canSquash = (config.mildeSize <= milde.SIZE.SMALL or playerHasForce(p))
                
                if canSquash then
                    if data.state == STATE.WALK then
                        data.state = STATE.SQUASH
                        data.timer = 0

                        data.squashSide = 0
                    end

                    p.speedX = 0

                    --updateHitboxSize(v,data,config)
                elseif data.state == STATE.WALK then
                    data.timer = config.stunTime

                    SFX.play(config.bounceSound)
                end

                if canSquash or data.forceSquashing then
                    p.speedY = v.speedY + 0.01
                    p.y = v.y + v.speedY - p.height - Defines.player_grav*4
                end
            end
        end
    end


    data.forceSquashing = false


    if data.state == STATE.WALK then
	    v.speedX = config.speed * v.direction

        if data.timer > 0 then
            local t = (data.timer / config.stunTime)
            local squash = math.cos((1 - t) * math.pi * 2) * t * 0.25

            data.scaleX = (1 + squash)
            data.scaleY = (1 - squash)

            data.timer = math.max(0,data.timer - 1)
        else
            data.scaleX = 1
            data.scaleY = 1
        end


        -- Custom cliffturn (because that default one ain't good)
        if config.mildeCliffturn and shouldCliffturn(v,data,config) then
            v.direction = -v.direction
        end
    else
        data.timer = data.timer + 1
        v.speedX = 0

        v.speedY = -getGravity(v,config)
        v.noblockcollision = true

        local t = math.sin((data.timer / config.squashDuration) * math.pi * 0.5)

        if data.squashSide == 0 then
            data.scaleX = math.lerp(1,config.squashScaleX, t)
            data.scaleY = math.lerp(1,config.squashScaleY, t)
        else
            data.scaleX = math.lerp(1,config.squashScaleY, t)
            data.scaleY = math.lerp(1,config.squashScaleX, t)
        end

        if data.timer >= config.squashDuration then
            doPop(v,data,config)
        end
    end

    --Colliders.getHitbox(v):Draw(Color.purple.. 0.5)

    updateHitboxSize(v,data,config)
    handleAnimation(v,data,config)
end


local lowPriorityStates = table.map{1,3,4}

function milde.onDrawNPC(v)
    if v.despawnTimer <= 0 or v.isHidden then return end

    local config = NPC.config[v.id]
    local data = v.data

    if not data.initialized then
        initailise(v,data,config)
    end

    --[[if data.scaleX == 1 and data.scaleY == 1 then
        return
    end]]

    
    if data.sprite == nil then
        data.sprite = Sprite{texture = Graphics.sprites.npc[v.id].img,frames = npcutils.getTotalFramesByFramestyle(v),pivot = Sprite.align.BOTTOM}
    end

    local priority = (lowPriorityStates[v:mem(0x138,FIELD_WORD)] and -75) or (config.foreground and -15) or -45

    local frame = v.animationFrame + 1

    data.sprite.x = v.x + v.width*0.5 + config.gfxoffsetx
    data.sprite.y = v.y + v.height + config.gfxoffsety

    data.sprite.scale.x = data.scaleX
    data.sprite.scale.y = data.scaleY

    if data.squashSide ~= 0 then
        --data.sprite.y = data.sprite.y + (config.gfxheight*data.scaleY - v.height)*0.5
    end

    data.sprite:draw{frame = v.animationFrame+1,priority = priority,sceneCoords = true}


    npcutils.hideNPC(v)
end


function milde.onNPCHarm(eventObj,v,reason,culprit)
    if not milde.idMap[v.id] then return end

    local config = NPC.config[v.id]
    local data = v.data

    if not data.initialized then
        return
    end

    if (type(culprit) == "NPC" and culprit.id == 13) or reason == HARM_TYPE_SWORD then
        data.health = math.max(0,data.health - 1)
        SFX.play(9)

        eventObj.cancelled = true
        
        if data.health <= 0 then
            doPop(v,data,config)
        end
    end
end


local harmTypesWithPopSound = table.map{HARM_TYPE_JUMP,HARM_TYPE_FROMBELOW,HARM_TYPE_NPC,HARM_TYPE_PROJECTILE_USED,HARM_TYPE_HELD,HARM_TYPE_TAIL}

function milde.onPostNPCKill(v,reason)
    if milde.idMap[v.id] and harmTypesWithPopSound[reason] then
        local config = NPC.config[v.id]

        SFX.play(config.popSound)
    end
end


--[[function milde.chuckInteraction(p,v,chargeSpeed)
    local config = NPC.config[v.id]
    local data = v.data

    if not data.initialized then
        return
    end

    if config.mildeSize >= milde.SIZE.BIG then
        v:mem(0x136,FIELD_BOOL,true)
        v.speedX = p.speedX

        if v.collidesBlockBottom then
            v.speedY = -4
        end

        v.friendly = true
        data.temporarilyFriendly = true

        data.inChargeKnockback = true

        return (chargeSpeed <= 1 or config.mildeSize > milde.SIZE.BIG)
    else
        v:harm(HARM_TYPE_NPC)
        return false
    end
end

function milde.batInteraction(p,v,hitDirection)
    local config = NPC.config[v.id]
    local data = v.data

    if not data.initialized then
        return
    end

    v:mem(0x136,FIELD_BOOL,true)
    v.speedX = hitDirection*4

    if v.collidesBlockBottom then
        v.speedY = -2
    end

    --v.friendly = true
    --data.temporarilyFriendly = true

    data.inChargeKnockback = true

    return true,true
end]]


function milde.clearpipeNPCOnTick(v)
    local data = v.data._basegame
    local data2 = data._clearpipe_storage
    local data3 = v.data

    local id = data.id
    local config = NPC.config[id]


    local walkFrames = (config.frames - config.squashFrames)

    data2.animationTimer = (data2.animationTimer or 0) + 1

    local frame = math.floor(data2.animationTimer / (config.framespeed*0.25)) % (walkFrames*2 - 2)
    if frame >= walkFrames then
        frame = walkFrames - (frame - walkFrames) - 2
    end
    if v.direction == DIR_RIGHT then
        frame = frame + config.frames
    end

    data.animationFrame = frame
    data.animationTimer = -999

    if data.speedY < 0 then
        data3.forceSquashing = true

        if not v.friendly or data3.temporarilyFriendly then
            v.friendly = true
            data3.temporarilyFriendly = true
        end
    else
        data3.forceSquashing = false

        if data3.temporarilyFriendly then
            v.friendly = false
            data3.temporarilyFriendly = false
        end
    end
end


function milde.onInitAPI()
    registerEvent(milde,"onNPCHarm")
    registerEvent(milde,"onPostNPCKill")
end


-- Pop effect
do
    local effectconfig = require("game/effectconfig")

    function effectconfig.onTick.TICK_MILDEPOP(v)
        if v.spawnX == nil then
            v.spawnX = v.x
            v.spawnY = v.y
        end

        if (v.lifetime - v.timer)%4 == 0 then
            v.x = v.spawnX + RNG.random(-24,24)
            v.y = v.spawnY + RNG.random(-24,24)
        end
    end
end


return milde