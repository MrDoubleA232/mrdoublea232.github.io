--[[

	Written by MrDoubleA
	Please give credit!

    Part of MrDoubleA's NPC Pack

]]

local npcManager = require("npcManager")
local npcutils = require("npcs/npcutils")

local ai = require("milde_ai")


local milde = {}
local npcID = NPC_ID

local deathEffectID = 294
local popEffectID = (npcID - 1)

local splitID = (npcID - 1)
local splitCount = 2


local mildeSettings = table.join({
	id = npcID,
	
	frames = 6,
	framestyle = 1,
	framespeed = 8,

	gfxwidth = 64,
	gfxheight = 64,

	width = 64,
	height = 64,

	gfxoffsetx = 0,
	gfxoffsety = 2,


	speed = 1,
	weight = 2,
	noyoshi = true,
	noiceball = true,
	health = 3,

	squashFrames = 1,

	squashDuration = 32,
	squashHeight = 64,
	squashScaleX = 2,
	squashScaleY = 0.35,

	squashSpeedExtraWidth = 80,
	squashSpeedSpeedX = 2,
	squashSpeedSpeedY = -4,

	stunTime = 16,

	splitID = splitID,
	splitCount = splitCount,

	popEffectID = popEffectID,
	popEffectScale = 1.5,

	mildeSize = ai.SIZE.BIG,
},ai.sharedSettings)

npcManager.setNpcSettings(mildeSettings)
npcManager.registerHarmTypes(npcID,
	{
		HARM_TYPE_FROMBELOW,
		HARM_TYPE_NPC,
		HARM_TYPE_PROJECTILE_USED,
		HARM_TYPE_LAVA,
		HARM_TYPE_HELD,
		HARM_TYPE_TAIL,
		HARM_TYPE_OFFSCREEN,
		HARM_TYPE_SWORD
	},
	{
		[HARM_TYPE_JUMP]            = deathEffectID,
		[HARM_TYPE_FROMBELOW]       = deathEffectID,
		[HARM_TYPE_NPC]             = deathEffectID,
		[HARM_TYPE_PROJECTILE_USED] = deathEffectID,
		[HARM_TYPE_HELD]            = deathEffectID,
		[HARM_TYPE_TAIL]            = deathEffectID,
		[HARM_TYPE_LAVA]            = {id=13, xoffset=0.5, xoffsetBack = 0, yoffset=1, yoffsetBack = 1.5},
		[HARM_TYPE_SPINJUMP]        = 10,
	}
)


ai.register(npcID)


return milde