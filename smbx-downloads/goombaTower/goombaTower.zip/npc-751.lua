-------------------------
--   GOOMBA TOWER v1   --
--  Made by MrDoubleA  --
--                     --
--  Bits of code taken --
--   from grrrol.lua   --
-- by Saturnyoshi & Enj--
-------------------------

-- For whatever reason, setting the height does not seem to work in older versions of PGE.

local npcManager = require("npcManager")
local colliders = require("colliders")
local imagic = require("imagic")
local pnpc = require("pnpc")
local rng = require("rng")

local goombaTower = {}
local npcID = NPC_ID

local goombaTowerSettings = {
	id = npcID,
	
	gfxwidth = 32,
	gfxheight = 32,
	width = 32,
	height = 32,
	
	gfxoffsetx = 0,
	gfxoffsety = 2,
	
	speed = 1,
	iswalker = true,
	
	npcblock = false,
	npcblocktop = false,
	playerblock = false,
	playerblocktop = false,

	nohurt=false,
	nogravity = false,
	noblockcollision = false,
	nofireball = false,
	noiceball = false,
	noyoshi= false,
	nowaterphysics = false,
	
	jumphurt = false,
	spinjumpsafe = false,
	harmlessgrab = false,
	harmlessthrown = false,
}

--Applies NPC settings
npcManager.setNpcSettings(goombaTowerSettings)

--Registers the category of the NPC. Options include HITTABLE, UNHITTABLE, POWERUP, COLLECTIBLE, SHELL. For more options, check expandedDefines.lua
npcManager.registerDefines(npcID, {NPC.HITTABLE})

--Register the vulnerable harm types for this NPC. The first table defines the harm types the NPC should be affected by, while the second maps an effect to each, if desired.
npcManager.registerHarmTypes(npcID,
	{
		HARM_TYPE_JUMP,
		HARM_TYPE_FROMBELOW,
		HARM_TYPE_NPC,
		HARM_TYPE_PROJECTILE_USED,
		HARM_TYPE_LAVA,
		HARM_TYPE_HELD,
		HARM_TYPE_TAIL,
		HARM_TYPE_SPINJUMP,
		HARM_TYPE_OFFSCREEN,
		HARM_TYPE_SWORD
	}, 
	{[HARM_TYPE_LAVA]={id=13, xoffset=0.5, xoffsetBack = 0, yoffset=1, yoffsetBack = 1.5},}
)

local cam = Camera.get()[1]
local camCol = colliders.Box(cam.x,cam.y,cam.width,cam.height)

--This function is from grrrol.lua
function drawNPCFrame(id,frame,x,y,angle)
	local settings = npcManager.getNpcSettings(id)
	local priority = -45
	if settings.foreground then
		priority = -15
	end
	imagic.Draw{
		texture = Graphics.sprites.npc[id].img,
		sourceWidth = settings.gfxwidth,
		sourceHeight = settings.gfxheight,
		sourceY = frame * settings.gfxheight,
		scene = true,
		x = x + settings.gfxoffsetx + settings.gfxwidth  * 0.5,
		y = y + settings.gfxoffsety + settings.gfxheight * 0.5,
		rotation = angle,
		align = imagic.ALIGN_CENTRE,
		priority = priority
	}
end

function changeSize(v,width,height)
	if width == v.width and height == v.height then return end
	local data = v.data
	v.x = (v.x + (v.width / 2)) - (width / 2)
	v.width = width
	
	v.y = (v.y + v.height) - height
	v.height = height
end

function getRealStack(v)
	local data = v.data
	local stack = {}
	for i=1,#data.stack do
		if data.stack[i].state >= 0 then
			table.insert(stack,i)
		end
	end
	return stack
end

function stackMemberKill(a,i)
	a.state = -1
	if i % 2 == 0 then
		a.speedX = rng.random(-4,-2)
	else
		a.speedX = rng.random(2,4)
	end
	a.speedY = rng.random(-5,-7)
end

--Register events
function goombaTower.onInitAPI()
	npcManager.registerEvent(npcID, goombaTower, "onTickNPC")
	--npcManager.registerEvent(npcID, goombaTower, "onTickEndNPC")
	npcManager.registerEvent(npcID, goombaTower, "onDrawNPC")
	
	registerEvent(goombaTower, "onNPCKill")
	registerEvent(goombaTower, "onNPCHarm")
	
	registerEvent(goombaTower,"onTick")
	--registerEvent(goombaTower,"onDraw")
end

function goombaTower.onTick()
	camCol.x,camCol.y = cam.x,cam.y
end

--function goombaTower.onDraw()
	--[[local p = colliders.Box(player.x,player.y,player.width,player.height)
	p:Draw()]]
	--[[Text.print(player:mem(0x14,FIELD_WORD),32,96)
	local c = colliders.Box(player.x + player.width,player.y + 12,38,8)
	c:Draw()
	local a = colliders.Box(player.x,player.y,player.width,player.height)
	a:Draw()]]
	--[[local r = colliders.Box(player.x + player.width,player.y + 36,19,12)
	r:Draw()
	local l = colliders.Box(player.x - 19,player.y + 36,19,12)
	l:Draw()]]
--end

function goombaTower.onNPCKill(eventObj, v, killReason)
	if v.id == npcID and killReason ~= 9 then
		eventObj.cancelled = true
	end
end

function goombaTower.onNPCHarm(killObj, v, killReason, culprit)
	if v.id == npcID and killReason ~= HARM_TYPE_OFFSCREEN then
		v = pnpc.wrap(v)
		local data = v.data
		local realStack = getRealStack(v)
		
		if v:mem(0x156,FIELD_WORD) > 0 then
			-- Invincibility frames
			killObj.cancelled = true
			return
		end
		local lowestKill
		for i=1,#data.stack do
			local a = data.stack[i]
			if a.state >= 0 then
				if killReason == HARM_TYPE_SWORD then
					-- Link's sword
					if player:mem(0x14,FIELD_WORD) == 0 and
					((realStack[1] == i          and v.y + (v.height / 2) > player.y + (player.height / 2))  or
					( realStack[#realStack] == i and v.y + (v.height / 2) < player.y + (player.height / 2))) then
						a.remove = true
						lowestKill = i
						Animation.spawn(63,a.x + (a.width / 2),a.y + (a.height / 2))
					elseif player:mem(0x14,FIELD_WORD) > 0 then
						local c
						if v.direction == -1 then
							c = colliders.Box(player.x + player.width,player.y + 12,38,8)
						else
							c = colliders.Box(player.x - 38,player.y + 12,38,8)
						end
						if c and colliders.collide(a.collider,c) then
							a.remove = true
							lowestKill = i
							Animation.spawn(63,a.x + (a.width / 2),a.y + (a.height / 2))
						end
					end
					v:mem(0x156,FIELD_WORD,20)
				elseif killReason == HARM_TYPE_TAIL then
					-- Tail attack
					local l = colliders.Box(player.x - 19,player.y + 36,19,12)
					local r = colliders.Box(player.x + player.width,player.y + 36,19,12)
					if (colliders.collide(a.collider,l) or colliders.collide(a.collider,r)) then
						stackMemberKill(a,i)
						lowestKill = i
					end
					v:mem(0x156,FIELD_WORD,20)
				elseif killReason == HARM_TYPE_JUMP and realStack[1] == i then
					-- Stomp
					a.state = -2
					lowestKill = i
				elseif killReason == HARM_TYPE_SPINJUMP and realStack[1] == i then
					-- Spin jump
					a.remove = true
					lowestKill = i
					Animation.spawn(10,a.x + (a.width / 2) - 16,a.y + (a.height / 2) - 16)
					Animation.spawn(76,a.x + (a.width / 2)     ,a.y + (a.height / 2)     )
				elseif killReason == HARM_TYPE_FROMBELOW and realStack[#realStack] == i and a.y >= (v.y + v.height - a.height) - .5 and a.speedY == 0 then
					-- Bonked from below
					stackMemberKill(a,i)
					lowestKill = i
				elseif killReason == HARM_TYPE_LAVA and realStack[#realStack] == i and a.y >= (v.y + v.height - a.height) - .5 and a.speedY == 0 then
					-- Lava
					a.remove = true
					lowestKill = i
				elseif culprit and (colliders.collide(a.collider,culprit) or #realStack == 1) then
					-- Hit by something
					stackMemberKill(a,i)
					lowestKill = i
					v:mem(0x156,FIELD_WORD,20)
				elseif not culprit then
					-- "I have no idea what just happened, so I'll just head out."
					stackMemberKill(a,i)
					lowestKill = i
				end
			end
		end
		if not lowestKill then
			killObj.cancelled = true
		else
			for i=1,#data.stack do
				local a = data.stack[i]
				if a.state >= 0 and i < lowestKill then
					a.speedY = -5
				elseif i >= lowestKill then
					break
				end
			end
		end
	end
end

function goombaTower.onTickNPC(v)
	local data = v.data
	
	if v:mem(0x12A, FIELD_WORD) <= 0 then
		data.initialized = false
		data.stack = nil
		return
	end

	--Initialize
	local settings = npcManager.getNpcSettings(v.id)
	if not data.initialized then
		data.initialized = true
		
		data._basegame.stackHeight = data._basegame.stackHeight or 8
		changeSize(v,v.width,data._basegame.stackHeight * settings.height)
		data.stack = {}
		for i=1,data._basegame.stackHeight do
			local y = v.y + ((i - 1) * settings.height)
			table.insert(
				data.stack,
				i,
				{
					--xOffset = 0,
					--yOffset = 0,
					width = settings.width,
					height = settings.height,
					x = v.x,
					y = y,
					frame = 0,
					rot = 0,
					
					state = 0,
					timer = 0,
					speedX = 0,
					speedY = 0,
					collider = colliders.Box(v.x,y,settings.width,settings.height),
					remove = false,
				}
			)
		end
	end
	
	-- Stuff
	
	--[[v.speedX = v.direction * goombaTowerSettings.speed
	if v:mem(0x120,FIELD_BOOL) then
		v.speedX = -v.speedX
		v.direction = -v.direction
	end]]
	
	--[[local c = colliders.Box(v.x,v.y,v.width,v.height)
	c:Draw(0xE6000050)]]
	
	local realStack = getRealStack(v)
	changeSize(v,v.width,#realStack * settings.height)
	
	if Defines.levelFreeze then
		for i=1,#data.stack do
			local a = data.stack[i]
			if a.state == 0 and (v:mem(0x12C, FIELD_WORD) > 0 or v:mem(0x136, FIELD_BOOL) or v:mem(0x138, FIELD_WORD) > 0) then
				a.x = (v.x + (v.width / 2)) - (a.height / 2)
				a.y = v.y + (((i - 1) - (#data.stack - #realStack)) * settings.height)
				a.speedX,a.speedY = 0,0
			end
		end
		return
	end
	
	for i=1,#data.stack do
		local a = data.stack[i]
		if not a then return end
		
		a.collider.x,a.collider.y = a.x,a.y
		--a.collider:Draw()
		
		if a.state == 0 then
			a.x = (v.x + (v.width / 2)) - (a.height / 2)
			if realStack[#realStack] == i then
				if not v.dontMove and a.speedY == 0 then
					a.frame = 2 + (math.floor(lunatime.tick() / 8) % 2)
				elseif a.speedY == 0 then
					a.frame = 0
				else
					a.frame = 1
				end
				--Text.print(v:mem(0x22,FIELD_WORD),32,256)
			elseif a.speedY == 0 then
				a.frame = 0
			else
				a.frame = 1
			end
			if v.direction == 1 then
				a.frame = a.frame + 4
			end
		end
		if a.state == 0 and (v:mem(0x12C, FIELD_WORD) > 0 or v:mem(0x136, FIELD_BOOL) or v:mem(0x138, FIELD_WORD) > 0) then -- Grabbed/thrown/contained in
			a.y = v.y + (((i - 1) - (#data.stack - #realStack)) * settings.height)
			a.speedX,a.speedY = 0,0
		elseif a.state == 0 then
			a.speedY = a.speedY + Defines.npc_grav
			if a.speedY > 8 then
				a.speedY = 8
			end
			a.y = a.y + a.speedY
			
			if realStack[#realStack] == i then
				-- Bottom
				if a.y + a.height > v.y + v.height then
					a.y = v.y + v.height - a.height
					a.speedY = 0
				end
			else
				for t=(i+1),#data.stack do
					if data.stack[t] and data.stack[t].state >= 0
					and a.y + a.height > data.stack[t].y then
						a.y = data.stack[t].y - a.height
						a.speedY = 0
						break
					end
				end
			end
		elseif a.state == -1 then
			a.rot = (a.rot + (a.speedX * 6))-- % 360
			a.x = a.x + a.speedX
			a.speedY = a.speedY + Defines.npc_grav
			if a.speedY > 12 then
				a.speedY = 12
			end
			a.y = a.y + a.speedY
			a.frame = 8
			
			-- Despawn
			if a.y > cam.y + cam.height then
				a.remove = true
			end
		elseif a.state == -2 then
			a.timer = a.timer + 1
			a.frame = 9
			if a.timer >= 20 then
				a.remove = true
			end
		end
	end
	for i=1,#data.stack do
		if data.stack[i].remove then
			table.remove(data.stack,i)
			break
		end
	end
	
	if #realStack == 0 then
		v:mem(0xDC,FIELD_WORD,0)
		v:mem(0x128,FIELD_BOOL,false)
		v:mem(0x12A,FIELD_WORD,180)
		v.friendly = true
		v.dontMove = true
		if #data.stack == 0 then
			v:harm(HARM_TYPE_OFFSCREEN)
		end
	end
end

function goombaTower.onDrawNPC(v)
	v.animationFrame = -1
	local data = v.data
	-- This code for checking that the NPC actually should be drawn taken from grrrol.lua
	--if v:mem(0x144, FIELD_WORD) > 0 then return end
	if v:mem(0x12A, FIELD_WORD) > 0 and not v.layerObj.isHidden and v:mem(0x124,FIELD_WORD) ~= 0 and data.initialized then
		local settings = npcManager.getNpcSettings(v.id)
		
		for i=1,#data.stack do
			local a = data.stack[i]
			drawNPCFrame(
				v.id,
				a.frame,
				math.floor(a.x),
				math.floor(a.y),
				a.rot
			)
		end
	end
end

--Gotta return the library table!
return goombaTower