local slm = require("simpleLayerMovement")

slm.addLayer{name = "down looping",verticalMovement = slm.MOVEMENT_LOOP,verticalSpeed = 1.25,verticalDistance = 256}
slm.addLayer{name = "vertical sine 1",verticalMovement = slm.MOVEMENT_COSINE,verticalSpeed = 60,verticalDistance = 1.1}
slm.addLayer{name = "vertical sine 2",verticalMovement = slm.MOVEMENT_COSINE,verticalSpeed = 60,verticalDistance = -1.1}


local pipeEntranceIdx = 1
local pipeExitIdx = 2

local hasRisenPipe = false
local raisePipeRoutineObj

local function raisePipeRoutine()
    hasRisenPipe = true


    local layer = Layer.get("rising pipe")
    local entrance = Warp(pipeEntranceIdx-1)
    local exit = Warp(pipeExitIdx-1)

    entrance.isHidden = true
    exit.isHidden = true


    -- Wait until the player is done warping
    while (player.forcedState > 0) do
        Routine.skip()
    end

    Routine.wait(0.5)

    -- You raise me up
    local raiseDistance = 128
    local raiseSpeed = -1.25

    local raisedDistance = 0


    layer.speedY = raiseSpeed

    while (raisedDistance < raiseDistance) do
        if not layer:isPaused() then
            raisedDistance = raisedDistance + math.abs(layer.speedY)

            entrance.entranceY = entrance.entranceY + layer.speedY
            exit.exitY = exit.exitY + layer.speedY
        end

        Routine.skip()
    end


    layer.speedY = 0
    entrance.isHidden = false
    exit.isHidden = false

    SFX.play(37)
end

function onLoadSection0()
    if player:mem(0x15E,FIELD_WORD) == pipeExitIdx and not hasRisenPipe then
        raisePipeRoutineObj = Routine.run(raisePipeRoutine)
    end
end

function onReset(fromRespawn)
    if raisePipeRoutineObj ~= nil and raisePipeRoutineObj.isValid then
        raisePipeRoutineObj:abort()
        raisePipeRoutineObj = nil
    end

    hasRisenPipe = false
end