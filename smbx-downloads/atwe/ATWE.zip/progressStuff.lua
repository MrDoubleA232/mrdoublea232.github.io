local starcoin = require("npcs/ai/starcoin")
local levels = require("levels")

local progressStuff = {}


local ACH_BEAT_THE_GAME = 1
local ACH_ALL_THE_THINGS = 2
local ACH_REZNOR = 3
local ACH_ORB = 4


local function updatePercentage()
    local beatenLevelsCount = 0
    local collectedStarCoins = 0

    for _,filename in ipairs(levels.list) do
        local data = levels.data[filename]

        if data.exits ~= nil and #data.exits > 0 and SaveData.smwMap.beatenLevels[filename] then
            beatenLevelsCount = beatenLevelsCount + 1
        end
        if data.starCoins ~= nil then
            local starCoinData = SaveData._basegame.starcoin[filename]

            if starCoinData ~= nil then
                for _,starCoinValue in ipairs(starCoinData) do
                    if starCoinValue == 1 then
                        collectedStarCoins = collectedStarCoins + 1
                    end
                end
            end
        end
    end

    local value = (beatenLevelsCount / #levels.beatableList)*80 + (collectedStarCoins / levels.starCoinCount)*20

    Progress.value = value

    if value >= Progress.maxProgress then
        local a = Achievements.get(ACH_ALL_THE_THINGS)

        a:collect()
    end
end


function progressStuff.onStart()
    updatePercentage()
end

function progressStuff.onTick()
    if Level.filename() == levels.names.map and lunatime.tick()%64 == 0 then
        updatePercentage()
    end

    if SaveData.hasBoughtOrb then
        local a = Achievements.get(ACH_ORB)

        a:collect()
    end
end


function progressStuff.onFinalBossBeat()
    local a = Achievements.get(ACH_BEAT_THE_GAME)

    a:collect()
end

function progressStuff.onReznorBeat()
    local a = Achievements.get(ACH_REZNOR)

    a:collect()
end


function progressStuff.onInitAPI()
    registerEvent(progressStuff,"onStart")
    registerEvent(progressStuff,"onTick")
end


return progressStuff