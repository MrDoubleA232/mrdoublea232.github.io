#version 120
uniform sampler2D iChannel0; // iceBuffer

uniform sampler2D insideBuffer;


#include "shaders/logic.glsl"

void main()
{
	vec4 c = texture2D(iChannel0, gl_TexCoord[0].xy);
	vec4 i = texture2D(insideBuffer, gl_TexCoord[0].xy);
	
	// what it'd be like if there is actually ice there
	vec4 t = c + (i * (1.0 - c.a));

	gl_FragColor = mix(vec4(0.0),t, gt(c.a,0.0))*gl_Color;
}