local levels = {}


local BIRBS_TYPES_NONE = {}
local BIRBS_TYPES_NORMAL = {1,2,3,4}
local BIRBS_TYPES_BLOOPER = {5}
local BIRBS_TYPES_ALL = {1,2,3,4,5}


levels.names = {
    lotus = "lotus.lvlx",
    sewer = "sewer.lvlx",
    sky = "sky.lvlx",
    train = "train.lvlx",
    notSoWatery = "not so watery.lvlx",
    castle = "castle.lvlx",

    yoshisHouse = "the house of the yoshi.lvlx",

    intro = "intro.lvlx",
    map = "map.lvlx",
}


levels.beatableList = {levels.names.lotus,levels.names.sewer,levels.names.sky,levels.names.train,levels.names.notSoWatery,levels.names.castle}

levels.data = {
    [levels.names.lotus]       = {name = "Field of Overly Aggressive Flowers",     exits = {LEVEL_WIN_TYPE_TAPE},                        starCoins = 3, itemBoxColor = Color.fromHexRGB(0xF8C000), birbTypes = {BIRBS_TYPES_NORMAL,BIRBS_TYPES_NONE}                                                            },
    [levels.names.sewer]       = {name = "Koopas and Dolphins, with Soda",         exits = {LEVEL_WIN_TYPE_TAPE},                        starCoins = 3, itemBoxColor = Color.fromHexRGB(0x00903F), birbTypes = {BIRBS_TYPES_NONE,BIRBS_TYPES_NONE,BIRBS_TYPES_NONE,BIRBS_TYPES_NONE,BIRBS_TYPES_ALL}            },
    [levels.names.sky]         = {name = "Sky Level with Indecisive Naming",       exits = {LEVEL_WIN_TYPE_TAPE,LEVEL_WIN_TYPE_SMB3ORB}, starCoins = 3, itemBoxColor = Color.fromHexRGB(0x2A9288), birbTypes = {BIRBS_TYPES_NORMAL,BIRBS_TYPES_NONE,BIRBS_TYPES_NORMAL,BIRBS_TYPES_NONE,BIRBS_TYPES_NONE}       },
    [levels.names.train]       = {name = "The Steelie Wheelie Express",            exits = {LEVEL_WIN_TYPE_TAPE},                        starCoins = 3, itemBoxColor = Color.fromHexRGB(0x8936C1), birbTypes = {}                                                                                               },
    [levels.names.notSoWatery] = {name = "The Water Has Gone Back to Being a Lie", exits = {LEVEL_WIN_TYPE_TAPE},                        starCoins = 3, itemBoxColor = Color.fromHexRGB(0x7E7CC1), birbTypes = {BIRBS_TYPES_BLOOPER,BIRBS_TYPES_BLOOPER,BIRBS_TYPES_BLOOPER,BIRBS_TYPES_BLOOPER,BIRBS_TYPES_ALL}},
    [levels.names.castle]      = {name = "Final and also First Keep",              exits = {LEVEL_WIN_TYPE_SMB3ORB},                     starCoins = 3, itemBoxColor = Color.fromHexRGB(0xB2C7DC), birbTypes = {}                                                                                               },

    [levels.names.yoshisHouse] = {name = "Yoshi's House",                                                                                starCoins = 0, itemBoxColor = Color.fromHexRGB(0x00C800), birbTypes = {BIRBS_TYPES_NORMAL}                                                                             },
    [levels.names.map]         = {},

    [levels.names.intro]       = {},
}


-- Generate lists
do
    levels.list = {}
    levels.beatableList = {}

    levels.starCoinCount = 0

    for filename,data in pairs(levels.data) do
        table.insert(levels.list,filename)

        if data.exits ~= nil and #data.exits > 0 then
            table.insert(levels.beatableList,filename)
        end

        if data.starCoins ~= nil then
            levels.starCoinCount = levels.starCoinCount + data.starCoins
        end
    end
end


levels.musicNames = {
    ["music/Sutte Hakkun - Stage 1 - Ported by Tamaki.spc"]                           = "Sutte Hakkun - Stage 1\nSMW port by Tamaki",
    ["music/Sonic 3 & Knuckles - Hydrocity Act 1 - Ported by Giftshaven.spc"]         = "Sonic 3 & Knuckles - Hydrocity Act 1\nSMW port by Giftshaven",
    ["music/Super Mario 64 - Dire Dire Docks - Ported by bebn legg.spc"]              = "Super Mario 64 - Dire Dire Docks\nSMW port by bebn legg",
    ["music/Mango Mountain - By Dispace.spc"]                                         = "Mango Mountain\nBy Dispace",
    ["music/Kirby Super Star - Boss Battle - Ported by Anas.spc"]                     = "Kirby Super Star - Boss Battle\nSMW port by Anas",
    ["music/Donkey Kong Country 2 - Disco Train - Ported by HaruMKT.spc"]             = "Donkey Kong Country 2 - Disco Train\nSMW port by HaruMKT",
    ["music/Mega Man 2 - Bubble Man - Ported by Jimmy.spc"]                           = "Mega Man 2 - Bubble Man\nSMW port by Jimmy",
    ["music/Yoshi's Island - Castle.spc"]                                             = "SMW2: Yoshi's Island - Castle / Fortress",
    ["music/Yoshi's Island - Room Before Boss.spc"]                                   = "SMW2: Yoshi's Island - Room Before Boss",
    ["music/Yoshi's Island - Kamek's Theme.spc"]                                      = "SMW2: Yoshi's Island - Kamek's Theme",
    ["music/Hollow Knight - Mantis Lords - Ported by Maxodex.spc"]                    = "Hollow Knight - Mantis Lords\nSMW port by Maxodex",
    ["music/Mario and Luigi Bowser's Inside Story - Toad Town I - Ported by SNN.spc"] = "Mario & Luigi: Bowser's Inside Story - Toad Town I\nSMW port by S.N.N.",
    ["music/Kirby's Adventure - Rainbow Resort Map - Ported by tcdw.spc"]             = "Kirby's Adventure - Rainbow Resort Map\nSMW port by tcdw",
    ["music/Super Mario 3D Land - Special World 8 (Remix) - By RednGreen.spc"]        = "Super Mario 3D Land - Special World 8 (Remix)\nBy RednGreen",
}


return levels