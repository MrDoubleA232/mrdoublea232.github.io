local littleDialogue = require("littleDialogue")

for i = 1,10 do
    littleDialogue.registerAnswer("test",{text = "Yes",addText = "<size 2>GOOD!</size>"})
    littleDialogue.registerAnswer("test",{text = "No",addText = "...|How dare you..."})
    littleDialogue.registerAnswer("test",{text = "Maybe",addText = "Come back later, once you've made up your mind..."})
end