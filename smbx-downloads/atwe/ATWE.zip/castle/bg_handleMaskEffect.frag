#version 120
uniform sampler2D iChannel0; // not actually used

uniform sampler2D backBuffer;
uniform sampler2D frontBuffer;

uniform vec2 cameraSize;

#include "shaders/logic.glsl"

void main()
{
	vec2 xy = gl_FragCoord.xy/cameraSize;

	vec4 b = texture2D(backBuffer, xy);
	vec4 f = texture2D(frontBuffer, xy);

    // if pink, show clouds (b), otherwise show castle (transparent)
	vec4 c = mix(b,vec4(0.0), lt(f.r*f.b - f.g,1.0));
	
	gl_FragColor = c*gl_Color;
}