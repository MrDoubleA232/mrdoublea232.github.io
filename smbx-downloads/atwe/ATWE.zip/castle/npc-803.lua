local npcManager = require("npcManager")
local npcutils = require("npcs/npcutils")

local kamekController = require("bigBadBoss/controller")

local ludwig = {}
local npcID = NPC_ID

kamekController.ludwigID = npcID

local ludwigSettings = {
	id = npcID,
	
	gfxwidth = 64,
	gfxheight = 64,

	gfxoffsetx = 0,
	gfxoffsety = 0,
	
	width = 40,
	height = 32,
	
	frames = 12,
	framestyle = 0,
	framespeed = 8,
	
	speed = 1,
	
	npcblock = false,
	npcblocktop = false, --Misnomer, affects whether thrown NPCs bounce off the NPC.
	playerblock = false,
	playerblocktop = false, --Also handles other NPCs walking atop this NPC.

	nohurt = false,
	nogravity = false,
	noblockcollision = false,
	nofireball = false,
	noiceball = true,
	noyoshi = true,
	nowaterphysics = true,
	
	jumphurt = false,
	spinjumpsafe = false,
	harmlessgrab = false,
	harmlessthrown = false,

	score = 0,

	staticdirection = true,
}

npcManager.setNpcSettings(ludwigSettings)
npcManager.registerHarmTypes(npcID,
	{
		HARM_TYPE_JUMP,
		HARM_TYPE_FROMBELOW,
		HARM_TYPE_NPC,
		HARM_TYPE_PROJECTILE_USED,
		--HARM_TYPE_LAVA,
		HARM_TYPE_HELD,
		HARM_TYPE_TAIL,
		--HARM_TYPE_SPINJUMP,
		--HARM_TYPE_OFFSCREEN,
		HARM_TYPE_SWORD
	},
	{
		--[HARM_TYPE_JUMP]            = 10,
		--[HARM_TYPE_FROMBELOW]       = 10,
		--[HARM_TYPE_NPC]             = 10,
		--[HARM_TYPE_PROJECTILE_USED] = 10,
		--[HARM_TYPE_LAVA]            = {id=13, xoffset=0.5, xoffsetBack = 0, yoffset=1, yoffsetBack = 1.5},
		--[HARM_TYPE_HELD]            = 10,
		--[HARM_TYPE_TAIL]            = 10,
		--[HARM_TYPE_SPINJUMP]        = 10,
		--[HARM_TYPE_OFFSCREEN]       = 10,
		--[HARM_TYPE_SWORD]           = 10,
	}
)


local FLOOR_HEIGHT = 416

local HEALTH = 7


local defeatSound = Misc.resolveSoundFile("bigBadBoss/ludwig_defeat")
local poofSound = Misc.resolveSoundFile("bigBadBoss/ludwig_poof")


local animations = {
	idle = {1},
	walk = {3,2,1, frameDelay = 4,loops = true},

	jump = {8,9, frameDelay = 4,loops = true},
	forwards = {7},

	shell = {10,11,12, frameDelay = 4,loops = true},

	beforeFire = {5},
	afterFire = {6},
}

local function handleAnimation(v,data,config)
	if data.animation ~= data.currentAnimation then
		data.currentAnimation = data.animation
		data.animationTimer = 0
	end

	local animationData = animations[data.animation]
	local frameCount = #animationData

	data.frameIndex = math.floor(data.animationTimer / (animationData.frameDelay or 1))

	if data.frameIndex >= frameCount then
		if animationData.loops then
			data.frameIndex = data.frameIndex % frameCount
		else
			data.frameIndex = frameCount - 1
		end
	end

	data.frameIndex = data.frameIndex + 1

	data.frame = animationData[data.frameIndex] or -1

	data.animationTimer = data.animationTimer + 1
end


local function shootFire(v,data,config, atPlayer,angleOffset,baseSpeed)
	data.animation = "beforeFire"
	Routine.wait(0.15)

	local npc = NPC.spawn(282, v.x + v.width*0.5 + v.width*0.5*v.direction,v.y + v.height - 32, v.section,false,true)

	local speed

	if atPlayer then
		speed = vector((player.x + player.width*0.5) - (npc.x + npc.width*0.5),(player.y + player.height*0.5) - (v.y + v.height*0.5)):normalise()
	else
		speed = vector(v.direction,0)
	end

	speed = speed:rotate((angleOffset or 0) * v.direction) * (baseSpeed or 3.5)


	npc.speedX = speed.x
	npc.speedY = speed.y

	SFX.play(42)

	data.animation = "afterFire"
	Routine.wait(0.1)

	data.animation = "idle"
end


local function jumpAcrossArena(v,data,config)
	local ob = v.sectionObj.origBoundary

	local centre = (ob.left + ob.right) * 0.5
	local floor = (ob.top + FLOOR_HEIGHT)

	local position = vector((v.x + v.width*0.5) - centre,(v.y + v.height) - floor)

	local rotationSpeed = (400 / math.abs(position.x))
	local rotationDirection = math.sign(position.x)
	local rotation = 0

	v.noblockcollision = true
	data.nogravity = true

	data.animation = "jump"

	SFX.play(24)

	while (rotation < 180 and rotation > -180) do
		rotation = rotation - (rotationSpeed * rotationDirection)
		position = position:rotate(rotationDirection * -rotationSpeed)

		v.x = centre + position.x - v.width*0.5
		v.y = floor + position.y - v.height

		data.rotation = rotation*2

		Routine.skip()
	end

	v.direction = rotationDirection

	v.noblockcollision = false
	data.nogravity = false
	data.rotation = 0

	data.animation = "idle"

	v.y = math.min(v.y,floor - v.height)
end


local function mainRoutineFunc(v,data,config)
	local ob = v.sectionObj.origBoundary
	local centre = (ob.left + ob.right) * 0.5

	data.animation = "jump"
	v.speedY = -6

	while (not v.collidesBlockBottom) do
		Routine.skip()
	end

	data.animation = "forwards"
	Routine.wait(0.3)

	npcutils.faceNearestPlayer(v)


	data.animation = "shell"

	v.speedX = -8 * v.direction
	v.speedY = -2

	while (math.abs(centre - (v.x + v.width*0.5)) <= 192 and math.abs(v.speedX) > 0.1) do
		v.speedX = v.speedX * 0.985
		Routine.skip()
	end

	v.speedX = 0
	Routine.wait(0.1)

	data.animation = "idle"
	Routine.wait(0.1)


	for i = 1,2 do
		for j = 1,3 do
			shootFire(v,data,config, false,0)
		end

		Routine.wait(0.8)
	end

	jumpAcrossArena(v,data,config)

	while (true) do
		for k = 1,2 do
			Routine.wait(0.2)

			for i = 1,2 do
				for j = 1,3 do
					shootFire(v,data,config, false,(j - 3) * 18)
				end

				Routine.wait(0.4)
			end

			Routine.wait(0.3)

			jumpAcrossArena(v,data,config)
		end


		local direction = v.direction

		local timer = 0

		Routine.wait(0.5)

		while (((v.x + v.width*0.6) - centre)*direction < 192) do
			npcutils.faceNearestPlayer(v)
			v.speedX = 2 * direction

			data.animation = "walk"

			timer = timer + 1

			if timer == 24 then
				shootFire(v,data,config, true,0)
			elseif timer == 64 then
				shootFire(v,data,config, true,-15)
			elseif timer == 64+12 then
				shootFire(v,data,config, true,0)
			elseif timer == 64+24 then
				shootFire(v,data,config, true,15)
			end
			
			Routine.skip()
		end

		data.animation = "idle"
		v.speedX = 0

		Routine.wait(0.3)

		jumpAcrossArena(v,data,config)
	end
end


function ludwig.onInitAPI()
	npcManager.registerEvent(npcID, ludwig, "onTickNPC")
	npcManager.registerEvent(npcID, ludwig, "onDrawNPC")
	registerEvent(ludwig,"onNPCHarm")
	registerEvent(ludwig,"onPostNPCKill")
end

function ludwig.onTickNPC(v)
	local data = v.data
	
	if v.despawnTimer <= 0 then
		data.initialized = false
		return
	end

	local config = NPC.config[v.id]

	if not data.initialized then
		data.initialized = true


		data.animation = "walk"

		data.currentAnimation = data.animation
		data.animationTimer = 0
		data.frameIndex = 1

		data.frame = 1


		data.scaleX = 1
		data.scaleY = 1
		data.rotation = 0

		data.nogravity = false


		data.hits = 0

		data.defeatTimer = 0


		data.mainRoutine = Routine.run(mainRoutineFunc,v,data,config)
	end

	local isFrozen = (Defines.levelFreeze)

	if data.mainRoutine ~= nil and data.mainRoutine.isValid then
		if isFrozen then
			data.mainRoutine:pause()
		else
			data.mainRoutine:resume()
		end
	end

	if not isFrozen then
		handleAnimation(v,data,config)

		if data.nogravity then
			v.speedY = v.speedY - Defines.npc_grav
		end

		if data.defeatTimer > 0 then
			data.scaleX = math.max(0,data.scaleX - 0.00625)
			data.scaleY = math.max(0,data.scaleY - 0.00625)
			data.rotation = data.rotation + 4

			if data.scaleX <= 0 or data.scaleY <= 0 then
				local e = Effect.spawn(10,v.x + v.width*0.5,v.y + v.height - config.gfxheight*0.5)

				e.x = e.x - e.width *0.5
				e.y = e.y - e.height*0.5

				SFX.play(poofSound)

				v:kill(HARM_TYPE_VANISH)
			end

			data.defeatTimer = data.defeatTimer + 1
		end
	end

	v.despawnTimer = math.max(100,v.despawnTimer)
end


local scalingBuffer = Graphics.CaptureBuffer(64,64)

local RENDER_SCALE = 0.5

function ludwig.onDrawNPC(v)
	if v.despawnTimer <= 0 or v.isHidden then return end

	local config = NPC.config[v.id]
	local data = v.data

	if not data.initialized then return end

	local priority = -44

	if data.sprite == nil then
		data.sprite = Sprite{texture = Graphics.sprites.npc[v.id].img,frames = npcutils.getTotalFramesByFramestyle(v),pivot = Sprite.align.CENTRE}
	end

	scalingBuffer:clear(priority)
	--Graphics.drawBox{x = 0,y = 0,width = scalingBuffer.width,height = scalingBuffer.height,priority = priority,color = Color.red,target = scalingBuffer}

	data.sprite.scale = vector(RENDER_SCALE * data.scaleX,RENDER_SCALE * data.scaleY)

	data.sprite.x = scalingBuffer.width*0.5
	data.sprite.y = scalingBuffer.height*0.5

	data.sprite.rotation = data.rotation

	data.sprite:draw{frame = data.frame,priority = priority,target = scalingBuffer,color = Color.white.. 0.8}
	

	Graphics.drawBox{
		texture = scalingBuffer,priority = priority,sceneCoords = true,centred = true,
		x = v.x + v.width*0.5,y = v.y + v.height - config.gfxheight*0.5,
		width = (scalingBuffer.width / RENDER_SCALE) * -v.direction,height = scalingBuffer.height / RENDER_SCALE,
		sourceWidth = scalingBuffer.width,sourceHeight = scalingBuffer.height,
	}


	npcutils.hideNPC(v)
end


function ludwig.onNPCHarm(eventObj,v,reason,culprit)
	if v.id ~= npcID or reason == HARM_TYPE_VANISH then return end

	local config = NPC.config[v.id]
	local data = v.data

	eventObj.cancelled = true


	local fromFireball = (reason == HARM_TYPE_NPC and type(culprit) == "NPC" and culprit.id == 13)

	if (reason == HARM_TYPE_JUMP or reason == HARM_TYPE_SPINJUMP) and type(culprit) == "Player" then
		if culprit.x+culprit.width*0.5 < v.x+v.width*0.5 then
			culprit.speedX = -4.5
		else
			culprit.speedX = 4.5
		end
	end


	if data.defeatTimer > 0 then
		return
	end


	local damage = 0

	if fromFireball then
		damage = 0.4
	else
		damage = 1
	end

	if fromFireball then
		SFX.play(9)
	else
		SFX.play(39)
	end

	data.hits = data.hits + damage

	if data.hits >= HEALTH then
		if data.mainRoutine ~= nil and data.mainRoutine.isValid then
			data.mainRoutine:abort()
		end

		v.noblockcollision = true
		data.nogravity = true

		data.rotation = 0
		data.scaleX = 1
		data.scaleY = 1

		data.animation = "forwards"

		v.speedX = 0
		v.speedY = 0

		v.friendly = true

		data.defeatTimer = 1

		SFX.play(defeatSound)
	end
end


function ludwig.onPostNPCKill(v,reason)
	if v.id == npcID then
		local data = v.data

		if data.mainRoutine ~= nil and data.mainRoutine.isValid then
			data.mainRoutine:abort()
		end
	end
end


return ludwig