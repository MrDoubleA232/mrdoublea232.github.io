local npcManager = require("npcManager")
local npcutils = require("npcs/npcutils")

local kamekController = require("bigBadBoss/controller")

local iggy = {}
local npcID = NPC_ID

local projectileID = (npcID + 1)

kamekController.iggyID = npcID

local iggySettings = {
	id = npcID,
	
	gfxwidth = 80,
	gfxheight = 64,

	gfxoffsetx = 0,
	gfxoffsety = 0,
	
	width = 32,
	height = 28,
	
	frames = 11,
	framestyle = 0,
	framespeed = 8,
	
	speed = 1,
	
	npcblock = false,
	npcblocktop = false, --Misnomer, affects whether thrown NPCs bounce off the NPC.
	playerblock = false,
	playerblocktop = false, --Also handles other NPCs walking atop this NPC.

	nohurt = false,
	nogravity = false,
	noblockcollision = false,
	nofireball = false,
	noiceball = true,
	noyoshi = true,
	nowaterphysics = true,
	
	jumphurt = false,
	spinjumpsafe = false,
	harmlessgrab = false,
	harmlessthrown = false,

	score = 0,

	staticdirection = true,
}

npcManager.setNpcSettings(iggySettings)
npcManager.registerHarmTypes(npcID,
	{
		HARM_TYPE_JUMP,
		HARM_TYPE_FROMBELOW,
		HARM_TYPE_NPC,
		HARM_TYPE_PROJECTILE_USED,
		--HARM_TYPE_LAVA,
		HARM_TYPE_HELD,
		HARM_TYPE_TAIL,
		--HARM_TYPE_SPINJUMP,
		--HARM_TYPE_OFFSCREEN,
		HARM_TYPE_SWORD
	},
	{
		--[HARM_TYPE_JUMP]            = 10,
		--[HARM_TYPE_FROMBELOW]       = 10,
		--[HARM_TYPE_NPC]             = 10,
		--[HARM_TYPE_PROJECTILE_USED] = 10,
		--[HARM_TYPE_LAVA]            = {id=13, xoffset=0.5, xoffsetBack = 0, yoffset=1, yoffsetBack = 1.5},
		--[HARM_TYPE_HELD]            = 10,
		--[HARM_TYPE_TAIL]            = 10,
		--[HARM_TYPE_SPINJUMP]        = 10,
		--[HARM_TYPE_OFFSCREEN]       = 10,
		--[HARM_TYPE_SWORD]           = 10,
	}
)


local FLOOR_HEIGHT = 416


local fallSound = Misc.resolveSoundFile("bigBadBoss/iggy_fall")
local poofSound = Misc.resolveSoundFile("bigBadBoss/ludwig_poof")


local animations = {
	idle = {1},
	walk = {3,2,1, loops = true,frameDelay = 4},

	prepareBall = {5,6,7,8,9, frameDelay = 6},
	afterBall = {10,11,1, frameDelay = 6},
}

local function handleAnimation(v,data,config)
	if data.animation ~= data.currentAnimation then
		data.currentAnimation = data.animation
		data.animationTimer = 0
		data.animationFinished = false
	end

	local animationData = animations[data.animation]
	local frameCount = #animationData

	data.frameIndex = math.floor(data.animationTimer / (animationData.frameDelay or 1))

	if data.frameIndex >= frameCount then
		if animationData.loops then
			data.frameIndex = data.frameIndex % frameCount
		else
			data.frameIndex = frameCount - 1
		end

		data.animationFinished = true
	end

	data.frameIndex = data.frameIndex + 1

	data.frame = animationData[data.frameIndex] or -1

	data.animationTimer = data.animationTimer + 1
end


local function throwBall(v,data,config, direction,speedX,speedY)
	v.direction = direction or v.direction
	data.cantFacePlayer = true

	data.animation = "prepareBall"
	data.animationTimer = 0
	data.animationFinished = false

	Routine.skip()

	while (not data.animationFinished) do
		Routine.skip()
	end

	local ball = NPC.spawn(projectileID, v.x + v.width*0.5 + v.direction*24,v.y + v.height - 30, v.section, false,true)

	ball.direction = v.direction
	ball.speedX = (speedX or 3) * ball.direction
	ball.speedY = speedY or 0

	data.animation = "afterBall"

	data.cantFacePlayer = false
	
	SFX.play(25)
end


local function mainRoutineFunc(v,data,config)
	local ob = v.sectionObj.origBoundary
	local centre = (ob.left + ob.right) * 0.5

	npcutils.faceNearestPlayer(v)

	data.animation = "walk"

	Routine.wait(1.5)

	for i = 1,2 do
		throwBall(v,data,config)
		Routine.wait(0.7)
	end

	Routine.wait(0.7)
	

	while (true) do
		for i = -1,1,2 do
			throwBall(v,data,config, v.direction*-i)
			Routine.wait(0.3)
		end

		Routine.wait(1)

		for i = -1,1 do
			local speed = vector(0,-8):rotate(10 * i)

			throwBall(v,data,config, nil,speed.x * v.direction,speed.y)
			Routine.wait(0.15)
		end

		Routine.wait(2.5)

		for i = 1,4 do
			throwBall(v,data,config)
		end

		Routine.wait(1.5)
	end
end


function iggy.onInitAPI()
	npcManager.registerEvent(npcID, iggy, "onTickNPC")
	npcManager.registerEvent(npcID, iggy, "onDrawNPC")
	registerEvent(iggy,"onNPCHarm")
	registerEvent(iggy,"onPostNPCKill")
end

function iggy.onTickNPC(v)
	local data = v.data
	
	if v.despawnTimer <= 0 then
		data.initialized = false
		return
	end

	local config = NPC.config[v.id]

	if not data.initialized then
		data.initialized = true


		data.animation = "idle"

		data.currentAnimation = data.animation
		data.animationTimer = 0
		data.animationFinished = false
		data.frameIndex = 1

		data.frame = 1


		data.scaleX = 1
		data.scaleY = 1
		data.rotation = 0

		data.nogravity = false


		data.hits = 0

		data.fallingTimer = 0

		data.cantFacePlayer = false


		data.mainRoutine = Routine.run(mainRoutineFunc,v,data,config)
	end

	local isFrozen = (Defines.levelFreeze)

	if data.mainRoutine ~= nil and data.mainRoutine.isValid then
		if isFrozen then
			data.mainRoutine:pause()
		else
			data.mainRoutine:resume()
		end
	end

	if not isFrozen then
		handleAnimation(v,data,config)

		if data.animation == "afterBall" and data.animationFinished then
			data.animation = "walk"
		end

		if not data.cantFacePlayer then
			npcutils.faceNearestPlayer(v)
		end


		if data.nogravity then
			v.speedY = v.speedY - Defines.npc_grav
		end

		local b = v.sectionObj.boundary
		local distanceToCentre = (b.left + b.right)*0.5 - (v.x + v.width*0.5)
		local goalSpeed = 0

		if math.abs(distanceToCentre) >= 96 then
			--goalSpeed = math.sign(distanceToCentre)
		end

		v.speedX = math.lerp(v.speedX,goalSpeed,0.03)

		if v.y >= v.sectionObj.boundary.bottom then
			if data.fallingTimer == 8 then
				SFX.play(fallSound)
			elseif data.fallingTimer == 128 then
				SFX.play(poofSound)
				v:kill(HARM_TYPE_VANISH)				
			end

			data.fallingTimer = data.fallingTimer + 1
		else
			data.fallingTimer = 0
		end
	end

	v.despawnTimer = math.max(100,v.despawnTimer)
end


local scalingBuffer = Graphics.CaptureBuffer(64,64)

local RENDER_SCALE = 0.5

function iggy.onDrawNPC(v)
	if v.despawnTimer <= 0 or v.isHidden then return end

	local config = NPC.config[v.id]
	local data = v.data

	if not data.initialized then return end

	local priority = -44

	if data.sprite == nil then
		data.sprite = Sprite{texture = Graphics.sprites.npc[v.id].img,frames = npcutils.getTotalFramesByFramestyle(v),pivot = Sprite.align.CENTRE}
	end

	scalingBuffer:clear(priority)
	--Graphics.drawBox{x = 0,y = 0,width = scalingBuffer.width,height = scalingBuffer.height,priority = priority,color = Color.red,target = scalingBuffer}

	data.sprite.scale = vector(RENDER_SCALE * data.scaleX,RENDER_SCALE * data.scaleY)

	data.sprite.x = scalingBuffer.width*0.5
	data.sprite.y = scalingBuffer.height*0.5

	data.sprite.rotation = data.rotation

	data.sprite:draw{frame = data.frame,priority = priority,target = scalingBuffer,color = Color.white.. 0.8}
	

	Graphics.drawBox{
		texture = scalingBuffer,priority = priority,sceneCoords = true,centred = true,
		x = v.x + v.width*0.5,y = v.y + v.height - config.gfxheight*0.5,
		width = (scalingBuffer.width / RENDER_SCALE) * -v.direction,height = scalingBuffer.height / RENDER_SCALE,
		sourceWidth = scalingBuffer.width,sourceHeight = scalingBuffer.height,
	}


	npcutils.hideNPC(v)
end


function iggy.onNPCHarm(eventObj,v,reason,culprit)
	if v.id ~= npcID or reason == HARM_TYPE_VANISH then return end

	local config = NPC.config[v.id]
	local data = v.data

	eventObj.cancelled = true


	local fromFireball = (reason == HARM_TYPE_NPC and type(culprit) == "NPC" and culprit.id == 13)
	local slidInto = (reason == HARM_TYPE_NPC and player:mem(0x3C,FIELD_BOOL) and Colliders.speedCollide(v,player))

	if (reason == HARM_TYPE_JUMP or reason == HARM_TYPE_SPINJUMP) and type(culprit) == "Player" or slidInto then
		local pushedBackObj = (slidInto and player) or culprit

		if pushedBackObj.x+pushedBackObj.width*0.5 < v.x+v.width*0.5 then
			pushedBackObj.speedX = -4.5
		else
			pushedBackObj.speedX = 4.5
		end
	end


	local slope = Block(v:mem(0x22,FIELD_WORD))

	local pushDirection

	if slidInto then
		if player.x+player.width*0.5 < v.x+v.width*0.5 then
			pushDirection = 1
		else
			pushDirection = -1
		end
	--[[elseif slope ~= nil and slope.isValid and slope.idx > 0 then
		local slopeDirection = Block.config[slope.id].floorslope

		pushDirection = slopeDirection]]
	else
		if type(culprit) == "Player" then
			if culprit.x+culprit.width*0.5 < v.x+v.width*0.5 then
				pushDirection = 1
			else
				pushDirection = -1
			end
		else
			pushDirection = -v.direction
		end
	end

	v.direction = -pushDirection

	if fromFireball then
		v.speedX = pushDirection * 1.5
	else
		v.speedX = pushDirection * 3.5
		--v.speedX = pushDirection * 16
	end

	SFX.play(39)
end


function iggy.onPostNPCKill(v,reason)
	if v.id == npcID then
		local data = v.data

		if data.mainRoutine ~= nil and data.mainRoutine.isValid then
			data.mainRoutine:abort()
		end
	end
end


return iggy