local npcManager = require("npcManager")
local rng = require("rng")

local globalStuff = require("globalStuff")

local torpedoTeds = {}


local allThoseVariableNames = {
	[false] = {x = "x",y = "y",speedX = "speedX",speedY = "speedY",width = "width" ,height = "height",spawnX = "spawnX",spawnY = "spawnY"},
	[true]  = {x = "y",y = "x",speedX = "speedY",speedY = "speedX",width = "height",height = "width" ,spawnX = "spawnY",spawnY = "spawnX"},
}


torpedoTeds.idList = {}
torpedoTeds.idMap = {}


torpedoTeds.sharedSettings = {
	id = npcID,
	framestyle = 1,
	frames = 2,
	jumphurt = 1,
	nogravity = 1,
	noblockcollision = 1,
	nofireball=1,
	noiceball=0,
	noyoshi=1,
	spinjumpsafe = true,
	leftspeed = 3,
	framespeed = 4,
	rightspeed = 3,
	acceleration = 1.035,
	deceleration = 0.975,
	nowaterphysics = -1,
	spawnpriority = -75,
	luahandlesspeed=true,
	staticdirection = true,
	
	icetime = 32,
}


local function hitBlock(block,...) -- Hit a block, but return if it actually did anything
    local oldContent = block.contentID
    local oldInvisible = block:mem(0x5A,FIELD_BOOL)

    local oldHitStart = block:mem(0x52,FIELD_WORD)
    local oldHitEnd = block:mem(0x54,FIELD_WORD)


    block:hit(...)


    return (
        not block.isValid
        or block.layerName == "Destroyed Blocks"

        or oldContent ~= block.contentID
        or oldInvisible ~= block:mem(0x5A,FIELD_BOOL)

        or oldHitStart ~= block:mem(0x52,FIELD_WORD)
        or oldHitEnd ~= block:mem(0x54,FIELD_WORD)

        --or block:mem(0x58,FIELD_BOOL)
    )
end


local function blockFilter(v)
	return (Colliders.FILTER_COL_BLOCK_DEF(v) and not Block.SIZEABLE_MAP[v.id])
end


function torpedoTeds.onTickEndTed(v)
	if Defines.levelFreeze then return end
	local data = v.data._basegame
	
	if v.isHidden or v:mem(0x12A, FIELD_WORD) <= 0 then
		data.tedDirection = nil
		return
	end

    local cfg = NPC.config[v.id]

    local names = allThoseVariableNames[cfg.horizontal]
	
	if data.tedDirection == nil then
		data.tedDirection = v.direction
		if v.direction == 0 then
			data.tedDirection = rng.randomInt(1)
			if data.tedDirection == 0 then data.tedDirection = -1 end
		end
		
		data.frame = 0
		data.frameStyle = cfg.framestyle
		data.animationTimer = 0
		data.frameSpeed = cfg.framespeed
	end
	local heldPlayer = v:mem(0x12C, FIELD_WORD)
	if heldPlayer > 0 then
		data.tedDirection = Player(heldPlayer).direction
	elseif heldPlayer == 0 then
		v.animationFrame = 500
		v.animationTimer = 500

		v:mem(0x136,FIELD_BOOL,false)

		local slowSpeed = (0.1 * data.tedDirection * cfg.speed)

		if math.sign(v[names.speedX]) == -data.tedDirection then
			v[names.speedX] = v[names.speedX] + 0.04*data.tedDirection
		elseif math.abs(v[names.speedX]) < math.abs(slowSpeed) then
			v[names.speedX] = slowSpeed
		elseif v[names.speedX] < -cfg.leftspeed then
			--v[names.speedX] = v[names.speedX] * 0.98
		elseif v[names.speedX] > cfg.rightspeed then
			--v[names.speedX] = v[names.speedX] * 0.98
		else
			v[names.speedX] = v[names.speedX] * cfg.acceleration
			v[names.speedX] = math.clamp(v[names.speedX], -cfg.leftspeed, cfg.rightspeed) * cfg.speed
		end
		
		v[names.speedY] = v[names.speedY] * cfg.deceleration
		data.animationTimer = data.animationTimer + 1/data.frameSpeed
		data.frame = math.floor(data.animationTimer)%cfg.frames

		v.direction = data.tedDirection
		
		if data.animationTimer%2==0 and (not v.dontMove) and ((v[names.speedX] > 0.5) or (v[names.speedX] < -0.5)) then
            local x,y

            if cfg.horizontal then
                x = v.x + 0.5 * v.width
                y = v.y + 0.5 * v.height - 0.5 * v.height * data.tedDirection
            else
                x = v.x + 0.5 * v.width - 0.5 * v.width * data.tedDirection
                y = v.y + 0.5 * v.height
            end

			local a = Effect.spawn(10, x, y)
			a.x = a.x - 0.5 * a.width
			a.y = a.y - 0.5 * a.height
			a[names.speedX] = -data.tedDirection
			a.animationFrame = 2
		end
		local f = 0
		if data.frameStyle == 1 and v.direction == 1 then
			f = cfg.frames
		end
		v.animationFrame = data.frame + f


        local blocks = Colliders.getColliding{a = v,btype = Colliders.BLOCK,filter = blockFilter}

		local explode = false

        for _,block in ipairs(blocks) do
            local didAnything = hitBlock(block, (v.y + v.height - v.speedY) <= (block.y - block.speedY))

            if didAnything or Block.MEGA_STURDY_MAP[block.id] then
				if block.id ~= 90 then
					if block.id == 159 then
						SFX.play(2)
					end

					explode = true
				else
					v.speedX = -v.speedX*0.1
					v.speedY = -v.speedY*0.1

					SFX.play(3)
				end
            end
        end

		if explode then
			local e = Effect.spawn(10,v.x + v.width*0.5,v.y + v.height*0.5)

			e.x = e.x - e.width*0.5
			e.y = e.y - e.height*0.5
			

			local explosionX = v.x + v.width*0.5
			local explosionY = v.y + v.height*0.5

			if cfg.horizontal then
				explosionY = explosionY + v.height*0.25*v.direction
			else
				explosionX = explosionX + v.width*0.25*v.direction
			end

			Explosion.spawn(explosionX,explosionY,globalStuff.explosionID)

			if cfg.horizontal then
				globalStuff.verticalShake = 6
			else
				globalStuff.horizontalShake = 6
			end

			v.animationFrame = -100
			v:kill(HARM_TYPE_VANISH)
		end
	end
end

function torpedoTeds.register(npcID)
	npcManager.registerEvent(npcID, torpedoTeds, "onTickEndNPC", "onTickEndTed")

	table.insert(torpedoTeds.idList,npcID)
	torpedoTeds.idMap[npcID] = true
end

	
return torpedoTeds