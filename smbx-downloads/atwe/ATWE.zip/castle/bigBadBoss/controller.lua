local controller = {}

controller.MAGIC_TYPE = {
    DIRECT    = 0,
    AT_PLAYER = 1,
    SPAWNER   = 2,
}

return controller