local betterSMWCamera = require("betterSMWCamera")
local globalStuff = require("globalStuff")

local someWeatherStuff = require("someWeatherStuff")

local levels = require("levels")

local rooms = require("rooms")


local spikeAI = require("spike_ai")
spikeAI.ballRenderScale = 0.5


local ENTRANCE_SECTION = 20
local ENTRANCE_WARP = 1

local entranceRoutineObj


local rainSound = Misc.resolveSoundFile("rainLoop")
local rainSoundObj

local thunderSound = Misc.resolveSoundFile("thunder")


local doorOpenSFX = Misc.resolveSoundFile("yiDoor_enter")
local doorCloseSFX = Misc.resolveSoundFile("yiDoor_close")


globalStuff.dontSetSectionBounds[ENTRANCE_SECTION] = true
globalStuff.dontSetSectionBounds[10] = true


-- Register layer movement
do
    local slm = require("simpleLayerMovement")

    slm.addLayer{name = "vertical sine 1",verticalMovement = slm.MOVEMENT_COSINE,verticalSpeed = 30,verticalDistance = 1.5}
    slm.addLayer{name = "vertical sine 2",verticalMovement = slm.MOVEMENT_COSINE,verticalSpeed = 30,verticalDistance = -1.5}
end


local function endEntranceScene()
    local warpObj = Warp(ENTRANCE_WARP - 1)

    warpObj.entranceX = player.x
    warpObj.entranceY = player.y

    rooms.spawnPosition.x = warpObj.exitX + warpObj.exitWidth*0.5
    rooms.spawnPosition.y = warpObj.exitY + warpObj.exitHeight
    rooms.spawnPosition.section = Section.getIdxFromCoords(warpObj.exitX,warpObj.exitY,warpObj.exitWidth,warpObj.exitHeight)
end


local function moveLayer(layerObj,distance,startingSpeed,gravity)
    local movedDistance = 0
    local speed = startingSpeed

    while (movedDistance < distance) do
        if not layerObj:isPaused() then
            layerObj.speedY = math.min(distance - movedDistance,speed)
            movedDistance = movedDistance + math.abs(layerObj.speedY)

            speed = speed + gravity
        end

        Routine.skip()
    end

    layerObj.speedY = 0
end


local function entranceRoutine()
    player.section = ENTRANCE_SECTION

    local b = player.sectionObj.boundary

    player.x = b.right - 592
    player.y = b.bottom - 64 - player.height

    betterSMWCamera.cameraData.targets = {vector(b.right,b.bottom)}

    local doorLayer = Layer.get("entrance door")


    -- Walk up to door
    player.speedX = Defines.player_walkspeed

    while (player.x < b.right - 248) do
        player.keys.right = true
        Routine.skip()
    end

    Routine.wait(0.5)

    -- Jump off yoshi
    --[[if player.mount == MOUNT_YOSHI then
        for i = 1,8 do
            player.keys.altJump = true
            Routine.skip()
        end

        while (not player:isOnGround()) do
            player:mem(0xBC,FIELD_WORD,2)
            Routine.skip()
        end

        Routine.wait(0.3)
    end]]

    -- Look up
    for time = 1,64 do
        player.keys.up = true
        Routine.skip()
    end

    Routine.wait(0.25)

    -- Move the door up
    SFX.play(doorOpenSFX)

    moveLayer(doorLayer,96,-1.5,0)

    -- Walk in
    Routine.wait(0.5)

    while (player.x < b.right - 64) do
        player.keys.right = true
        Routine.skip()
    end

    -- Close the door
    Routine.wait(0.5)

    moveLayer(doorLayer,96,0,0.25)

    SFX.play(doorCloseSFX)

    Defines.earthquake = 6

    Routine.wait(0.6)

    endEntranceScene()
end


function onStart()
    if player.section == 0 then
        entranceRoutineObj = Routine.run(entranceRoutine)
    end
end

function onInputUpdate()
    if player.section == ENTRANCE_SECTION then
        for k,_ in pairs(player.keys) do
            player.keys[k] = false
        end
    end
end

function onTickEnd()
    if player.section == ENTRANCE_SECTION then
        if entranceRoutineObj ~= nil and entranceRoutineObj.isValid and player.rawKeys.jump == KEY_PRESSED and lunatime.tick() > 2 then
            entranceRoutineObj:abort()
            endEntranceScene()
        end
    end
end

function onDraw()
    if someWeatherStuff.rainIntensity > 0 then
        if rainSoundObj == nil or not rainSoundObj:isPlaying() then
            rainSoundObj = SFX.play{sound = rainSound,volume = someWeatherStuff.rainIntensity,loops = 0}
        end

        rainSoundObj.volume = someWeatherStuff.rainIntensity

        --[[if Misc.isPaused() and not rainSoundObj:isPaused() then
            rainSoundObj:pause()
        elseif not Misc.isPaused() and rainSoundObj:isPaused() then
            rainSoundObj:resume()
        end]]
    else
        if rainSoundObj ~= nil and rainSoundObj:isPlaying() then
            rainSoundObj:stop()
        end
    end

    --[[if player.keys.up then
        someWeatherStuff.rainIntensity = math.min(1,someWeatherStuff.rainIntensity + 0.05)
    elseif player.keys.down then
        someWeatherStuff.rainIntensity = math.max(0,someWeatherStuff.rainIntensity - 0.05)
    end]]
end

function onTick()
    -- Control rain intensity
    if player.section == 0 or player.section == 20 then
        someWeatherStuff.rainIntensity = 0
    elseif player.section == 1 then
        someWeatherStuff.rainIntensity = math.clamp((player.x - (player.sectionObj.boundary.left + 480)) / 3000,someWeatherStuff.rainIntensity,1)
    elseif player.section ~= 10 then
        if player.section >= 3 then
            someWeatherStuff.lightningActive = true
        end

        someWeatherStuff.rainIntensity = 1
    end


    -- Set camera offset
    if player.section == 10 or player.section == 5 then
        betterSMWCamera.settings.offset.y = 0
    else
        betterSMWCamera.settings.offset.y = -128
    end


    -- Handle the warp that goes either to the spike or ted room
    local platformRoomWarp = Warp(4)

    if SaveData.smwMap.beatenLevels[levels.names.notSoWatery] then
        platformRoomWarp.exitX = -99600 - platformRoomWarp.exitWidth*0.5
        platformRoomWarp.exitY = -97856 - platformRoomWarp.exitHeight
    else
        platformRoomWarp.exitX = -119776 - platformRoomWarp.exitWidth*0.5
        platformRoomWarp.exitY = -120128 - platformRoomWarp.exitHeight
    end


    -- Handle ted focusing
    if player.section ~= 10 then
        betterSMWCamera.cameraData.targets = {}
    end
    
    if player.section == 5 then
        local teds = {}
        local tedCount = 0

        for _,npc in NPC.iterate(770,player.section) do
            if npc.despawnTimer > 0 and npc.spawnId > 0 and npc.spawnY > npc.sectionObj.boundary.bottom-64 then
                table.insert(teds,npc)
                tedCount = tedCount + 1
            end
        end

        if tedCount > 0 then
            local focus = vector.zero2

            for _,npc in ipairs(teds) do
                focus.x = focus.x + (npc.x + npc.width*0.5)/tedCount
                focus.y = focus.y + (npc.y + npc.height - 192)/tedCount
            end

            table.insert(betterSMWCamera.cameraData.targets,focus)
        end

        betterSMWCamera.settings.normalModes[2] = betterSMWCamera.MODE_ALWAYS_IDEAL
    else
        betterSMWCamera.settings.normalModes[2] = betterSMWCamera.MODE_CATCH_UP_CONDITIONAL
    end


    if someWeatherStuff.lightningIntensity > 0 then
        someWeatherStuff.lightningIntensity = math.max(0,someWeatherStuff.lightningIntensity - 0.03)
    elseif someWeatherStuff.lightningActive and someWeatherStuff.rainIntensity >= 1 and RNG.randomInt(1,384) == 1 then
        someWeatherStuff.lightningIntensity = 1
        SFX.play(thunderSound)
    end
end

-- Handle background
local backBuffer = Graphics.CaptureBuffer()
local frontBuffer = Graphics.CaptureBuffer()

function onCameraDraw()
    local bg = player.sectionObj.background

    for _,layer in ipairs(bg.layers) do
        local uniforms = layer.uniforms

        if layer.name == "rain" then
            uniforms.opacity = someWeatherStuff.rainIntensity * 0.7--0.35
            uniforms.defaultBlendingMode = 1 - someWeatherStuff.lightningIntensity*0.7
        elseif layer.name == "rainBGOverlay" then
            layer.opacity = someWeatherStuff.rainIntensity * 0.2
        elseif layer.name == "handleMaskEffect" then
            backBuffer:captureAt(-99)
            frontBuffer:captureAt(-97.9)

            uniforms.backBuffer = backBuffer
            uniforms.frontBuffer = frontBuffer

            uniforms.cameraSize = vector(camera.width,camera.height)
        end
    end

    --bg.fillColor = Color.fromHexRGB(0xF8E0B0):lerp(Color.fromHexRGB(0x000000),someWeatherStuff.rainIntensity)
end

function onFramebufferResize(width,height)
    backBuffer = Graphics.CaptureBuffer()
    frontBuffer = Graphics.CaptureBuffer()
end