#version 120
uniform sampler2D iChannel0;

uniform float opacity;
uniform float defaultBlendingMode;

void main()
{
	vec4 c = texture2D(iChannel0, gl_TexCoord[0].xy);

	c *= mix(1.0,opacity,defaultBlendingMode);
	c.a *= defaultBlendingMode;
	
	gl_FragColor = c*gl_Color;
}