local depthSwitching = require("depthSwitching")
local playerManager = require("playerManager")
local paletteChange = require("paletteChange")

local extendedPlayerStuff = {}


function extendedPlayerStuff.resetValues()
    extendedPlayerStuff.playerPalette = 0

    extendedPlayerStuff.customFrameX = 0
    extendedPlayerStuff.customFrameY = 0

    extendedPlayerStuff.doCustomRendering = true

    extendedPlayerStuff.playerPriority = nil
    extendedPlayerStuff.playerDirection = nil

    extendedPlayerStuff.ignoreState = false
end

extendedPlayerStuff.resetValues()



extendedPlayerStuff.customFrameWidth = 100
extendedPlayerStuff.customFrameHeight = 100

extendedPlayerStuff.customFrameOffset = vector(0,-30)
extendedPlayerStuff.customFrameYoshiOffset = vector(-4,-34)


function extendedPlayerStuff.onInitAPI()
    registerEvent(extendedPlayerStuff,"onTick")
    registerEvent(extendedPlayerStuff,"onDraw")
    registerEvent(extendedPlayerStuff,"onDrawEnd")
end


local oldFrame

function extendedPlayerStuff.onTick()
    extendedPlayerStuff.resetValues()
end

function extendedPlayerStuff.onDraw()
    if (extendedPlayerStuff.playerPalette > 0 or extendedPlayerStuff.customFrameY > 0 or extendedPlayerStuff.playerPriority ~= nil or extendedPlayerStuff.playerDirection ~= nil or extendedPlayerStuff.ignoreState or depthSwitching.currentDepth == depthSwitching.depthValues.BACK) and extendedPlayerStuff.doCustomRendering then
        extendedPlayerStuff.render{}

        oldFrame = player.frame
        player.frame = 50
    end
end

function extendedPlayerStuff.onDrawEnd()
    player.frame = oldFrame or player.frame
    oldFrame = nil
end



local invisibleForcedStates = table.map{FORCEDSTATE_POWERUP_LEAF,FORCEDSTATE_INVISIBLE,FORCEDSTATE_SWALLOWED}

local someBuffer = Graphics.CaptureBuffer(200,200)

local cachedStuff = {}

function extendedPlayerStuff.render(args)
    local character = (args.character or player.character)
    local powerup = (args.powerup or player.powerup)

    local direction = (args.direction or extendedPlayerStuff.playerDirection or player.direction)

    local frameX = (args.frameX or extendedPlayerStuff.customFrameX)
    local frameY = (args.frameY or extendedPlayerStuff.customFrameY)

    local paletteIndex = (args.palette or args.paletteIndex or extendedPlayerStuff.playerPalette)

    local scaleX = (args.scaleX or 1)
    local scaleY = (args.scaleY or 1)
    local rotation = (args.rotation or 0)

    local x = (args.x or player.x)
    local y = (args.y or player.y)

    local priority = (args.priority or extendedPlayerStuff.playerPriority)
    local color = (args.color or Color.white)
    local sceneCoords = (args.sceneCoords ~= false)

    if priority == nil then
        if player.forcedState == FORCEDSTATE_PIPE then
            priority = -70
        else
            priority = -25
        end
    end
    
    if depthSwitching.currentDepth == depthSwitching.depthValues.BACK and Level.winState() ~= LEVEL_END_STATE_KEYHOLE then
        priority = -97
        color = color * depthSwitching.playerBackColor
    end


    local ignoreState = args.ignorestate
    if ignoreState == nil then
        ignoreState = extendedPlayerStuff.ignoreState
    end

    local characterName = playerManager.getName(character)


    -- Do all the cached stuff
    cachedStuff[character] = cachedStuff[character] or {}

    if cachedStuff[character][powerup] == nil then
        local paletteImageName = Misc.resolveGraphicsFile("extendedPlayerStuff/".. characterName.. "-palette-".. powerup.. ".png") or Misc.resolveGraphicsFile("extendedPlayerStuff/".. characterName.. "-palette.png") or ""
        
        local customFramesPath = Misc.resolveGraphicsFile("extendedPlayerStuff/".. characterName.. "-".. powerup.. ".png")
        local customFramesImage

        if customFramesPath ~= nil then
            customFramesImage = Graphics.loadImage(customFramesPath)
        end

        cachedStuff[character][powerup] = {
            paletteImageName = paletteImageName,
            customFramesImage = customFramesImage,
        }
    end

    local theStuff = cachedStuff[character][powerup]


    -- Actually drawing!
    local shader,uniforms = paletteChange.getShaderAndUniforms(paletteIndex,theStuff.paletteImageName)

    if shader ~= nil then
        uniforms.tintColor = color
        color = nil
    end


    if frameY <= 0 then
        -- Draw the usual player
        someBuffer:clear(-100)

        player:render{
            x = someBuffer.width*0.5 - player.width*0.5,y = someBuffer.height*0.5 - player.height*0.5,
            frame = args.frame or player.frame,ignorestate = ignoreState,direction = direction,color = color,
            target = someBuffer,priority = -100,sceneCoords = false,
        }

        Graphics.drawBox{
            x = x + player.width*0.5,y = y + player.height*0.5,
            width = someBuffer.width * scaleX,height = someBuffer.height * scaleY,rotation = rotation,
            texture = someBuffer,centred = true,priority = priority,sceneCoords = sceneCoords,shader = shader,uniforms = uniforms,
        }
    elseif theStuff.customFramesImage ~= nil then
        if not ignoreState and (player.deathTimer > 0 or invisibleForcedStates[player.forcedState] or player:mem(0x142,FIELD_BOOL)) then
            return
        end


        local sourceWidth = extendedPlayerStuff.customFrameWidth
        local sourceHeight = extendedPlayerStuff.customFrameHeight

        local width  = sourceWidth  * scaleX * direction
        local height = sourceHeight * scaleY

        local offset
        if (args.mount or player.mount) == MOUNT_YOSHI then
            offset = extendedPlayerStuff.customFrameYoshiOffset
            offset = vector(offset.x * direction,offset.y + player:mem(0x10E,FIELD_WORD))
        else
            offset = extendedPlayerStuff.customFrameOffset
            offset = vector(offset.x * direction,offset.y)
        end

        Graphics.drawBox{
            texture = theStuff.customFramesImage,priority = priority,sceneCoords = sceneCoords,color = color,

            x = x + player.width*0.5 + offset.x,y = y + player.height + offset.y,
            sourceX = (frameX - 1) * sourceWidth,sourceY = (frameY - 1) * sourceHeight,
            sourceWidth = sourceWidth,sourceHeight = sourceHeight,width = width,height = height,
            rotation = rotation,centred = true,

            shader = shader,uniforms = uniforms,
        }
    end
end


return extendedPlayerStuff