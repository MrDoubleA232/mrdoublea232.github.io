local globalStuff = require("globalStuff")
local smwMap = require("smwMap")

local shopItems

SaveData.mostRecentlyItemsCount = SaveData.mostRecentlyItemsCount or #globalStuff.getShopItems()


local newItemsImage = Graphics.loadImageResolved("newItems.png")

local newItemsMessageActive = false
local newItemsMessageAppearTimer = 0
local newItemsMessageTimer = 0

function onTick()
    shopItems = globalStuff.getShopItems()

    if #smwMap.activeEvents == 0 and smwMap.mainPlayer.state == smwMap.PLAYER_STATE.NORMAL and not newItemsMessageActive then
        if SaveData.hasMetShopKeeper and SaveData.mostRecentlyItemsCount < #shopItems then
            newItemsMessageActive = true
            newItemsMessageAppearTimer = 16
        else
            SaveData.mostRecentlyItemsCount = #shopItems
        end
    elseif newItemsMessageActive and newItemsMessageAppearTimer > 0 then
        newItemsMessageAppearTimer = newItemsMessageAppearTimer - 1

        if newItemsMessageAppearTimer == 0 then
            newItemsMessageTimer = 128
            SFX.play(14)
        end
    elseif newItemsMessageActive and newItemsMessageTimer > 0 then
        newItemsMessageTimer = newItemsMessageTimer - 1

        if newItemsMessageTimer == 0 then
            newItemsMessageActive = false
            SaveData.mostRecentlyItemsCount = #shopItems
        end
    end
end

function onDraw()
    if newItemsMessageActive and newItemsMessageTimer > 0 then
        local levelObj

        for _,obj in ipairs(smwMap.objects) do
            if obj.id == 814 then
                levelObj = obj
                break
            end
        end

        if levelObj ~= nil then
            local opacity = math.min(newItemsMessageTimer / 16)

            local offset = (math.floor(newItemsMessageTimer / 32) % 2) * 2

            Graphics.drawBox{
                texture = newItemsImage,target = smwMap.mainBuffer,priority = -8,centred = true,color = Color.white.. opacity,
                x = levelObj.x - smwMap.camera.x,y = levelObj.y + offset - 48 - smwMap.camera.y,
            }
        end
    end
end