local npcManager = require("npcManager")

local effectconfig = require("game/effectconfig")


local smoke = {}
local npcID = NPC_ID

local smokeSettings = {
	id = npcID,
	
	gfxwidth = 32,
	gfxheight = 32,

	gfxoffsetx = 0,
	gfxoffsety = 0,
	
	width = 32,
	height = 32,
	
	frames = 1,
	framestyle = 0,
	framespeed = 8,
	
	speed = 1,
	
	npcblock = false,
	npcblocktop = false, --Misnomer, affects whether thrown NPCs bounce off the NPC.
	playerblock = false,
	playerblocktop = false, --Also handles other NPCs walking atop this NPC.

	nohurt = true,
	nogravity = true,
	noblockcollision = true,
	nofireball = true,
	noiceball = true,
	noyoshi = true,
	nowaterphysics = true,
	
	jumphurt = true,
	spinjumpsafe = false,
	harmlessgrab = false,
	harmlessthrown = false,

	ignorethrownnpcs = true,
	notcointransformable = true,
}

npcManager.setNpcSettings(smokeSettings)
npcManager.registerHarmTypes(npcID,{},{})

function smoke.onInitAPI()
	npcManager.registerEvent(npcID, smoke, "onTickNPC")
	--npcManager.registerEvent(npcID, smoke, "onTickEndNPC")
	--npcManager.registerEvent(npcID, smoke, "onDrawNPC")
	--registerEvent(smoke, "onNPCKill")
end

function smoke.onTickNPC(v)
	if Defines.levelFreeze then return end
	
	local data = v.data
	
	if v.despawnTimer <= 0 then
		data.initialized = false
		return
	end

	if not data.initialized then
		data.initialized = true
		data.timer = 0
	end

	data.timer = data.timer + 1

	if data.timer >= 80 then
		Effect.spawn(751,v.x + v.width*0.5,v.y + v.height*0.5)
		data.timer = 0
	end
end


function effectconfig.onTick.TICK_YOSHIHOUSESMOKE(v)
	local time = (v.lifetime - v.timer)

	v.speedY = -0.5

	local moveTime = (32 / math.abs(v.speedY))

	if time > moveTime then
		v.speedX = math.cos((time - moveTime) / 32) * 0.5
	else
		v.speedX = 0
	end
end


return smoke