local credits = {}

if not GameData.inCreditsMode then
    return credits
end


local extendedPlayerStuff = require("extendedPlayerStuff")
local betterSMWCamera = require("betterSMWCamera")
local progressStuff = require("progressStuff")
local idleBirbs = require("idleBirbs")
local pauseplus = require("pauseplus")
local textplus = require("textplus")


idleBirbs.neededIdleTime = math.huge
pauseplus.canPause = false


local fonts = {
    [0] = textplus.loadFont("textplus/font/6.ini"),
    [1] = textplus.loadFont("bigFont.ini"),
}


credits.text = {
    1,"CREDITS",
    0,"",
    0,"",
    1,"MAIN CREATOR",
    0,"",
    0,"MrDoubleA",
    0,"",
    0,"",
    1,"BETA TESTING",
    0,"",
    0,"Hatsune Blake",
    0,"Eclipsed",
    0,"Chipss",
    0,"NegativeBread",
    0,"MegaDood",
    0,"",
    0,"",
    1,"GRAPHICS",
    0,"",
    0,"SMW Expanded GFX - Sednaiur     ",
    0,"Pipe Colour Set  - Hatsune Blake",
    0,"Some Mario       - GlacialSiren \nSprites",
    0,"Sewer, Alt.      - LinkStorm Z  \nAthletic, and\nTower tilesets",
    0,"Dark Sewers BG   - Carld923     ",
    0,"Skeletal         - Necho        \nDolphins",
    0,"Wario Land II    - cheat-       \nTrain Tileset      master30\nSMW port",
    0,"",
    1,"MUSIC",
    0,"(All from SMWCentral)",
    0,"",
    0,"Tamaki",
    0,"Giftshaven",
    0,"bebn legg",
    0,"Dispace",
    0,"Anas",
    0,"HaruMKT",
    0,"Jimmy",
    0,"Maxodex",
    0,"S.N.N.",
    0,"tcdw",
    0,"RednGreen",
    0,"",
    1,"SCRIPTS",
    0,"",
    0,"Enjl",
    0,"KBM-Quine",
    0,"",
    0,"",
    0,"<align center>Thank you to the numerous\npeople who gave ideas\nand suggestions!</align>"
}


local creditsScrollY = 0
local walkScrollX = 0

local transitionHighPriority = true
local transitionProgress = 1
local transitionTimer = 0

local forceHoldEgg = true

local kamekX = 0
local kamekY = 0
local kamekTimer = 0
local kamekActive = false
local kamekFlyLength = 512 + 128

local playerFrameX,playerFrameY


local textLayouts = {}

local textColours = {Color.fromHexRGB(0x58F858),Color.fromHexRGB(0xF85858),Color.fromHexRGB(0xF8D870)}


local backgroundsList = {"castle","train","notSoWatery","sky","sewer","lotus"}
local backgroundsData = {}

local currentBGIndex = 1


local yoshiHouseX = -199648
local yoshiHouseY = -200096

local finalSceneRoutineObj


local veryCoolEgg


local yoshiesData = {{1,-144},{0,-80},{2,80},{3,144}}

local function setYoshiesState(yoshies,state)
    for _,npc in ipairs(yoshies) do
        if npc.isValid then
            npc.data.state = state
            npc.data.timer = 0
        end
    end
end

local function makeEggParticles()
    SFX.play(51)

    if veryCoolEgg ~= nil and veryCoolEgg.isValid then
        veryCoolEgg.data.noBouncing = true

        local e = Effect.spawn(57,veryCoolEgg.x + veryCoolEgg.width*0.5 - 8,veryCoolEgg.y + veryCoolEgg.height*0.5)
    end
end


local function finalSceneRoutine()
    Routine.skip()

    player.section = 0
    local sectionObj = player.sectionObj
    local b = sectionObj.boundary

    b.left = b.left - 800
    b.right = b.right + 800
    sectionObj.boundary = b

    betterSMWCamera.cameraData.targets = {vector(yoshiHouseX,yoshiHouseY)}
    
    player.x = yoshiHouseX + 400 + player.width*0.5 + 16
    player.y = yoshiHouseY - player.height - 64
    player.speedX = 0
    player.speedY = 0

    Defines.player_walkspeed = 1.5

    Layer.get("not in credits"):hide(true)
    Layer.get("in credits"):show(true)


    local yoshies = {}
    for _,data in ipairs(yoshiesData) do
        local npc = NPC.spawn(756,yoshiHouseX + data[2],yoshiHouseY,player.section,false,true)

        npc.y = npc.y - npc.height*0.5
        npc.direction = -math.sign(data[2])
        npc.data.variant = data[1]

        table.insert(yoshies,npc)
    end


    Routine.waitFrames(5)


    while (transitionProgress > 0) do
        transitionProgress = math.max(0,transitionProgress - 0.015)
        Routine.skip()
    end

    while (player.x+player.width*0.5 > yoshiHouseX+42) do
        player.keys.left = true
        Routine.skip()
    end

    Routine.wait(0.9)

    for i = 1,48 do
        player.keys.down = true
        Routine.skip()
    end

    forceHoldEgg = false

    for i = 1,8 do
        player.keys.down = true
        Routine.skip()
    end

    Routine.wait(0.8)

    makeEggParticles()

    Routine.wait(0.1)

    setYoshiesState(yoshies,2)

    Routine.wait(0.2)

    playerFrameX,playerFrameY = 1,4

    Routine.wait(1.9)

    for i = 1,2 do
        makeEggParticles()
        Routine.wait(0.8)
    end

    Routine.wait(0.8)

    makeEggParticles()
    if veryCoolEgg ~= nil and veryCoolEgg.isValid then
        veryCoolEgg.data.isYoshi = true
        veryCoolEgg.data.noBouncing = false
    end

    Routine.wait(0.5)

    setYoshiesState(yoshies,1)

    playerFrameX,playerFrameY = nil,nil

    Routine.wait(0.3)

    for k = 1,2 do
        for i = 1,2 do
            for j = 1,5 do
                player.keys.jump = true
                Routine.skip()
            end

            while (not player:isOnGround()) do
                Routine.skip()
            end
        end

        Routine.wait(1)
    end

    betterSMWCamera.cameraData.targets = {vector(yoshiHouseX - 256 - 96,yoshiHouseY)}

    kamekActive = true
    kamekTimer = 0

    Defines.player_walkspeed = nil

    while (player.x > yoshiHouseX-448) do
        player.keys.left = true
        Routine.skip()
    end

    player.speedX = 0
    Routine.wait(0.2)
    player.direction = DIR_RIGHT
    playerFrameX,playerFrameY = 2,3


    while (kamekActive) do
        Routine.skip()
    end
    Routine.wait(0.2)

    playerFrameX,playerFrameY = nil,nil

    Routine.wait(0.7)

    for i = 1,108 do
        player:setFrame(28)
        Routine.skip()
    end

    while (transitionProgress < 1) do
        transitionProgress = math.min(transitionProgress + 0.005)
        Audio.MusicVolume(64 * (1 - transitionProgress))

        Routine.skip()
    end

    player.sectionObj.music = 0

    GameData.inCreditsMode = false
    Level.exit(LEVEL_WIN_TYPE_SMB3ORB)
end


function credits.onStart()
    local colorIndex = 0

    for i = 1,#credits.text,2 do
        local fontID = credits.text[i]
        local font = fonts[fontID]
        local text = credits.text[i+1]

        local color
        if fontID > 0 then
            color = textColours[(colorIndex % #textColours) + 1]
            colorIndex = colorIndex + 1
        end

        if text == "" then
            text = " "
        end


        local layout = textplus.layout(text,nil,{font = font,color = color,xscale = 2,yscale = 2})

        table.insert(textLayouts,layout)
    end

    Graphics.activateHud(false)


    for i = 0,20 do
        Section(i).music = "music/Super Mario 3D Land - Special World 8 (Remix) - By RednGreen.spc|0;g=2.7;"
    end


    for _,name in ipairs(backgroundsList) do
        backgroundsData[name] = {
            background = Graphics.loadImageResolved("credits/".. name.. "_bg.png"),
            ground = Graphics.loadImageResolved("credits/".. name.. "_ground.png"),
        }
    end


    player.section = 1

    veryCoolEgg = NPC.spawn(154,0,0,player.section,false,true)
end


function credits.onInputUpdate()
    for k,v in pairs(player.keys) do
        player.keys[k] = false
    end
end

function credits.onTick()
    local b = player.sectionObj.boundary

    if forceHoldEgg and veryCoolEgg ~= nil and veryCoolEgg.isValid then
        player:mem(0x154,FIELD_WORD,veryCoolEgg.idx+1)
        veryCoolEgg:mem(0x12C,FIELD_WORD,player.idx)
        player:mem(0x62,FIELD_WORD,2)
    end

    if finalSceneRoutineObj == nil then
        player.speedX = -2.5
        player.direction = DIR_LEFT

        player.x = (b.left + b.right) * 0.5 - player.width*0.5 - player.speedX
        player.y = b.bottom - 64 - player.height


        creditsScrollY = creditsScrollY + 0.5
        walkScrollX = walkScrollX - 2

        if lunatime.tick() > 2 then
            transitionTimer = transitionTimer + 1

            if transitionTimer >= 480 then
            --if transitionTimer >= 64 then
                local isFinal = (currentBGIndex >= #backgroundsList)

                transitionProgress = math.min(1,transitionProgress + 0.015)
                transitionHighPriority = transitionHighPriority or isFinal

                if transitionProgress >= 1 then
                    if isFinal then
                        finalSceneRoutineObj = Routine.run(finalSceneRoutine)
                    else
                        currentBGIndex = currentBGIndex + 1
                        transitionTimer = 0
                    end
                end
            elseif transitionProgress > 0 then
                transitionProgress = math.max(0,transitionProgress - 0.015)

                if transitionProgress <= 0 then
                    transitionHighPriority = false
                end
            end
        end
    end

    -- Handle the kamek in the back
    if player.section == 0 then
        local layer = player.sectionObj.background:get("tiny")

        if kamekActive then
            layer.x = math.lerp(500,256,kamekTimer / kamekFlyLength) - 96
            layer.y = math.lerp(-320,-224 + (600 - camera.height)*0.25,kamekTimer / kamekFlyLength) + 24

            kamekTimer = kamekTimer + 1

            layer.hidden = false

            if kamekTimer >= kamekFlyLength then
                kamekActive = false
                SFX.play(36)

                local x = ((camera.x - b.left) * layer.parallaxX) + 16 + layer.x + camera.x - (800 - camera.width)*0.5
                local y = (b.bottom + layer.y) + (600 - camera.height)*0.25 + 16

                local e = Effect.spawn(952,x,y)

                e.x = e.x - e.width *0.5
                e.y = e.y - e.height*0.5
                e.framespeed = 10

                Effect.spawn(76,x,y)

                progressStuff.onFinalBossBeat()
            end
        else
            layer.hidden = true
        end
    end
end

function credits.onTickEnd()
    if playerFrameY ~= nil then
        extendedPlayerStuff.customFrameX = playerFrameX
        extendedPlayerStuff.customFrameY = playerFrameY
    end
end


function credits.onDraw()
    local b = player.sectionObj.boundary

    if finalSceneRoutineObj == nil then
        local y = 0

        for _,layout in ipairs(textLayouts) do
            textplus.render{layout = layout,priority = -1,x = (camera.width - layout.width)*0.5,y = y - creditsScrollY + camera.height}

            y = y + layout.height + 4
        end


        local bgData = backgroundsData[backgroundsList[currentBGIndex]]

        local groundImage = bgData.ground

        for i = 0,math.ceil(camera.width / groundImage.width) do
            Graphics.drawBox{
                texture = groundImage,sceneCoords = true,priority = -65,
                x = b.left + i*groundImage.width - (walkScrollX%groundImage.width),
                y = b.bottom - groundImage.height,
            }
        end

        local bgImage = bgData.background

        for i = 0,math.ceil(camera.width / groundImage.width) do
            Graphics.drawBox{
                texture = bgImage,sceneCoords = true,priority = -95,
                x = b.left + i*bgImage.width - ((walkScrollX * 0.5)%bgImage.width),
                y = b.bottom - bgImage.height,
            }
        end
    end

    -- Transition
    if transitionProgress > 0 then
        local width = (b.right - b.left)
        local height = (b.bottom - b.top) * 0.5 * transitionProgress
        local priority = (transitionHighPriority and -0.9) or -64
        
        Graphics.drawBox{color = Color.black,sceneCoords = true,priority = priority,x = b.left,y = b.top,width = width,height = height}
        Graphics.drawBox{color = Color.black,sceneCoords = true,priority = priority,x = b.left,y = b.bottom - height,width = width,height = height}
    end
end


function credits.onInitAPI()
    registerEvent(credits,"onStart")
    registerEvent(credits,"onTick")
    registerEvent(credits,"onTickEnd")
    registerEvent(credits,"onDraw")
    registerEvent(credits,"onInputUpdate")
end


return credits