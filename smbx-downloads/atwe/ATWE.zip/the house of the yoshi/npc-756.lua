local npcManager = require("npcManager")
local npcutils = require("npcs/npcutils")

local creditsYoshi = {}
local npcID = NPC_ID

local creditsYoshiSettings = {
	id = npcID,
	
	gfxwidth = 80,
	gfxheight = 64,

	gfxoffsetx = 0,
	gfxoffsety = 0,
	
	width = 80,
	height = 64,
	
	frames = 5,
	framestyle = 1,
	framespeed = 8,
	
	speed = 1,
	
	npcblock = false,
	npcblocktop = false, --Misnomer, affects whether thrown NPCs bounce off the NPC.
	playerblock = false,
	playerblocktop = false, --Also handles other NPCs walking atop this NPC.

	nohurt = true,
	nogravity = false,
	noblockcollision = false,
	nofireball = true,
	noiceball = true,
	noyoshi = true,
	nowaterphysics = true,
	
	jumphurt = true,
	spinjumpsafe = false,
	harmlessgrab = false,
	harmlessthrown = false,

	ignorethrownnpcs = true,
}

npcManager.setNpcSettings(creditsYoshiSettings)
npcManager.registerHarmTypes(npcID,{},{})

function creditsYoshi.onInitAPI()
	npcManager.registerEvent(npcID, creditsYoshi, "onTickEndNPC")
	npcManager.registerEvent(npcID, creditsYoshi, "onDrawNPC")
end

function creditsYoshi.onTickEndNPC(v)
	if Defines.levelFreeze then return end
	
	local data = v.data
	
	if v.despawnTimer <= 0 then
		data.initialized = false
		return
	end

	if not data.initialized then
		data.initialized = true
		data.state = 0
		data.timer = 0
	end

	local frame = 0

	if data.state == 1 then
		frame = math.min(2,math.floor(data.timer / 4))
		data.timer = data.timer + 1

		if v.collidesBlockBottom then
			v.speedY = -4
			data.timer = 0
		end
	elseif data.state == 2 then
		frame = math.min(1,math.floor(data.timer / 8)) + 3
		data.timer = data.timer + 1
	end

	v.animationFrame = npcutils.getFrameByFramestyle(v,{frame = frame})
end

function creditsYoshi.onDrawNPC(v)
	if v.despawnTimer <= 0 or v.isHidden then return end

	local config = NPC.config[v.id]
	local data = v.data

	npcutils.drawNPC(v,{sourceX = (data.variant or 0)*config.gfxwidth})
	npcutils.hideNPC(v)
end


return creditsYoshi