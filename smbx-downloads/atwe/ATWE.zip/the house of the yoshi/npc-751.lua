local npcManager = require("npcManager")

local ai = require("walkingYoshi_ai")

local walkingYoshi = {}
local npcID = NPC_ID


local walkingYoshiSettings = table.join({
	id = npcID,
},ai.sharedSettings)

npcManager.setNpcSettings(walkingYoshiSettings)
npcManager.registerHarmTypes(npcID,{},{})


ai.register(npcID)


return walkingYoshi