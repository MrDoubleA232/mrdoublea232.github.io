local npcManager = require("npcManager")
local npcutils = require("npcs/npcutils")

local walkingYoshi = {}


walkingYoshi.sharedSettings = {
	gfxwidth = 96,
	gfxheight = 64,

	gfxoffsetx = 0,
	gfxoffsety = 2,
	
	width = 32,
	height = 64,
	
	frames = 4,
	framestyle = 1,
	framespeed = 8,
	
	speed = 1,
	
	npcblock = false,
	npcblocktop = false, --Misnomer, affects whether thrown NPCs bounce off the NPC.
	playerblock = false,
	playerblocktop = false, --Also handles other NPCs walking atop this NPC.

	nohurt = true,
	nogravity = false,
	noblockcollision = false,
	nofireball = true,
	noiceball = true,
	noyoshi = true,
	nowaterphysics = false,

	ignorethrownnpcs = true,
    notcointransformable = true,
	
	jumphurt = true,
	spinjumpsafe = false,
	harmlessgrab = false,
	harmlessthrown = false,


    turnTime = 16,

    walkFrames = {2,1,0},
}



walkingYoshi.idList = {}
walkingYoshi.idMap  = {}

function walkingYoshi.register(npcID)
	npcManager.registerEvent(npcID, walkingYoshi, "onTickEndNPC")

    table.insert(walkingYoshi.idList,npcID)
    walkingYoshi.idMap[npcID] = true
end

function walkingYoshi.onTickEndNPC(v)
	if Defines.levelFreeze then return end
	
	local data = v.data
	
	if v.despawnTimer <= 0 then
		data.initialized = false
		return
	end

	if not data.initialized then
		data.initialized = true

        data.stopTimer = 0

        data.oldDirection = v.direction
        data.turnDirection = 0

        data.animationTimer = 0
	end


    v.despawnTimer = 180


    local config = NPC.config[v.id]
    local settings = v.data._settings

    if (v.x+v.width*0.5 - v.spawnX+v.spawnWidth*0.5)*v.direction >= settings.walkDistance then
        data.stopTimer = settings.stopTime
        v.direction = -v.direction
    end

    if data.stopTimer > 0 then
        data.stopTimer = math.max(0,data.stopTimer - 1)
        v.speedX = 0
    else
        v.speedX = v.direction * settings.walkSpeed
    end


    if v.direction ~= data.oldDirection then
        data.turnDirection = data.oldDirection
        data.animationTimer = 0

        data.oldDirection = v.direction
    end


    -- Animation
    local direction = v.direction
    local frame

    if data.turnDirection ~= 0 then
        frame = config.frames - 1

        if data.animationTimer <= config.turnTime*0.5 then
            direction = data.turnDirection
        else
            direction = -data.turnDirection
        end

        data.animationTimer = data.animationTimer + 1

        if data.animationTimer >= config.turnTime then
            data.turnDirection = 0
            data.animationTimer = 0
        end
    elseif v.speedX == 0 then
        frame = 0
        data.animationTimer = 0
    else
        frame = config.walkFrames[(math.floor(data.animationTimer / config.framespeed) % #config.walkFrames) + 1]
        data.animationTimer = data.animationTimer + v.speedX
    end

    v.animationFrame = npcutils.getFrameByFramestyle(v,{frame = frame,direction = direction})
end


return walkingYoshi