local extraNPCProperties = require("extraNPCProperties")
local littleDialogue = require("littleDialogue")
local globalStuff = require("globalStuff")
local credits = require("credits")
local levels = require("levels")

local shopKeeperYoshi


-- Initialise
if SaveData.hasMetShopKeeper == nil then
    -- Decide the name the shop keeper yoshi will call you
    local commonNames = {"Martin","Maria","Martha","Matthew"}
    local rareNames = {"Gordon","Metroid","Wario","Luigi","Zelda","Link"}

    if RNG.randomInt(1,6) == 1 then
        SaveData.shopKeeperYoshiName = RNG.irandomEntry(rareNames)
    else
        SaveData.shopKeeperYoshiName = RNG.irandomEntry(commonNames)
    end

    SaveData.hasMetShopKeeper = false
    SaveData.hasBoughtOrb = false
end


local notEnoughCoinsMessages = {
    "Sorry %s, you don't have enough coins for that!",
    "Let's see... oh, you don't have enough coins, sorry.",
    "Hey, that's not enough coins!",
}
local pointlessMessages = {
    "Well, there's no point in you buying that! I won't charge ya for it.",
}
local purchasedMessages = {
    "Thank you!",
    "Good choice!",
    "Thanks!",
}


local lowPowerupReserveIDs = table.map{0,185,9,185,249}


local function addRandomMessage(box,list)
    box:addDialogue(RNG.irandomEntry(list):format(SaveData.shopKeeperYoshiName))
end

local function giveItem(id)
    NPC.spawn(id,player.x,player.y,player.section).animationFrame = -1
end


local latestItem

local shopItems


local function updateItems()
    littleDialogue.deregisterQuestion("shop")

    shopItems = globalStuff.getShopItems()

    for _,item in ipairs(shopItems) do
        local text = ""

        if item.icon ~= nil then
            text = text.. "<image icon_".. item.icon.. ".png> "
        end

        local cost = tostring(item.cost)
        while (#cost < #tostring(2000)) do
            cost = cost.. " "
        end


        text = text.. "$*".. cost.. " ".. item.name


        local chosenFunction = (function(box)
            latestItem = item

            if item.powerupID ~= nil then
                if item.powerupState == PLAYER_BIG and (player.powerup > PLAYER_BIG and not lowPowerupReserveIDs[player.reservePowerup]) or (player.powerup == item.powerupState and player.reservePowerup == item.powerupID) then
                    addRandomMessage(box,pointlessMessages)
                    return
                end

                if SaveData.coins < item.cost then
                    addRandomMessage(box,notEnoughCoinsMessages)
                    return
                end

                if player.powerup ~= item.powerupState and player.reservePowerup ~= item.powerupID then
                    box:addDialogue("Would you like that in your reserve box or just now?<question reserveOrNow>")
                    return
                else
                    addRandomMessage(box,purchasedMessages)
                    giveItem(item.powerupID)

                    SaveData.coins = SaveData.coins - latestItem.cost

                    return
                end
            elseif item.reserveID ~= nil then
                if item.reserveID == player.reservePowerup then
                    addRandomMessage(box,pointlessMessages)
                    return
                end

                if SaveData.coins < item.cost then
                    if item.cost >= 2000 then
                        box:addDialogue("Well, I commend you for attempting to get the joke item.")
                    else
                        addRandomMessage(box,notEnoughCoinsMessages)
                    end

                    return
                end

                player.reservePowerup = item.reserveID
                SaveData.coins = SaveData.coins - item.cost

                if item.cost >= 2000 then
                    box:addDialogue("Huh you... actually have enough coins. That was a joke. Well, a deal's a deal.")
                    SaveData.hasBoughtOrb = true

                    updateItems()
                else
                    addRandomMessage(box,purchasedMessages)
                end

                return
            end

            box:addDialogue("This message shouldn't appear <3")
        end)


        littleDialogue.registerAnswer("shop",{text = text,chosenFunction = chosenFunction})
    end

    littleDialogue.registerAnswer("shop",{text = "No thanks"})
end

updateItems()


littleDialogue.registerAnswer("reserveOrNow",{
    text = "Now",
    chosenFunction = (function(box)
        giveItem(latestItem.powerupID)
        SaveData.coins = SaveData.coins - latestItem.cost
        addRandomMessage(box,purchasedMessages)
    end),
})
littleDialogue.registerAnswer("reserveOrNow",{
    text = "Reserve box",
    chosenFunction = (function(box)
        player.reservePowerup = latestItem.powerupID
        SaveData.coins = SaveData.coins - latestItem.cost
        addRandomMessage(box,purchasedMessages)
        SFX.play(12)
    end),
})


--for i = 1,30 do littleDialogue.registerAnswer("test",{text = "Test ABCDEF ".. i,addText = "Response\nResponse ".. i}) end
--littleDialogue.registerAnswer("test2",{text = "Yes",addText = "DEF<question test>"})


function onTick()
    shopKeeperYoshi = extraNPCProperties.getWithTag("shopKeeper")[1]

    if shopKeeperYoshi ~= nil and shopKeeperYoshi.isValid then
        if not SaveData.hasMetShopKeeper then
            shopKeeperYoshi.msg = "Hey ".. SaveData.shopKeeperYoshiName.. "! (Did I get that right... ?)|Yoshi's told me all about you and your adventures together.|Now we're set up here rather than ol' dinosaur land.|But anyway... I have some items for you, as long as you have enough coins.|So what can I get ya?<question shop>"
        else
            shopKeeperYoshi.msg = "Hey ".. SaveData.shopKeeperYoshiName.. "! What can I get ya?<question shop>"
        end

        --shopKeeperYoshi.msg = shopKeeperYoshi.msg.. "|A|B"
    end

    local otherYoshi = extraNPCProperties.getWithTag("otherYoshi")[1]

    if otherYoshi ~= nil and otherYoshi.isValid then
        if SaveData.smwMap.beatenLevels[levels.names.castle] then
            otherYoshi.msg = "Hey Mario! Thank you so much for going to save my egg, and beat Kamek."
        else
            otherYoshi.msg = "Hey Mario!|You're going to go save my egg, right?|Well, I don't have much for you, but I can wish you good luck!|<wave 2>... Good luck!</wave>"
        end
    end
end

function onMessageBox(eventObj,text,playerObj,npcObj)
    if npcObj == shopKeeperYoshi then
        -- Just started talking...
        SaveData.hasMetShopKeeper = true

        Progress.savename = SaveData.shopKeeperYoshiName
    end
end