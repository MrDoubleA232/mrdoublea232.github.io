--[[

    THIS ITSELF IS NOT SAVE DATA, DO NOT DELETE
    

    GlobalSaveData
    by MrDoubleA

    Literally a few lines, based on savedata.lua.

]]


local serializer = require("ext/serializer")


local globalDataLib = {}

local GlobalSaveData


local filename = "globalSaveData.dat"


local function loadData()
    local f = io.open(Misc.episodePath().. filename,"r")

    if f == nil then
        return {}
    end


    local content = f:read("*a")

    f:close()


    if content == "" then
        return {}
    end


    local s,e = pcall(serializer.deserialize, content, filename)
    if s then
        return e
    else
        pcall(Misc.dialog,"Error loading episode-wide save data. Your save file may be corrupted. Please try reloading the game.\n(NOTE: This is a message produced by the episode, not the engine.)\n\n=============\n".. e)
        return {}
    end
end


local function saveData()
    local f = io.open(Misc.episodePath().. filename,"w")

    if f == nil then
        return
    end

    local data = serializer.serialize(GlobalSaveData)

    f:write(data)
    f:flush()
    f:close()
end


function globalDataLib.onExitLevel(winType)
    saveData()
end


globalDataLib.flush = saveData


function globalDataLib.onInitAPI()
    registerEvent(globalDataLib,"onExitLevel","onExitLevel",false)
end


GlobalSaveData = loadData()

globalDataLib.data = GlobalSaveData


return globalDataLib