local goalTape = require("goalTape_ai")
local levels = require("levels")

local idleBirbs = {}


local birbImage
local flyNoise = Misc.resolveSoundFile("birdflap")

local birbFrames = 5

local birbTypes = {
    {flyNoise = flyNoise,peckNoise = 9,peckVolume = 0.3},
    {flyNoise = flyNoise,peckNoise = 9,peckVolume = 0.3},
    {flyNoise = flyNoise,peckNoise = 9,peckVolume = 0.3},
    {flyNoise = flyNoise,peckNoise = 9,peckVolume = 0.3},
    {flyNoise = 72,peckNoise = 72,peckVolume = 0.7},
}


idleBirbs.neededIdleTime = lunatime.toTicks(12)
--idleBirbs.neededIdleTime = lunatime.toTicks(1)


idleBirbs.idleTime = 0


idleBirbs.birbObj = {}
local birb = idleBirbs.birbObj

local BIRB_STATE = {
    NOT_THERE = 0,
    FLY_IN = 1,
    SIT = 2,
    PECK = 3,
    TURN = 4,
    FLY_AWAY = 5,
}

local onHeadStates = table.map{BIRB_STATE.SIT,BIRB_STATE.PECK,BIRB_STATE.TURN}


local function resetBirb()
    birb.state = BIRB_STATE.NOT_THERE
    birb.timer = 0

    birb.direction = DIR_LEFT

    birb.x = 0
    birb.y = 0

    birb.type = 1
    birb.frame = 1

    birb.flyAwayTimer = 0
    birb.persistance = 0
end

resetBirb()


local headOffsets = {
    [MOUNT_NONE] = {
        [PLAYER_SMALL] = {-4,8},
        [PLAYER_BIG]   = {2,4},
    },
    [MOUNT_YOSHI] = {
        [PLAYER_SMALL] = {16,24},
        [PLAYER_BIG]   = {2,14},
    }
}

local function getHeadPosition()
    local headX = player.x + player.width*0.5
    local headY = player.y

    local offset = headOffsets

    offset = offset[player.mount] or offset[MOUNT_NONE]
    offset = offset[player.powerup] or offset[PLAYER_BIG]
    
    if player:mem(0x12E,FIELD_BOOL) then
        offset = offset[2]
    else
        offset = offset[1]
    end

    headY = headY + (offset or 0)

    if player.mount ~= MOUNT_NONE then
        headY = headY + player:mem(0x10E,FIELD_WORD)
    end

    return headX,headY
end


function idleBirbs.onTickEnd()
    local levelData = levels.data[Level.filename()]

    if player.forcedState == FORCEDSTATE_NONE and player:mem(0x34,FIELD_WORD) == 0 and player.speedX == 0 and player:isOnGround() and not player.isMega then
        idleBirbs.idleTime = idleBirbs.idleTime + 1
    else
        idleBirbs.idleTime = 0
    end


    if idleBirbs.idleTime >= idleBirbs.neededIdleTime then
        local types
        if levelData ~= nil and levelData.birbTypes ~= nil then
            types = levelData.birbTypes[player.section+1]
        end

        if birb.state == BIRB_STATE.NOT_THERE and types ~= nil and #types > 0 then
            resetBirb()

            birb.state = BIRB_STATE.FLY_IN
            birb.timer = 0

            birb.direction = RNG.irandomEntry{player.direction,DIR_LEFT,DIR_RIGHT}

            if RNG.randomInt(1,50) == 1 then
                birb.persistance = math.huge
            elseif RNG.randomInt(1,3) > 1 then
                birb.persistance = 12
            else
                birb.persistance = 4
            end

            birb.type = RNG.irandomEntry(types)

            SFX.play(birbTypes[birb.type].flyNoise)
        end

        birb.flyAwayTimer = 0
    elseif birb.state ~= BIRB_STATE.FLY_AWAY and birb.state ~= BIRB_STATE.NOT_THERE then
        if idleBirbs.idleTime == 0 and onHeadStates[birb.state] then
            birb.flyAwayTimer = birb.flyAwayTimer + 1
        else
            birb.flyAwayTimer = 0
        end
        
        if birb.flyAwayTimer >= birb.persistance or not onHeadStates[birb.state] then
            birb.state = BIRB_STATE.FLY_AWAY
            birb.timer = 0

            if birb.state ~= BIRB_STATE.FLY_IN then
                SFX.play(birbTypes[birb.type].flyNoise)
            end
        end
    end


    local headX,headY = getHeadPosition()

    
    if birb.state == BIRB_STATE.FLY_IN then
        local t = (1 - math.clamp(birb.timer / 80))

        birb.x = headX - t*80*birb.direction
        birb.y = headY - t*450

        birb.frame = (math.floor(birb.timer / 3) % 2) + 3

        birb.timer = birb.timer + math.lerp(0.2,1,t)

        if t <= 0 then
            birb.state = BIRB_STATE.SIT
            birb.timer = 0
        end
    elseif birb.state == BIRB_STATE.SIT then
        birb.x = headX
        birb.y = headY

        birb.frame = 1

        birb.timer = birb.timer + 1

        if RNG.randomInt(1,128) == 1 or birb.timer >= 144 then
            if RNG.randomInt(1,3) > 1 then
                birb.state = BIRB_STATE.PECK
                birb.timer = RNG.randomInt(4,8)

                SFX.play(birbTypes[birb.type].peckNoise,birbTypes[birb.type].peckVolume)
            else
                birb.state = BIRB_STATE.TURN
                birb.timer = 0
            end
        end
    elseif birb.state == BIRB_STATE.PECK then
        birb.x = headX
        birb.y = headY

        birb.frame = 2

        birb.timer = birb.timer - 1

        if birb.timer <= 0 then
            birb.state = BIRB_STATE.SIT
            birb.timer = 0
        end
    elseif birb.state == BIRB_STATE.TURN then
        birb.x = headX
        birb.y = headY

        birb.frame = 5

        birb.timer = birb.timer + 1

        if birb.timer >= 8 then
            birb.state = BIRB_STATE.SIT
            birb.timer = 0

            birb.direction = -birb.direction
        end
    elseif birb.state == BIRB_STATE.FLY_AWAY then
        birb.x = birb.x + 1*birb.direction
        birb.y = birb.y - (birb.timer*0.15)

        birb.frame = (math.floor(birb.timer / 4) % 2) + 3

        birb.timer = birb.timer + 1

        if birb.y <= camera.y then
            birb.state = BIRB_STATE.NOT_THERE
            birb.timer = 0
        end
    end
end


local function drawBirb(priority,opacity)
    birb.sprite:draw{frame = vector(birb.type,birb.frame),color = Color.white.. opacity,priority = priority,sceneCoords = true}
end


function idleBirbs.onDraw()
    if birb.state ~= BIRB_STATE.NOT_THERE then
        if birb.sprite == nil then
            birbImage = birbImage or Graphics.loadImageResolved("idleBirbs.png")
            birb.sprite = Sprite{texture = birbImage,frames = vector(#birbTypes,birbFrames),pivot = Sprite.align.BOTTOM}
        end

        birb.sprite.x = birb.x
        birb.sprite.y = birb.y

        birb.sprite.width = (birbImage.width / #birbTypes) * -birb.direction
        birb.sprite.texpivot = vector((birb.direction == DIR_RIGHT and 1) or 0,0)

        drawBirb((player.forcedState == FORCEDSTATE_PIPE and -95.1) or -26,1)

        local info = goalTape.playerInfo[1]

        if info ~= nil and info.darkness > 0 then
            drawBirb((info.isOrb and 0.45) or -6.05,info.darkness)
        end
    end
end


function idleBirbs.onInitAPI()
    registerEvent(idleBirbs,"onTickEnd","onTickEnd",false)
    registerEvent(idleBirbs,"onDraw")
end


return idleBirbs