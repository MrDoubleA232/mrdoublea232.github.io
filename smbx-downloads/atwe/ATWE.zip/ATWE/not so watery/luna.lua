local betterSMWCamera = require("betterSMWCamera")
local rooms = require("rooms")


betterSMWCamera.settings.normalModes[2] = betterSMWCamera.MODE_ALWAYS_IDEAL


function onLoadSection1()
    if player.x > -179776 then return end
    
    rooms.spawnPosition.x = -179840
    rooms.spawnPosition.y = -174016
    rooms.spawnPosition.section = 1

    rooms.spawnPosition.direction = DIR_RIGHT

    rooms.spawnPosition.forcedState = 0
    rooms.spawnPosition.forcedTimer = 0
    rooms.spawnPosition.warp = 0

    rooms.spawnPosition.checkpoint = nil
end



-- Checkpoint thing
local checkpointRoutineObj

local function moveLayer(layerObj,speedY,distance)
    local movedDistance = 0

    layerObj.speedY = speedY

    while (movedDistance < distance) do
        if not layerObj:isPaused() then
            movedDistance = movedDistance + math.abs(layerObj.speedY)
        end

        Routine.skip()
    end
    
    layerObj.speedY = 0
end


local function checkpointThing(checkpointIdx,name)
    local lowPriorityLayer = Layer.get(name.. " low")
    local highPriorityLayer = Layer.get(name.. " high")
    local armLayer = Layer.get(name.. " arm")

    if Checkpoint.getActive() == Checkpoint(checkpointIdx) then
        lowPriorityLayer:hide(true)
        highPriorityLayer:show(true)
        armLayer:hide(true)

        return
    end

    lowPriorityLayer:show(true)

    moveLayer(lowPriorityLayer,-1,96)

    Routine.wait(0.5)

    lowPriorityLayer:hide(true)
    highPriorityLayer:show(true)
    armLayer:show(true)

    Routine.wait(0.5)

    moveLayer(armLayer,1,96)

    armLayer:hide(true)
end

function onTick()
    if checkpointRoutineObj == nil and player.x > -170528 then
        checkpointRoutineObj = Routine.run(checkpointThing,1,"checkpoint 1")
    end

    if player.section == 2 and player.x > -153728 then
        local teds = {}
        local tedsCount = 0

        for _,npc in NPC.iterateIntersecting(camera.x,camera.y,camera.x+camera.width,camera.y+camera.height) do
            if npc.despawnTimer > 0 and not npc.isGenerator and npc.id == 757 and npc.spawnId > 0 and npc.spawnY > -160032 then
                table.insert(teds,npc)
                tedsCount = tedsCount + 1
            end
        end

        if tedsCount > 0 then
            local tedsFocus = vector.zero2

            for _,npc in ipairs(teds) do
                tedsFocus.x = tedsFocus.x + (npc.x + npc.width*0.5)/tedsCount
                tedsFocus.y = tedsFocus.y + (npc.y - 128)/tedsCount
            end

            betterSMWCamera.cameraData.targets = {player,tedsFocus,tedsFocus}
        else
            betterSMWCamera.cameraData.targets = {}
        end

        betterSMWCamera.settings.normalModes[1] = betterSMWCamera.MODE_ALWAYS_IDEAL
    elseif #betterSMWCamera.cameraData.targets > 0 then
        betterSMWCamera.cameraData.targets = {}

        betterSMWCamera.settings.normalModes[1] = betterSMWCamera.MODE_CATCH_UP
    end
end

function onReset(fromRespawn)
    if checkpointRoutineObj ~= nil and checkpointRoutineObj.isValid then
        checkpointRoutineObj:abort()
    end

    checkpointRoutineObj = nil
end
