local npcManager = require("npcManager")
local npcutils = require("npcs/npcutils")

local tedAI = require("torpedoted_custom")
local spline = require("spline")


local tedGrabber = {}


tedGrabber.sharedSettings = {
    gfxwidth = 32,
	gfxheight = 32,

	gfxoffsetx = 0,
	gfxoffsety = 0,
	
	width = 32,
	height = 32,
	
	frames = 2,
	framestyle = 0,
	framespeed = 8,
	
	speed = 1,
	
	npcblock = false,
	npcblocktop = false, --Misnomer, affects whether thrown NPCs bounce off the NPC.
	playerblock = false,
	playerblocktop = false, --Also handles other NPCs walking atop this NPC.

	nohurt = true,
	nogravity = true,
	noblockcollision = true,
	nofireball = true,
	noiceball = true,
	noyoshi = true,
	nowaterphysics = true,
	
	jumphurt = true,
	spinjumpsafe = false,
	harmlessgrab = false,
	harmlessthrown = false,

    ignorethrownnpcs = true,
}


local extraGrabbableNPCs = {}


local STATE = {
    WAITING        = 0,
    THROW_START    = 1,
    THROW_WAIT     = 2,
    THROW_YEET     = 3,
    THROW_SLOWDOWN = 4,
    THROW_RETURN   = 5,
}

local THROW_DIRECTION = {
    UP    = 0,
    RIGHT = 1,
    DOWN  = 2,
    LEFT  = 3,
}


local defaultRotations = {
    [false] = {[-1] = 0,[1] = 180},
    [true]  = {[-1] = 270,[1] = 90},
}

local directionData = {
    [THROW_DIRECTION.UP]    = {tedID = tedAI.idList[3],tedDirection = -1,speed = vector(0 ,-1)},
    [THROW_DIRECTION.RIGHT] = {tedID = tedAI.idList[1],tedDirection = 1 ,speed = vector(1 ,0 )},
    [THROW_DIRECTION.DOWN]  = {tedID = tedAI.idList[3],tedDirection = 1 ,speed = vector(0 ,1 )},
    [THROW_DIRECTION.LEFT]  = {tedID = tedAI.idList[1],tedDirection = -1,speed = vector(-1,0 )},
}



local throwSound = 75--Misc.resolveSoundFile("yeetus")


local function npcFilter(v)
    return (
        Colliders.FILTER_COL_NPC_DEF(v)
        and v:mem(0x12C,FIELD_WORD) == 0
        and v:mem(0x138,FIELD_WORD) == 0
    )
end


local function getSplinePoints(v,data,config,settings)
    local points = {}

    if config.horizontal then
        local origin = v.x + v.width*0.5 - v.width*0.5*config.direction

        table.insert(points,vector(origin,v.y + v.height*0.5))
        table.insert(points,vector(v.x + v.width*0.5 - (v.width*0.5 - 32)*config.direction,v.y + v.height*0.5))
        
        local offset = vector((v.width - config.width*0.5 + 0.1) * config.direction,0):rotate(data.armRotation)

        table.insert(points,vector(origin + offset.x,v.y + v.height*0.5 + offset.y))
    else
        local origin = v.y + v.height*0.5 - v.height*0.5*config.direction

        table.insert(points,vector(v.x + v.width*0.5,origin))
        table.insert(points,vector(v.x + v.width*0.5,v.y + v.height*0.5 - (v.height*0.5 - 32)*config.direction))
        
        local offset = vector(0,(v.height - config.height*0.5 + 0.1) * config.direction):rotate(data.armRotation)

        table.insert(points,vector(v.x + v.width*0.5 + offset.x,origin + offset.y))
    end

    return points
end


local function getEndOfSplineData(config,spline)
    local endPoint = spline:evaluate(1)
    local nearEndPoint = spline:evaluate(0.9999)

    local rotation = math.deg(math.atan2(endPoint.y - nearEndPoint.y,endPoint.x - nearEndPoint.x)) + 90 - defaultRotations[config.horizontal][config.direction]

    return endPoint,rotation
end


local function getNeededArmRotation(v,data,config,settings)
    local rotation = (settings.throwDirection*90 - defaultRotations[config.horizontal][config.direction]) % 360

    if rotation == 0 then
        return -115
    elseif rotation < 180 then
        return -90
    else
        return 90
    end
end


local function isOnCamera(v)
    return (v.x+v.width > camera.x and v.x < camera.x+camera.width and v.y+v.height > camera.y and v.y < camera.y+camera.height)
end


local function initialise(v,data,config,settings)
    data.initialized = true

    data.state = STATE.NORMAL
    data.timer = 0

    data.grabbedNPC = nil

    if config.horizontal then
        if config.direction == -1 then
            v.x = v.x + v.width - settings.length
            v.spawnX = v.spawnX + v.spawnWidth - settings.length
        end

        v.width = settings.length
        v.spawnWidth = settings.length
    else
        if config.direction == -1 then
            v.y = v.y + v.height - settings.length
            v.spawnY = v.spawnY + v.spawnHeight - settings.length
        end

        v.height = settings.length
        v.spawnHeight = settings.length
    end

    data.armRotation = 0

    data.throwSpeed = 0

    data.spline = spline.new{points = getSplinePoints(v,data,config,settings),smoothness = 0.5}

    data.sprite = nil
    data.grabbedSprite = nil
end


function tedGrabber.onTickEndNPC(v)
	if Defines.levelFreeze then return end
	
	local data = v.data
	
	if v.despawnTimer <= 0 then
		data.initialized = false
		return
	end

    local config = NPC.config[v.id]
    local settings = v.data._settings

	if not data.initialized then
		initialise(v,data,config,settings)
	end

    if data.state == STATE.NORMAL then
        local endPoint,endRotation = getEndOfSplineData(config,data.spline)

        local collider = Colliders.Rect(endPoint.x,endPoint.y,config.width,config.height,endRotation)

        --collider:Draw()

        local grabbedNPC = Colliders.getColliding{a = collider,b = table.append(tedAI.idList,extraGrabbableNPCs),btype = Colliders.NPC,filter = npcFilter}[1]

        if grabbedNPC ~= nil then
            data.state = STATE.THROW_START
            data.timer = 0

            data.grabbedNPC = grabbedNPC

            if tedAI.idMap[data.grabbedNPC.id] then
                local direction = directionData[settings.throwDirection]

                data.grabbedNPC:transform(direction.tedID)
                data.grabbedNPC.direction = direction.tedDirection

                data.throwSpeed = math.clamp(vector(grabbedNPC.speedX,grabbedNPC.speedY).length * 1.75,4,8)
            else
                data.throwSpeed = 4
            end

            if isOnCamera(v) then
                SFX.play(91)
            end
        end

        data.armRotation = math.lerp(data.armRotation,0,0.125)
    elseif data.state == STATE.THROW_START then
        data.timer = math.lerp(data.timer,1,0.15)

        data.armRotation = math.lerp(0,getNeededArmRotation(v,data,config,settings),data.timer)

        if data.timer >= 0.98 then
            data.state = STATE.THROW_WAIT
            data.timer = 0
        end
    elseif data.state == STATE.THROW_WAIT then
        data.timer = data.timer + 1

        if data.timer >= 8 then
            data.state = STATE.THROW_YEET
            data.timer = 0
        end
    elseif data.state == STATE.THROW_YEET then
        local neededRotation = getNeededArmRotation(v,data,config,settings)

        data.timer = data.timer + 0.4
        data.armRotation = data.armRotation - data.timer*math.sign(neededRotation)

        if math.sign(data.armRotation) ~= math.sign(neededRotation) then
            data.state = STATE.THROW_SLOWDOWN

            if data.grabbedNPC ~= nil and data.grabbedNPC.isValid then
                local grabbedConfig = NPC.config[data.grabbedNPC.id]
                local direction = directionData[settings.throwDirection]

                data.grabbedNPC.width = grabbedConfig.width
                data.grabbedNPC.height = grabbedConfig.height
                
                data.grabbedNPC:mem(0x138,FIELD_WORD,0)
                data.grabbedNPC:mem(0x13C,FIELD_DFLOAT,0)

                data.grabbedNPC.speedX = direction.speed.x * data.throwSpeed
                data.grabbedNPC.speedY = direction.speed.y * data.throwSpeed

                if isOnCamera(v) then
                    SFX.play(throwSound)
                end
            end

            data.grabbedNPC = nil
        end
    elseif data.state == STATE.THROW_SLOWDOWN then
        local neededRotation = getNeededArmRotation(v,data,config,settings)

        data.timer = math.max(0,data.timer - 0.35)

        data.armRotation = data.armRotation - data.timer*math.sign(neededRotation)

        if data.timer <= 0 then
            data.state = STATE.NORMAL
            data.timer = 0
        end
    end

    data.spline.points = getSplinePoints(v,data,config,settings)

    if data.grabbedNPC ~= nil and data.grabbedNPC.isValid then
	    v.animationFrame = 0

        -- Update the grabbed NPC
        local endPoint,endRotation = getEndOfSplineData(config,data.spline)
        
        local grabbedConfig = NPC.config[data.grabbedNPC.id]

        data.grabbedNPC.width = math.min(grabbedConfig.width,grabbedConfig.height)
        data.grabbedNPC.height = data.grabbedNPC.width

        data.grabbedNPC.x = endPoint.x - data.grabbedNPC.width*0.5
        data.grabbedNPC.y = endPoint.y - data.grabbedNPC.height*0.5

        data.grabbedNPC.speedX = 0
        data.grabbedNPC.speedY = 0

        data.grabbedNPC:mem(0x138,FIELD_WORD,8)
        data.grabbedNPC:mem(0x13C,FIELD_DFLOAT,5)

        --Colliders.getHitbox(data.grabbedNPC):Draw()
    else
        v.animationFrame = 1
    end
end


local glDrawArgs = {vertexCoords = {}}

local vertexCoords = glDrawArgs.vertexCoords

local vertexCount = 0
local previousVertexCount = 0


local ARM_COLOR = Color.black
local ARM_WIDTH = 8
local ARM_STEP = 4


local function drawArmSpline(v,data,config,settings,priority)
    local length = data.spline.length
    local totalLength = (math.ceil(length / ARM_STEP) * ARM_STEP) - 12

    local previousPosition


    vertexCount = 0


    for distance = 0, totalLength, ARM_STEP do
        local position = data.spline:evaluate(distance / length)

        local x = position.x
        local y = position.y

        local rotation

        if previousPosition ~= nil then
            rotation = math.atan2(position.y - previousPosition.y,position.x - previousPosition.x) + math.pi*0.5
        else
            local forwardPosition = data.spline:evaluate(1 / totalLength)

            rotation = math.atan2(forwardPosition.y - position.y,forwardPosition.x - position.x) + math.pi*0.5
        end


        local width = ARM_WIDTH
        local height = ARM_STEP


        local sinAngle = math.sin(rotation)
        local cosAngle = math.cos(rotation)

        local w1 = cosAngle*width*0.5
        local w2 = sinAngle*width*0.5
        local h1 = sinAngle*height
        local h2 = cosAngle*height

        local topLeftX,topLeftY,topRightX,topRightY

        if vertexCount > 0 then
            topLeftX  = vertexCoords[vertexCount - 11] -- previous one's bottom left
            topLeftY  = vertexCoords[vertexCount - 10]
            topRightX = vertexCoords[vertexCount - 9]  -- previous one's bottom right
            topRightY = vertexCoords[vertexCount - 8]
        else
            topLeftX  = math.floor(x - w1)
            topLeftY  = math.floor(y - w2)
            topRightX = math.floor(x + w1)
            topRightY = math.floor(y + w2)
        end

        vertexCoords[vertexCount+1]  = math.floor(x - h1 - w1) -- bottom left
        vertexCoords[vertexCount+2]  = math.floor(y + h2 - w2)
        vertexCoords[vertexCount+3]  = math.floor(x - h1 + w1) -- bottom right
        vertexCoords[vertexCount+4]  = math.floor(y + h2 + w2)
        vertexCoords[vertexCount+5]  = topLeftX                -- top left
        vertexCoords[vertexCount+6]  = topLeftY

        vertexCoords[vertexCount+7]  = math.floor(x - h1 + w1) -- bottom right
        vertexCoords[vertexCount+8]  = math.floor(y + h2 + w2)
        vertexCoords[vertexCount+9]  = topRightX               -- top right
        vertexCoords[vertexCount+10] = topRightY
        vertexCoords[vertexCount+11] = topLeftX                -- top left
        vertexCoords[vertexCount+12] = topLeftY

        vertexCount = vertexCount + 12

        previousPosition = position
    end


    -- Clear out old vertices
    for i = vertexCount+1, previousVertexCount do
        vertexCoords[i] = nil
    end

    previousVertexCount = vertexCount


    glDrawArgs.color = ARM_COLOR
    glDrawArgs.priority = priority
    glDrawArgs.sceneCoords = true

    Graphics.glDraw(glDrawArgs)
end


function tedGrabber.onDrawNPC(v)
    if v.despawnTimer <= 0 or v.isHidden then return end

    local config = NPC.config[v.id]
    local data = v.data

    local settings = v.data._settings

    if not data.initialized then
        initialise(v,data,config,settings)
    end


    local priority = -55


    -- Arm... extending... thing
    drawArmSpline(v,data,config,settings,priority)


    if data.sprite == nil then
        data.sprite = Sprite{texture = Graphics.sprites.npc[v.id].img,frames = npcutils.getTotalFramesByFramestyle(v),pivot = Sprite.align.CENTRE}
    end

    local endPoint,endRotation = getEndOfSplineData(config,data.spline)

    data.sprite.x = endPoint.x
    data.sprite.y = endPoint.y

    data.sprite.rotation = endRotation

    data.sprite:draw{frame = v.animationFrame+1,priority = priority,sceneCoords = true}


    if data.grabbedNPC ~= nil and data.grabbedNPC.isValid then
        local image = Graphics.sprites.npc[data.grabbedNPC.id].img
        local grabbedConfig = NPC.config[data.grabbedNPC.id]

        local gfxwidth  = (grabbedConfig.gfxwidth  ~= 0 and grabbedConfig.gfxwidth ) or grabbedConfig.width
        local gfxheight = (grabbedConfig.gfxheight ~= 0 and grabbedConfig.gfxheight) or grabbedConfig.height

        if data.grabbedSprite == nil or data.grabbedSprite.texture ~= image then
            data.grabbedSprite = Sprite{texture = image,frames = image.height/gfxheight,pivot = Sprite.align.CENTRE}
        end

        data.grabbedSprite.x = data.sprite.x
        data.grabbedSprite.y = data.sprite.y
        data.grabbedSprite.rotation = data.sprite.rotation

        data.grabbedSprite:draw{frame = data.grabbedNPC.animationFrame+1,priority = priority - 0.1,sceneCoords = true}

        npcutils.hideNPC(data.grabbedNPC)
    end


    npcutils.hideNPC(v)
end


function tedGrabber.register(npcID)
    npcManager.registerEvent(npcID,tedGrabber,"onTickEndNPC")
    npcManager.registerEvent(npcID,tedGrabber,"onDrawNPC")
end


return tedGrabber