local extendedPlayerStuff = require("extendedPlayerStuff")
local depthSwitching = require("depthSwitching")

local expandedNets = {}


depthSwitching.enabled = true


local playerData = {}

expandedNets.playerData = playerData


expandedNets.switcherIDList = {}
expandedNets.switcherIDMap  = {}

function expandedNets.registerSwitcher(id)
    table.insert(expandedNets.switcherIDList,id)
    expandedNets.switcherIDMap[id] = true
end



local function loadImageResolved(path)
    local p = Misc.resolveGraphicsFile(path)

    if p ~= nil then
        return Graphics.loadImage(p)
    else
        return nil
    end
end


--[[local playerSheets = {}

function expandedNets.getPlayerSheet()
    local costume = player:getCostume()

    local img = playerSheets[costume] or playerSheets[player.character]
    if img ~= nil then
        return img
    end


    if costume ~= nil then
        playerSheets[costume] = loadImageResolved("expandedNets_player_".. costume.. ".png")

        if playerSheets[costume] ~= nil then
            return playerSheets[costume]
        end
    end

    playerSheets[player.character] = loadImageResolved("expandedNets_player_".. player.character.. ".png")

    if playerSheets[player.character] ~= nil then
        return playerSheets[player.character]
    end


    return nil
end]]


function expandedNets.onInitAPI()
    registerEvent(expandedNets,"onTick")
    registerEvent(expandedNets,"onDraw")
end


local function hittableNPCFilter(v)
    return (
        v.despawnTimer > 0
        and not v.isGenerator

        and v:mem(0x12C,FIELD_WORD) == 0
        and v:mem(0x138,FIELD_WORD) == 0
        and (v.data.depthSwitching ~= nil and v.data.depthSwitching.depth == -depthSwitching.currentDepth)
    )
end

local function isOnFence()
    return (
        player.climbing
        and (
            player:mem(0x2C,FIELD_DFLOAT) == -1
            or (player.climbingNPC ~= nil and player.climbingNPC.isValid and expandedNets.switcherIDMap[player.climbingNPC.id])
        )
    )
end


local function findFrame()
    --[[if playerData.swappingDepthTimer > 0 then
        local animationProgress = (playerData.swappingDepthTimer/expandedNets.swappingDepthLength)

        if playerData.swappingDepthStartingDepth == depthSwitching.depthValues.BACK then
            animationProgress = 1-animationProgress
        end

        playerData.frame = math.floor(animationProgress*3)+7

        if playerData.swappingDepthMovement < 0 then
            playerData.frame = playerData.frame + 3
        end

        return
    end

    
    if playerData.punchTimer > 0 then
        playerData.frame = 3
        playerData.animationTimer = 0
    else
        if player.speedX ~= 0 or player.speedY < 0 then
            playerData.animationTimer = playerData.animationTimer + 1
        end
    
        playerData.frame = (math.floor(playerData.animationTimer/8)%2)+1
    end

    if depthSwitching.currentDepth == depthSwitching.depthValues.BACK then
        playerData.frame = playerData.frame + 3
    end]]


    if playerData.swappingDepthTimer > 0 then
        local animationProgress = (playerData.swappingDepthTimer / expandedNets.swappingDepthLength)

        if playerData.swappingDepthStartingDepth == depthSwitching.depthValues.BACK then
            animationProgress = 1 - animationProgress
        end

        extendedPlayerStuff.customFrameX = math.floor(math.lerp(1,5,math.clamp(animationProgress)))
        extendedPlayerStuff.customFrameY = 7
        extendedPlayerStuff.ignoreState = true

        playerData.animationTimer = 0
        playerData.hasMoved = false

        if playerData.swappingDepthMovement < 0 then
            extendedPlayerStuff.playerDirection = DIR_RIGHT
        else
            extendedPlayerStuff.playerDirection = DIR_LEFT
        end

        return
    end


    if depthSwitching.currentDepth == depthSwitching.depthValues.FRONT then
        extendedPlayerStuff.customFrameY = 5
    else
        extendedPlayerStuff.customFrameY = 6
    end

    if playerData.punchTimer > 0 then
        extendedPlayerStuff.customFrameX = 4
        playerData.animationTimer = 0
    else
        if player.speedX ~= 0 or player.speedY < 0 then
            playerData.animationTimer = playerData.animationTimer + 1
            playerData.hasMoved = true
        end
    
        if playerData.hasMoved then
            extendedPlayerStuff.customFrameX = (math.floor(playerData.animationTimer / 8) % 2) + 2
        else
            extendedPlayerStuff.customFrameX = 1
        end
    end
end

local function onTickPlayer()
    if not playerData.initialised then
        playerData.initialised = true

        playerData.animationTimer = 0
        playerData.hasMoved = false

        playerData.punchTimer = 0

        playerData.swappingDepthTimer = 0
        playerData.swappingDepthStartingDepth = nil
        playerData.swappingDepthMovement = 0
    end


    if player.deathTimer > 0 then return end


    if playerData.swappingDepthTimer > 0 then
        playerData.swappingDepthTimer = playerData.swappingDepthTimer + 1

        findFrame()

        if playerData.swappingDepthTimer == math.floor(expandedNets.swappingDepthLength*0.5) then
            depthSwitching.setDepth(-depthSwitching.currentDepth)
        elseif playerData.swappingDepthTimer > expandedNets.swappingDepthLength then
            player.forcedState = FORCEDSTATE_NONE
            player.forcedTimer = 0

            playerData.swappingDepthTimer = 0
        end

        player.x = player.x + (playerData.swappingDepthMovement / expandedNets.swappingDepthLength)

        return
    end


    if player.forcedState ~= FORCEDSTATE_NONE or not isOnFence() then
        playerData.initialised = false
        return
    end



    if playerData.punchTimer > 0 then
        playerData.punchTimer = playerData.punchTimer - 1

        player.keys.left = false
        player.keys.right = false
        player.keys.up = false
        player.keys.down = false


        if playerData.punchTimer == 0 then
            -- Hit NPC's
            local npcs = Colliders.getColliding{a = player,b = NPC.HITTABLE,btype = Colliders.NPC,filter = hittableNPCFilter}

            for _,npc in ipairs(npcs) do
                local originallyFriendly = npc.friendly
                npc.friendly = false

                npc:harm(HARM_TYPE_NPC)

                npc.friendly = originallyFriendly
            end

            -- Handle side switching
            local climbingNPC = player.climbingNPC
            if climbingNPC ~= nil and climbingNPC.isValid and expandedNets.switcherIDMap[climbingNPC.id] then
                local npcConfig = NPC.config[climbingNPC.id]

                local x1 = climbingNPC.x+(climbingNPC.width *0.5)-(npcConfig.hittableBoxWidth *0.5)
                local y1 = climbingNPC.y+(climbingNPC.height*0.5)-(npcConfig.hittableBoxHeight*0.5)
                local x2 = x1+npcConfig.hittableBoxWidth
                local y2 = y1+npcConfig.hittableBoxHeight

                if player.x >= x1 and player.x+player.width <= x2 and player.y >= y1 and player.y+player.height <= y2 then
                    player.forcedState = FORCEDSTATE_INVISIBLE
                    player.forcedTimer = 0

                    playerData.swappingDepthTimer = 1
                    playerData.swappingDepthStartingDepth = depthSwitching.currentDepth
                    playerData.swappingDepthMovement = ((climbingNPC.x+(climbingNPC.width*0.5))-(player.x+(player.width*0.5))) * 2

                    SFX.play(35)

                    --depthSwitching.setDepth(-depthSwitching.currentDepth)
                end
            end

            SFX.play(3)
        end
    elseif player.keys.run == KEYS_PRESSED then
        playerData.punchTimer = 8
    end


    findFrame()
end

function expandedNets.onTick()
    onTickPlayer()
end


--[[function expandedNets.onDraw()
    if player.deathTimer == 0 and (player.forcedState == FORCEDSTATE_NONE or playerData.swappingDepthTimer > 0) and playerData.initialised and not player:mem(0x142,FIELD_BOOL) and isOnFence() then
        local img = expandedNets.getPlayerSheet()

        if playerData.sprite == nil or playerData.sprite.texture ~= img then
            playerData.sprite = Sprite{texture = img,frames = vector(7,12),pivot = Sprite.align.CENTRE}
        end

        local color,priority = nil,-25
        if depthSwitching.currentDepth == depthSwitching.depthValues.BACK then
            color = depthSwitching.playerBackColor
            priority = -97
        elseif playerData.swappingDepthTimer > 0 then
            priority = -74
        end


        playerData.sprite.x = math.floor(player.x+(player.width *0.5)+0.5)
        playerData.sprite.y = math.floor(player.y+(player.height*0.5)+0.5)

        playerData.sprite:draw{frame = vector(player.powerup,playerData.frame or 1),priority = priority,color = color,sceneCoords = true}


        playerData.oldRealFrame = player.frame
        player.frame = 51
    end
end

function expandedNets.onDrawEnd()
    if playerData.oldRealFrame ~= nil then
        player.frame = playerData.oldRealFrame
        playerData.oldRealFrame = nil
    end
end]]



expandedNets.swappingDepthLength = 34


return expandedNets