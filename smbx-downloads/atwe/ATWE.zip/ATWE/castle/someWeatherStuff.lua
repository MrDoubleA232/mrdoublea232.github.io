-- This would be in the luna.lua file but multiple files need to use it so
local someWeatherStuff = {}


someWeatherStuff.rainIntensity = 0

someWeatherStuff.lightningActive = false
someWeatherStuff.lightningIntensity = 0


return someWeatherStuff