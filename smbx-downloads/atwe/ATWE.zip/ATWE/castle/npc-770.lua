local npcManager = require("npcManager")
local rng = require("rng")

local tedAI = require("torpedoted_custom")


local torpedoTeds = {}

local npcID = NPC_ID


local tedSettings = table.join({
	id = npcID,
	gfxheight = 64,
	gfxwidth = 32,
	width = 32,
	height = 64,
	horizontal = true,
},tedAI.sharedSettings)

npcManager.registerHarmTypes(npcID, 
	{HARM_TYPE_FROMBELOW, HARM_TYPE_HELD,HARM_TYPE_NPC}, 
	{[HARM_TYPE_FROMBELOW]=164,
	[HARM_TYPE_HELD]=164,
	[HARM_TYPE_NPC]=164,
	[HARM_TYPE_SPINJUMP] = 10,
});

npcManager.setNpcSettings(tedSettings)

tedAI.register(npcID)
	
return torpedoTeds
