--[[

	Written by MrDoubleA
	Please give credit!

	Part of MrDoubleA's NPC Pack

]]

local blockManager = require("blockManager")
local blockutils = require("blocks/blockutils")

local crumblingBlock = {}


crumblingBlock.sharedSettings = {
    shakeTime = 48,
    regenerateTime = 160,

    isVertical = false,

    regenerateSounds = {
        Misc.resolveSoundFile("crumblingBlock_regenerate_1"),
        Misc.resolveSoundFile("crumblingBlock_regenerate_2"),
        Misc.resolveSoundFile("crumblingBlock_regenerate_3"),
        Misc.resolveSoundFile("crumblingBlock_regenerate_4"),
        Misc.resolveSoundFile("crumblingBlock_regenerate_5"),
    },
}


crumblingBlock.idList = {}
crumblingBlock.idMap  = {}

function crumblingBlock.register(blockID)
	blockManager.registerEvent(blockID,crumblingBlock,"onTickBlock")
    blockManager.registerEvent(blockID,crumblingBlock,"onCameraDrawBlock")
    blockManager.registerEvent(blockID,crumblingBlock,"onCollideBlock")

    table.insert(crumblingBlock.idList,blockID)
    crumblingBlock.idMap[blockID] = true
end


function crumblingBlock.onInitAPI()
    registerEvent(crumblingBlock,"onDraw")
    registerEvent(crumblingBlock,"onReset")
end


local STATE_NORMAL  = 0
local STATE_CRUMBLE = 1
local STATE_OUTLINE = 2


local function findBlocks(v,groupBlocks,inGroupMap)
    table.insert(groupBlocks,v)
    inGroupMap[v] = true
    
    v.data.groupBlocks = groupBlocks

    local x1,x2,y1,y2

    if Block.config[v.id].isVertical then
        x1 = v.x + 1
        y1 = v.y - 1
        x2 = v.x + v.width - 1
        y2 = v.y + v.height + 1
    else
        x1 = v.x - 1
        y1 = v.y + 1
        x2 = v.x + v.width + 1
        y2 = v.y + v.height - 1
    end

    for _,b in Block.iterateIntersecting(x1,y1,x2,y2) do
        if not inGroupMap[b] and b.id == v.id and b.layerName == v.layerName then
            findBlocks(b,groupBlocks,inGroupMap)
        end
    end
end


local function startCrumbling(v)
    local mainBlock = v.data.groupMainBlock

    if mainBlock == nil or not mainBlock.isValid then
        return
    end

    local mainBlockData = mainBlock.data
    local config = Block.config[mainBlock.id]

    if mainBlockData.state == STATE_NORMAL then
        mainBlockData.state = STATE_CRUMBLE
        mainBlockData.timer = 0

        local effectConfig = Effect.config[config.effectID][1]

        for _,b in ipairs(mainBlockData.groupBlocks) do
            local effectDirection,effectCount

            if config.isVertical then
                effectDirection = vector(0,effectConfig.height)
                effectCount = math.floor(b.height / effectConfig.height) - 1
            else
                effectDirection = vector(effectConfig.width,0)
                effectCount = math.floor(b.width / effectConfig.width) - 1
            end

            for i = 0, effectCount do
                local x = b.x + i*effectDirection.x
                local y = b.y + i*effectDirection.y
                local variant = (i % effectConfig.variants) + 1

                local e = Effect.spawn(config.effectID,x,y,variant)

                table.insert(mainBlockData.effects,e)
            end
        end
    end

    mainBlockData.isTouched = true
end


function crumblingBlock.onTickBlock(v)
	local data = v.data
	
    if not data.initialized then
        data.state = STATE_NORMAL
        data.timer = 0

        if data.groupBlocks == nil then
            data.groupMainBlock = v

            findBlocks(v,{},{})

            -- Find size of group
            local minX,minY = math.huge,math.huge
            local maxX,maxY = -math.huge,-math.huge

            for _,b in ipairs(data.groupBlocks) do
                minX = math.min(minX,b.x)
                minY = math.min(minY,b.y)
                maxX = math.max(maxX,b.x + b.width)
                maxY = math.max(maxY,b.y + b.height)
            end

            data.groupX = minX
            data.groupY = minY
            data.groupWidth = maxX - minX
            data.groupHeight = maxY - minY
        else
            data.groupMainBlock = data.groupBlocks[1]
        end

        data.effects = {}
        data.useOutline = false

        data.isTouched = false

        data.layerObj = v.layerObj
        
        data.initialized = true
    end


    local speedX,speedY = 0,0

    if data.groupMainBlock == v and data.layerObj ~= nil and not data.layerObj:isPaused() then
        speedX = data.layerObj.speedX
        speedY = data.layerObj.speedY

        data.groupX = data.groupX + speedX
        data.groupY = data.groupY + speedY
    end


    local config = Block.config[v.id]

    if data.state == STATE_CRUMBLE then
        data.timer = data.timer + 1

        if data.timer >= config.shakeTime --[[or not data.isTouched]] then
            data.state = STATE_OUTLINE
            data.timer = 0

            data.useOutline = true

            for _,b in ipairs(data.groupBlocks) do
                b.isHidden = true
            end
            
            SFX.play(4)
        else
            for _,effectSpawner in ipairs(data.effects) do
                effectSpawner.x = effectSpawner.x + speedX
                effectSpawner.y = effectSpawner.y + speedY

                for _,effect in ipairs(effectSpawner.effects) do
                    effect.x = effectSpawner.x + RNG.random(-1.5,1.5)
                    effect.y = effectSpawner.y + RNG.random(-1.5,1.5)
                    effect.speedY = 0

                    data.useOutline = true
                end
            end
        end
    elseif data.state == STATE_OUTLINE then
        data.timer = data.timer + 1

        if data.timer >= config.regenerateTime then
            local objectInside = false

            for _,p in ipairs(Player.getIntersecting(data.groupX,data.groupY,data.groupX+data.groupWidth,data.groupY+data.groupHeight)) do
                objectInside = true
                break
            end

            for _,n in NPC.iterateIntersecting(data.groupX,data.groupY,data.groupX+data.groupWidth,data.groupY+data.groupHeight) do
                if not NPC.config[n.id].noblockcollision and not n.noblockcollision and n.despawnTimer > 0 then
                    objectInside = true
                    break
                end
            end


            if not objectInside then
                data.state = STATE_NORMAL
                data.timer = 0

                data.useOutline = false

                for i = 1, #data.effects do
                    data.effects[i] = nil
                end

                for _,b in ipairs(data.groupBlocks) do
                    b.isHidden = false
                end


                local isOnScreen = false

                for _,b in ipairs(data.groupBlocks) do
                    if blockutils.isOnScreen(b,32) then
                        local e = Effect.spawn(10,b.x + b.width*0.5,b.y + b.height*0.5)

                        e.x = e.x - e.width*0.5
                        e.y = e.y - e.height*0.5

                        isOnScreen = true
                    end
                end
                
                if isOnScreen then
                    SFX.play(RNG.irandomEntry(config.regenerateSounds))
                end
            end
        end
    end

    data.isTouched = false
end


function crumblingBlock.onCameraDrawBlock(v,camIdx)
    local data = v.data

    if data.groupMainBlock ~= v or not blockutils.visible(Camera(camIdx),data.groupX,data.groupY,data.groupWidth,data.groupHeight) then return end

    local config = Block.config[v.id]

    for _,b in ipairs(data.groupBlocks) do
        local image
        local frameX,frameY
        local width,height
        local priority

        if not data.useOutline then
            image = Graphics.sprites.block[b.id].img
            priority = -64

            width = v.width
            height = v.height
            frameX = 0
            frameY = math.floor(lunatime.drawtick() / config.framespeed) % config.frames
        else
            image = config.outlineImage
            priority = -66.1

            width = image.width / 4
            height = image.height
            frameX = 0
            frameY = 0

            local onNegativeEdge,onPositiveEdge

            if config.isVertical then
                onNegativeEdge = (b.y <= data.groupY)
                onPositiveEdge = (b.y+b.height >= data.groupY+data.groupHeight)
            else
                onNegativeEdge = (b.x <= data.groupX)
                onPositiveEdge = (b.x+b.width >= data.groupX+data.groupWidth)
            end

            if onNegativeEdge then
                if onPositiveEdge then
                    frameX = 3
                else
                    frameX = 0
                end
            elseif onPositiveEdge then
                frameX = 2
            else
                frameX = 1
            end
        end

        Graphics.drawImageToSceneWP(image, b.x,b.y, frameX*width,frameY*height, width,height, priority)
    end
end


function crumblingBlock.onCollideBlock(v,n)
    if type(n) == "Player" then
        if n.forcedState ~= FORCEDSTATE_NONE or n.deathTimer > 0 then
            return
        end
    elseif type(n) == "NPC" then
        if n:mem(0x138,FIELD_WORD) > 0 then
            return
        end

        local config = NPC.config[n.id]

        if config == nil or not config.isheavy or config.noblockcollision or v.noblockcollision then
            return
        end
    end

    startCrumbling(v)
end


function crumblingBlock.onDraw()
    for _,id in ipairs(crumblingBlock.idList) do
        blockutils.setBlockFrame(id,-1000)
    end
end


function crumblingBlock.onReset(fromRespawn)
    -- jank fix
    for _,b in Block.iterate(crumblingBlock.idList) do
        local data = b.data

        data.initialized = false
        data.groupBlocks = nil
    end
end


return crumblingBlock