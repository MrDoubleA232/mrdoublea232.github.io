--[[

    smwMap.lua
    by MrDoubleA

    See main file for more

]]

local smwMap = require("smwMap")


local npcID = NPC_ID
local obj = {}


local smokeID = 797

-- If true, the smoke will show up even (greyed out) even if the level itself is locked.
local showSmokeIfLocked = true


smwMap.setObjSettings(npcID,{
    framesY = 2,

    onTickObj = (function(v)
        v.frameY = smwMap.doBasicAnimation(v,smwMap.getObjectConfig(v.id).framesY,8)

        -- Spawn chimney smoke
        if not v.isOffScreen and (v.lockedFade == 0 or (showSmokeIfLocked and not v.hideIfLocked)) and v.data.animationTimer%50 == 1 then
            local smoke = smwMap.createObject(smokeID,v.x - 8, v.y + v.height*0.5 - 32 - 16)

            smoke.lockedFade = v.lockedFade
            smoke.hideIfLocked = v.hideIfLocked
        end
    end),

    isLevel = true,
})


return obj