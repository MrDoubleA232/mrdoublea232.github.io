local blockManager = require("blockManager")
local betterSMWCamera = require("betterSMWCamera")

local cameraLocker = {}
local blockID = BLOCK_ID

local cameraLockerSettings = {
	id = blockID,

	passthrough = true,
}

blockManager.setBlockSettings(cameraLockerSettings)


function cameraLocker.onInitAPI()
	blockManager.registerEvent(blockID, cameraLocker, "onTickBlock")
end

function cameraLocker.onTickBlock(v)
    local data = v.data

	if data.layerObj == nil or data.layerObj.name ~= v.layerName then
		data.layerObj = v.layerObj
		v.isHidden = true
	end
end


betterSMWCamera.cameraLockerID = blockID


return cameraLocker