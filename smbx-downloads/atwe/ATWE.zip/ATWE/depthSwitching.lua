local blockutils = require("blocks/blockutils")
local npcutils = require("npcs/npcutils")
local sizeable = require("game/sizable")

local depthSwitching = {}

depthSwitching.depthValues = {
    BACK = -1,
    FRONT = 1,

    MIDDLE = 0, -- don't set the current depth to this! only used for stuff like blocks
}


depthSwitching.enabled = false


depthSwitching.currentDepth = depthSwitching.depthValues.FRONT


depthSwitching.npcPassthroughLava = 756
depthSwitching.playerPassthroughLava = 757


local BLOCK_IS_LAVA_ADDR = mem(0x00B2C064,FIELD_DWORD)


local function getData(v)
    v.data.depthSwitching = v.data.depthSwitching or {}
    return v.data.depthSwitching
end


local blockIDsAtBack = {
    [depthSwitching.depthValues.BACK] = {
        -- back blocks become npc passthrough
        751, -- passthrough
        687, -- solid
        1283, -- semisolid
        1285, -- floorslope = -1
        1284, -- floorslope = 1
        1286, -- ceilingslope = 1
        1287, -- ceilingslope = -1
        depthSwitching.npcPassthroughLava, -- lava
    },
    [depthSwitching.depthValues.FRONT] = {
        -- front blocks become player passthrough
        751, -- passthrough
        658, -- solid
        1282, -- semisolid
        752, -- floorslope = -1
        753, -- floorslope = 1
        754, -- ceilingslope = 1
        755, -- ceilingslope = -1
        --depthSwitching.playerPassthroughLava, -- lava
        751,
    },
}

-- Blocks that will stay as is when the current depth is at the back. Done to avoid some weirdness.
local backExceptionIDs = table.map{
    88, -- smw ? block
}

local function getNewBlockID(oldID,blockDepth,currentDepth)
    local oldConfig = Block.config[oldID]

    if blockDepth == depthSwitching.depthValues.MIDDLE then
        return nil
    end

    if currentDepth == depthSwitching.depthValues.BACK then
        if blockDepth == depthSwitching.depthValues.BACK and backExceptionIDs[oldID] then
            return nil
        end


        local ids = blockIDsAtBack[blockDepth]

        if oldConfig.passthrough then
            return ids[1]
        elseif oldConfig.semisolid or oldConfig.sizeable then
            return ids[3]
        elseif oldConfig.floorslope == -1 then
            return ids[4]
        elseif oldConfig.floorslope == 1 then
            return ids[5]
        elseif oldConfig.ceilingslope == 1 then
            return ids[6]
        elseif oldConfig.ceilingslope == -1 then
            return ids[7]
        elseif mem(BLOCK_IS_LAVA_ADDR + oldID*0x02,FIELD_BOOL) then -- lava
            return ids[8]
        else
            return ids[2]
        end
    elseif blockDepth == depthSwitching.depthValues.BACK then
        return 751
    else
        return nil
    end
end

function depthSwitching.getLayerDepth(name)
    if name:find("^%[Back]") then
        return depthSwitching.depthValues.BACK
    elseif name:find("^%[Front]") then
        return depthSwitching.depthValues.FRONT
    end
end


-- NPC's that just copy the depth of the player.
local playerProjectileNPCs = table.map{13,265,171,292,291,266}

local function getNPCDepth(npc)
    local forcedState = npc:mem(0x138,FIELD_WORD)

    if forcedState == 1 or forcedState == 3 then -- if coming out of a block, try to find the block that spawned it and copy its depth
        local x1 = npc.x
        local x2 = npc.x+npc.width
        local y1,y2

        if forcedState == 1 then -- top of a block
            y1 = npc.y + npc.height
            y2 = y1 + 1
        else -- bottom of a block
            y2 = npc.y
            y1 = y2 - 1
        end

        for _,block in Block.iterateIntersecting(x1,y1,x2,y2) do
            local blockData = getData(block)

            if (block:mem(0x52,FIELD_WORD) ~= 0 or block:mem(0x54,FIELD_WORD) ~= 0) and blockData.depth ~= nil and blockData.depth ~= depthSwitching.depthValues.MIDDLE then -- just hit and has a depth to copy
                return blockData.depth
            end
        end

        -- couldn't find a block, so just do the default
    elseif playerProjectileNPCs[npc.id] or forcedState == 2 or (player.keys.dropItem and Colliders.collide(npc,player)) then -- the player's projectiles and dropping items just copy the player's depth
        return depthSwitching.currentDepth
    elseif NPC.config[npc.id] ~= nil and NPC.config[npc.id].iscoin and npc.ai1 == 1 then -- fire coin
        for _,coinSpawner in NPC.iterateIntersecting(npc.x,npc.y,npc.x+npc.width,npc.y+npc.height) do
            local spawnerData = getData(coinSpawner)

            if coinSpawner ~= npc and coinSpawner.despawnTimer > 0 and coinSpawner:mem(0x122,FIELD_WORD) == HARM_TYPE_NPC and coinSpawner.data.hitByFireTime == lunatime.tick() and spawnerData ~= nil then
                return spawnerData.depth
            end
        end
    end

    return depthSwitching.getLayerDepth(npc.layerName) or depthSwitching.depthValues.FRONT
end


function depthSwitching.setDepth(value)
    if not depthSwitching.enabled then
        return
    end


    depthSwitching.affectedBlocks = {}


    -- Affect all blocks (may be slow!)
    for _,block in Block.iterate() do
        local data = getData(block)

        data.depth = data.depth or depthSwitching.getLayerDepth(block.layerName) or depthSwitching.depthValues.MIDDLE
        --data.layerObj = data.layerObj or block.layerObj

        if data.originalID ~= nil then
            block.id = data.originalID
            data.originalID = nil
        end
        

        local newID = getNewBlockID(block.id,data.depth,value)

        if newID ~= nil then
            data.originalID = block.id
            block.id = newID
        end
    end

    depthSwitching.currentDepth = value
end


function depthSwitching.onInitAPI()
    registerEvent(depthSwitching,"onStart")
    registerEvent(depthSwitching,"onReset")

    registerEvent(depthSwitching,"onTick")

    registerEvent(depthSwitching,"onDraw","onDraw",false)
    registerEvent(depthSwitching,"onDrawEnd")
end


function depthSwitching.onStart()
    if not depthSwitching.enabled then
        return
    end

    
    depthSwitching.setDepth(depthSwitching.depthValues.FRONT)

    -- make these two blocks lava
    mem(BLOCK_IS_LAVA_ADDR + depthSwitching.npcPassthroughLava   *0x02,FIELD_BOOL,true)
    mem(BLOCK_IS_LAVA_ADDR + depthSwitching.playerPassthroughLava*0x02,FIELD_BOOL,true)
end

function depthSwitching.onReset(fromRespawn)
    if not depthSwitching.enabled then
        return
    end

    
    if fromRespawn then
        depthSwitching.setDepth(depthSwitching.depthValues.FRONT)
    else
        depthSwitching.setDepth(depthSwitching.currentDepth) -- to make sure all the blocks are right
    end
end


function depthSwitching.onTick()
    if not depthSwitching.enabled then
        return
    end

    
    for _,npc in NPC.iterate() do
        local data = getData(npc)

        if npc.despawnTimer > 0 and not npc.isGenerator then
            if data.depth == nil then
               -- data.depth = depthSwitching.getLayerDepth(npc.layerName) or depthSwitching.depthValues.FRONT
                data.depth = getNPCDepth(npc)

                data.originallyFriendly = false--npc.friendly
            end

            if data.depth ~= depthSwitching.currentDepth then
                npc.friendly = true
            else
                npc.friendly = data.originallyFriendly
            end
        else
            if data.originallyFriendly ~= nil then
                npc.friendly = data.originallyFriendly
                data.originallyFriendly = nil
            end

            data.depth = nil
        end
    end
end



depthSwitching.hiddenBlocks = {}

depthSwitching.blockBackColor  = Color(0.55,0.55,0.55,1)
depthSwitching.npcBackColor    = Color(0.55,0.55,0.55,1)
depthSwitching.playerBackColor = Color(0.55,0.55,0.55,1)


local function hideBlock(block)
    block.isHidden = true
    table.insert(depthSwitching.hiddenBlocks,block)
end



-- Drawing stuff (mostly gl draw, and uses just one arguments table for performance)
local drawBlock
local drawNPC

do
    local glDrawArgs = {
        vertexCoords = {},
        textureCoords = {},
    }


    local function doBasicSetup(texture,x,y,width,height,sourceX,sourceY,sourceWidth,sourceHeight)
        glDrawArgs.texture = texture

        -- Vertex coords
        do
            local vc = glDrawArgs.vertexCoords

            local x1 = x
            local y1 = y
            local x2 = x1+width
            local y2 = y1+height

            vc[1] = x1
            vc[2] = y1
            
            vc[3] = x1
            vc[4] = y2

            vc[5] = x2
            vc[6] = y1

            vc[7] = x1
            vc[8] = y2

            vc[9] = x2
            vc[10] = y1

            vc[11] = x2
            vc[12] = y2
        end

        -- Texture coords
        do
            local tc = glDrawArgs.textureCoords

            local x1 = sourceX/texture.width
            local y1 = sourceY/texture.height
            local x2 = (sourceX+sourceWidth )/texture.width
            local y2 = (sourceY+sourceHeight)/texture.height

            tc[1] = x1
            tc[2] = y1
            
            tc[3] = x1
            tc[4] = y2

            tc[5] = x2
            tc[6] = y1

            tc[7] = x1
            tc[8] = y2

            tc[9] = x2
            tc[10] = y1

            tc[11] = x2
            tc[12] = y2
        end
    end


    function drawBlock(block)
        if block.isHidden or block:mem(0x5A,FIELD_BOOL) then return end

        local data = getData(block)

        if data.depth ~= depthSwitching.depthValues.BACK and data.originalID == nil then return end

        -- Set up draw arguments
        local id = (data.originalID or block.id)


        -- Sizeable handling
        if Block.SIZEABLE_MAP[id] then
            local color,priority
            if data.depth == depthSwitching.depthValues.BACK then
                color = depthSwitching.blockBackColor
                priority = -99
            end

            local actualID = block.id
            block.id = id

            sizeable.drawSizable(block, camera, priority, nil, color)

            block.id = actualID


            hideBlock(block)

            return
        end


        local texture = Graphics.sprites.block[id].img
        if texture == nil then
            return
        end


        local x = block.x
        local y = block.y+block:mem(0x56,FIELD_WORD)
        local width  = block.width
        local height = block.height

        doBasicSetup(texture,x,y,width,height,0,blockutils.getBlockFrame(id)*height,width,height)


        -- Other stuff
        glDrawArgs.sceneCoords = true

        if data.depth == depthSwitching.depthValues.BACK then
            glDrawArgs.color = depthSwitching.blockBackColor
            glDrawArgs.priority = -98
        else
            glDrawArgs.color = nil
            glDrawArgs.priority = -65
        end


        Graphics.glDraw(glDrawArgs)

        hideBlock(block)
    end


    local lowPriorityStates = table.map{1,3,4}

    function drawNPC(npc)
        if npc.despawnTimer <= 0 or npc.isGenerator or npc.animationFrame < 0 then return end

        local data = getData(npc)

        if data.depth ~= depthSwitching.depthValues.BACK then return end

        local texture = Graphics.sprites.npc[npc.id].img
        local config = NPC.config[npc.id]

        if texture == nil or config == nil then
            return
        end


        local gfxwidth = npcutils.gfxwidth(npc)
        local gfxheight = npcutils.gfxheight(npc)

        local fullGfxWidth  = config.gfxwidth
        local fullGfxHeight = config.gfxheight

        if fullGfxWidth == 0 then
            fullGfxWidth = config.width
        end
        if fullGfxHeight == 0 then
            fullGfxHeight = config.height
        end


        local x = npc.x+(npc.width*0.5)-(gfxwidth*0.5)+config.gfxoffsetx
        local y = npc.y+npc.height-gfxheight+config.gfxoffsety

        doBasicSetup(texture,x,y,gfxwidth,gfxheight,0,npc.animationFrame*fullGfxHeight,gfxwidth,gfxheight)


        glDrawArgs.sceneCoords = true
        glDrawArgs.color = depthSwitching.npcBackColor

        if npc:mem(0x12C,FIELD_WORD) > 0 then
            if Level.winState() == LEVEL_END_STATE_KEYHOLE then
                glDrawArgs.priority = -30
            else
                glDrawArgs.priority = -97.4
            end
        elseif lowPriorityStates[npc:mem(0x138,FIELD_WORD)] then
            glDrawArgs.priority = -98.5
        else
            glDrawArgs.priority = -97.5
        end


        Graphics.glDraw(glDrawArgs)

        npcutils.hideNPC(npc)
    end

    --[[function drawNPC(npc)
        if npc.despawnTimer <= 0 or npc.isGenerator or npc.animationFrame < 0 then return end

        local data = getData(npc)

        if data.depth ~= depthSwitching.depthValues.BACK then return end

        local texture = Graphics.sprites.npc[npc.id].img
        local config = NPC.config[npc.id]

        local gfxwidth = npcutils.gfxwidth(npc)
        local gfxheight = npcutils.gfxheight(npc)


        if data.sprite == nil or data.sprite.texture ~= texture then
            data.sprite = Sprite{texture = texture,frames = texture.height/gfxheight,pivot = Sprite.align.CENTRE}
        end

        local priority = (npc:mem(0x12C,FIELD_WORD) > 0 and -97.4) or -97.5

        data.sprite.x = npc.x+(npc.width*0.5)+config.gfxoffsetx
        data.sprite.y = npc.y+npc.height-(gfxheight*0.5)+config.gfxoffsety

        data.sprite:draw{frame = npc.animationFrame+1,color = depthSwitching.npcBackColor,priority = priority,sceneCoords = true}

        npcutils.hideNPC(npc)
    end]]
end



local playerFrame

function depthSwitching.onDraw()
    if not depthSwitching.enabled then
        return
    end

    
    if not (Misc.inEditor() and Misc.GetKeyState(VK_T)) then
        for _,block in Block.iterateIntersecting(camera.x,camera.y,camera.x+camera.width,camera.y+camera.height) do
            drawBlock(block)
        end

        for _,npc in NPC.iterate() do
        --for _,npc in NPC.iterateIntersecting(camera.x,camera.y,camera.x+camera.width,camera.y+camera.height) do
            drawNPC(npc)
        end
    end

    
    --[[if depthSwitching.currentDepth == depthSwitching.depthValues.BACK and (player.frame >= -49 and player.frame <= 50) then
        player:render{color = depthSwitching.playerBackColor,priority = (Level.winState() == LEVEL_END_STATE_KEYHOLE and -25) or -97}

        playerFrame = player.frame
        player.frame = 51
    end]]
end

function depthSwitching.onDrawEnd()
    for i = 1, #depthSwitching.hiddenBlocks do
        local block = depthSwitching.hiddenBlocks[i]

        if block.isValid then
            block.isHidden = false
        end

        depthSwitching.hiddenBlocks[i] = nil
    end

    if playerFrame ~= nil then
        player.frame = playerFrame
        playerFrame = nil
    end
end



return depthSwitching