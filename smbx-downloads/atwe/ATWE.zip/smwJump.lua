-- TODO:
-- Spin jumping
-- Fix small hop?
-- Add classic physics option
-- Add more descriptions

local smwJump = {}



smwJump.settings = {
    gravityUnheld = 0.702,
    gravityHeld = 0.351,

    initialJumpSpeed = -9.243,
    initialSpinjumpSpeed = -8.541,

    terminalVelocity = 9.594,


    forceHeldGravitySpeed = -10000,
}


local function canDoTheStuff()
    return (
        player.forcedState == FORCEDSTATE_NONE and player.deathTimer == 0
        and (
            -- in the air
            player.speedY ~= 0 -- """on a block"""
            or player:mem(0x176,FIELD_WORD) == 0 -- on a moving block / NPC
            or player:mem(0x48,FIELD_WORD) == 0 -- on a slope
        )

        and not player:mem(0x0C,FIELD_BOOL) -- fairy
        and not player:mem(0x36,FIELD_BOOL) -- underwater
        and not player.climbing
    )
end


function smwJump.onInitAPI()
    registerEvent(smwJump,"onTick")
end


function smwJump.onTick()
    if player:mem(0x36,FIELD_BOOL) or player:mem(0x3C,FIELD_BOOL) then -- underwater / sliding
        Defines.player_grav = nil
        Defines.gravity = nil
    else
        if player:mem(0x11C,FIELD_WORD) > 0 then -- upwards jump force
            player:mem(0x11C,FIELD_WORD,0)

            if player:mem(0x50,FIELD_BOOL) then -- spinjump
                player.speedY = smwJump.settings.initialSpinjumpSpeed
            else
                player.speedY = smwJump.settings.initialJumpSpeed
            end

            player.speedY = player.speedY - math.abs(player.speedX)/Defines.player_runspeed/3/12
        end

        if canDoTheStuff() and (player.keys.jump or player.keys.altJump or player.speedY < smwJump.settings.forceHeldGravitySpeed) then
            Defines.player_grav = smwJump.settings.gravityHeld
        else
            Defines.player_grav = smwJump.settings.gravityUnheld
        end
        Defines.gravity = smwJump.settings.terminalVelocity
    end

    --Text.print(Defines.player_grav,32,32)
end


return smwJump