local npcManager = require("npcManager")
local npcutils = require("npcs/npcutils")

local iceBlock = {}
local npcID = NPC_ID

local iceBlockSettings = {
	id = npcID,
	
	gfxwidth = 96,
    gfxheight = 96,

	frames = 4,
    framespeed = 12,
}

npcManager.setNpcSettings(iceBlockSettings)


local actualNPCImage


local insideShader = Shader()
insideShader:compileFromFile(nil, Misc.resolveFile("ice_inside.frag"))


local freezeSound = Misc.resolveSoundFile("ice_freeze")


local function getIceData(v)
    v.data._iceBlock = v.data._iceBlock or {}
    return v.data._iceBlock
end


local iceBuffer = Graphics.CaptureBuffer(400,400)
local insideBuffer = Graphics.CaptureBuffer(400,400)

local glDrawArgs = {vertexCoords = {},textureCoords = {},uniforms = {}}

local vertexCoords = glDrawArgs.vertexCoords
local textureCoords = glDrawArgs.textureCoords

local verticesCount = 0


local function clearOutVertices()
    for i = 1, #vertexCoords do
        vertexCoords[i] = nil
        textureCoords[i] = nil
    end

    verticesCount = 0
end

local function addQuad(x,y,width,height,sourceX,sourceY,sourceWidth,sourceHeight)
    local texture = glDrawArgs.texture

    -- Vertex coords
    do
        local x1 = x
        local x2 = x + width
        local y1 = y
        local y2 = y + height

        -- triangle 1
        vertexCoords[verticesCount + 1 ] = x1
        vertexCoords[verticesCount + 2 ] = y1
        vertexCoords[verticesCount + 3 ] = x1
        vertexCoords[verticesCount + 4 ] = y2
        vertexCoords[verticesCount + 5 ] = x2
        vertexCoords[verticesCount + 6 ] = y1
        -- triangle 2
        vertexCoords[verticesCount + 7 ] = x1
        vertexCoords[verticesCount + 8 ] = y2
        vertexCoords[verticesCount + 9 ] = x2
        vertexCoords[verticesCount + 10] = y1
        vertexCoords[verticesCount + 11] = x2
        vertexCoords[verticesCount + 12] = y2
    end

    -- Texture coords
    do
        local x1 = (sourceX) / texture.width
        local x2 = (sourceX + sourceWidth) / texture.width
        local y1 = (sourceY) / texture.height
        local y2 = (sourceY + sourceHeight) / texture.height

        -- triangle 1
        textureCoords[verticesCount + 1 ] = x1
        textureCoords[verticesCount + 2 ] = y1
        textureCoords[verticesCount + 3 ] = x1
        textureCoords[verticesCount + 4 ] = y2
        textureCoords[verticesCount + 5 ] = x2
        textureCoords[verticesCount + 6 ] = y1
        -- triangle 2
        textureCoords[verticesCount + 7 ] = x1
        textureCoords[verticesCount + 8 ] = y2
        textureCoords[verticesCount + 9 ] = x2
        textureCoords[verticesCount + 10] = y1
        textureCoords[verticesCount + 11] = x2
        textureCoords[verticesCount + 12] = y2
    end

    verticesCount = verticesCount + 12
end


function iceBlock.onDrawNPC(v)
	if v.despawnTimer <= 0 or v.isHidden then return end

    local config = NPC.config[v.id]
    local data = getIceData(v)

    if v.ai2 >= 0 then
        data.insideFrame = v.ai2
        v.ai2 = -1000
    elseif data.insideFrame == nil then
        data.insideFrame = 0
    end


    local iceX = math.floor(v.x + config.gfxoffsetx + 0.5)
    local iceY = math.floor(v.y + config.gfxoffsety + 0.5)
    local iceWidth  = math.floor(v.width  + 0.5)
    local iceHeight = math.floor(v.height + 0.5)


    glDrawArgs.priority = (v:mem(0x12C,FIELD_WORD) > 0 and -30) or -50
    glDrawArgs.sceneCoords = false
    glDrawArgs.shader = nil


    -- Draw the NPC frozen inside of the ice
    local insideImage = Graphics.sprites.npc[v.ai1].img

    if insideImage ~= nil then
        glDrawArgs.texture = insideImage
        glDrawArgs.target = insideBuffer

        insideBuffer:clear(glDrawArgs.priority)

        
        local insideConfig = NPC.config[v.ai1]


        local width = insideConfig.gfxwidth
        local height = insideConfig.gfxheight

        if width == 0 then
            width = insideConfig.width
        end
        if height == 0 then
            height = insideConfig.height
        end


        local x = insideBuffer.width *0.5 - width*0.5 + insideConfig.gfxoffsetx
        local y = insideBuffer.height*0.5 + iceHeight*0.5 - height + insideConfig.gfxoffsety

        local sourceX = 0
        local sourceY = data.insideFrame * height

        addQuad(x,y,width,height,sourceX,sourceY,width,height)

        Graphics.glDraw(glDrawArgs)

        clearOutVertices()
    end


    -- Draw the actual ice
    glDrawArgs.texture = actualNPCImage
    glDrawArgs.target = iceBuffer

    iceBuffer:clear(glDrawArgs.priority)

    for segmentX = 1,3 do
        for segmentY = 1,3 do
            local x = iceBuffer.width *0.5 - iceWidth *0.5
            local y = iceBuffer.height*0.5 - iceHeight*0.5
            local width  = math.min(iceWidth  * 0.5, config.gfxwidth /3)
            local height = math.min(iceHeight * 0.5, config.gfxheight/3)

            local sourceX = 0
            local sourceY = (v.animationFrame * config.gfxheight)
            local sourceWidth = width
            local sourceHeight = height


            if segmentX == 2 then
                x = x + width
                width = iceWidth - (sourceWidth*2)
                sourceX = sourceX + sourceWidth
            elseif segmentX == 3 then
                x = x + iceWidth - width
                sourceX = sourceX + config.gfxwidth - sourceWidth
            end

            if segmentY == 2 then
                y = y + height
                height = iceHeight - (sourceHeight*2)
                sourceY = sourceY + sourceHeight
            elseif segmentY == 3 then
                y = y + iceHeight - height
                sourceY = sourceY + config.gfxheight - sourceHeight
            end


            if width > 0 and height > 0 then
                addQuad(x,y,width,height,sourceX,sourceY,sourceWidth,sourceHeight)
            end
        end
    end

    Graphics.glDraw(glDrawArgs)

    clearOutVertices()


    -- Now, put the ice onto the screen, using a shader to put the NPC inside of it
    glDrawArgs.texture = iceBuffer
    glDrawArgs.target = nil
    glDrawArgs.sceneCoords = true

    if insideImage ~= nil then
        glDrawArgs.shader = insideShader
        glDrawArgs.uniforms.insideBuffer = insideBuffer
    else
        glDrawArgs.shader = nil
    end

    addQuad(iceX + iceWidth*0.5 - iceBuffer.width*0.5,iceY + iceHeight*0.5 - iceBuffer.height*0.5,iceBuffer.width,iceBuffer.height,0,0,iceBuffer.width,iceBuffer.height)

    Graphics.glDraw(glDrawArgs)

    clearOutVertices()
end


-- Stuff for icewidth and iceheight configs
do
    local function createDebris(v)
        local e = Effect.spawn(957,v.x + v.width*0.5,v.y + v.height*0.5)

        e.x = e.x - e.width*0.5
        e.y = e.y - e.height*0.5
    end


    for id = 1, NPC_MAX_ID do
        local config = NPC.config[id]
        
        config:setDefaultProperty("icewidth",0)
        config:setDefaultProperty("iceheight",0)
        config:setDefaultProperty("icetime",0)
    end

    

    local function deinitialize(v,data)
        data.initialized = false
        data.timer = nil
        data.setSize = nil
    end

    local function initialize(v,data)
        if data.initialized then return end

        data.initialized = true
        data.timer = 0
        data.setSize = false

        SFX.play(freezeSound)
    end


    function iceBlock.onTickEndNPC(v)
        local data = getIceData(v)

        if v.despawnTimer <= 0 then
            deinitialize(v,data)
            return
        end

        initialize(v,data)

        if v.ai1 > 0 then
            local config = NPC.config[v.ai1]

            v.noblockcollision = (v.ai3 == 1)

            if not data.setSize then
                if config.icewidth > 0 then
                    v.x = v.x + v.width*0.5 - config.icewidth*0.5
                    v.width = config.icewidth
                end
                if config.iceheight > 0 then
                    v.y = v.y + v.height - config.iceheight
                    v.height = config.iceheight
                end
                
                data.setSize = true
            end

            if not Defines.levelFreeze and config.icetime > 0 then
                data.timer = data.timer + 1

                if data.timer >= config.icetime then
                    local holdingPlayer = v:mem(0x12C,FIELD_WORD)
                    if holdingPlayer > 0 then
                        local p = Player(holdingPlayer)

                        p:mem(0x154,FIELD_WORD,0)
                        v:mem(0x12C,FIELD_WORD,0)
                    end


                    deinitialize(v,data)

                    createDebris(v)
                    SFX.play(4)

                    v.noblockcollision = false

                    v:harm(HARM_TYPE_EXT_FIRE)
                elseif data.timer%2 == 0 then
                    v.y = v.y + 4
                else
                    v.y = v.y - 4
                end
            end
        end
    end


    function iceBlock.onPostNPCKill(v,reason)
        if v.id == npcID then
            createDebris(v)
        end
    end
end


function iceBlock.onStart()
    actualNPCImage = Graphics.sprites.npc[npcID].img
    Graphics.sprites.npc[npcID].img = Graphics.loadImageResolved("stock-0.png")
end

function iceBlock.onInitAPI()
    npcManager.registerEvent(npcID, iceBlock, "onTickEndNPC")
	npcManager.registerEvent(npcID, iceBlock, "onDrawNPC")
    
    registerEvent(iceBlock,"onStart","onStart",false)
    registerEvent(iceBlock,"onPostNPCKill")
end


return iceBlock