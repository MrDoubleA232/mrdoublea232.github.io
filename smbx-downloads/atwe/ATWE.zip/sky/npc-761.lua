local npcManager = require("npcManager")
local npcutils = require("npcs/npcutils")

local reznorController = require("reznorController")

local betterSMWCamera = require("betterSMWCamera")
local littleDialogue = require("littleDialogue")

local goalTape = require("goalTape_ai")

local progressStuff = require("progressStuff")


local wheel = {}
local npcID = NPC_ID


local reznorID = (npcID + 1)
local blockID = (npcID + 2)


local wheelSettings = {
	id = npcID,
	
	gfxwidth = 256,
	gfxheight = 256,

	gfxoffsetx = 0,
	gfxoffsety = 0,
	
	width = 256,
	height = 256,
	
	frames = 1,
	framestyle = 0,
	framespeed = 8,
	
	speed = 1,
	
	npcblock = false,
	npcblocktop = false, --Misnomer, affects whether thrown NPCs bounce off the NPC.
	playerblock = false,
	playerblocktop = false, --Also handles other NPCs walking atop this NPC.

	nohurt = true,
	nogravity = true,
	noblockcollision = true,
	nofireball = true,
	noiceball = true,
	noyoshi = true,
	nowaterphysics = true,
	
	jumphurt = true,
	spinjumpsafe = false,
	harmlessgrab = false,
	harmlessthrown = false,

	ignorethrownnpcs = true,
}

npcManager.setNpcSettings(wheelSettings)
npcManager.registerHarmTypes(npcID,{},{})


function wheel.onInitAPI()
	npcManager.registerEvent(npcID, wheel, "onTickNPC")
	npcManager.registerEvent(npcID, wheel, "onDrawNPC")

	registerEvent(wheel, "onPostPlayerKill")
	registerEvent(wheel, "onPostNPCKill")
	registerEvent(wheel, "onReset")
end


GameData.watchedReznorIntro = GameData.watchedReznorIntro or false


local fallSound = Misc.resolveSoundFile("reznor_fall")

local fireballShotProperties = {
	[0] = {
		reznorStates = {reznorController.UNIT_STATE.FIRE},
		shots = 2, waitStart = 0.4,waitEnd = 0.2, betweenShotsWait = 1.2,
	},
	[1] = {
		reznorStates = {reznorController.UNIT_STATE.FIRE_BOUNCY},
		shots = 2, waitStart = 0.4,waitEnd = 0.2, betweenShotsWait = 1.3,
	},
	[2] = {
		reznorStates = {reznorController.UNIT_STATE.FIRE_BOUNCY,reznorController.UNIT_STATE.FIRE_BOUNCY,reznorController.UNIT_STATE.FIRE},
		shots = 6, waitStart = 0.6,waitEnd = 0.4, betweenShotsWait = 1.0,
	},
	[3] = {
		reznorStates = {reznorController.UNIT_STATE.FIRE},
		shots = 12, waitStart = 0.6,waitEnd = 0.35, betweenShotsWait = 0,
	},
}


local CEILING_HEIGHT = 448
local FLOOR_HEIGHT = 96

local LAVA_HEIGHT = 32


local RENDER_SCALE = 2

local REZNOR_COUNT = 4

local INTRO_GRAVITY = 0.3

local ORB_ID = 952
--local ORB_X = -119568
--local ORB_Y = -119008


local stateTickFunctions = {}
local stateRoutines = {}


local function setState(v,newState)
	local data = v.data

	if data.currentStateRoutine ~= nil and data.currentStateRoutine.isValid and data.currentStateRoutine:getTime() > 0 then
		data.currentStateRoutine:abort()
	end

	if stateRoutines[newState] ~= nil then
		data.currentStateRoutine = Routine.run(stateRoutines[newState],v,data,config)
	end

	data.state = newState
	data.timer = 0
end

function reznorController.setWheelState(newState)
	setState(reznorController.wheelNPC,newState)
end


local function getMessageBoxPos(v,yOffset)
	return vector(v.x + v.width*0.5, v.y + v.height + yOffset)
end

local function reznorSpeak(v,boxList,text,offset)
	v.data.state = reznorController.UNIT_STATE.ANIM_MOUTH
	reznorController.updateUnitAnimation(v)

	table.insert(boxList,littleDialogue.create{text = text,speakerObj = getMessageBoxPos(v,80 + (offset or 0)),uncontrollable = true})
end

local function waitForBoxesEnd(boxList)
	while (boxList[#boxList].state ~= littleDialogue.BOX_STATE.STAY or player.rawKeys.jump ~= KEYS_PRESSED) do
		Routine.skip(true)
	end

	-- Close all the boxes
	for _,box in ipairs(boxList) do
		box:progress()
	end
end


local function getBigShotReznor(v,reznors)
	local best
	local bestDistance

	for _,reznor in ipairs(reznors) do
		if reznor.isValid then
			-- "Value" is calculated based on its X and Y positions relative to the wheel.
			local distanceX = (reznor.x + reznor.width*0.5) - (v.x + v.width)
			local distanceY = (reznor.y + reznor.height*0.5) - (v.y + v.height)

			local thisDistance = math.abs(distanceX)*1.5 + math.abs(distanceY)

			if (best == nil or thisDistance < bestDistance) then
				best = reznor
				bestDistance = thisDistance
			end
		end
	end

	return best
end


stateRoutines[reznorController.WHEEL_STATE.INTRO] = (function(v,data,config)
	v.x = v.sectionObj.boundary.right + 48
	v.y = v.sectionObj.boundary.bottom - FLOOR_HEIGHT - v.height

	
	while (player.section ~= v.section or player.y < (v.sectionObj.boundary.bottom - CEILING_HEIGHT) or not player:isOnGround()) do
		Routine.skip()
	end

	Routine.wait(0.5)



	if GameData.watchedReznorIntro then
		v.sectionObj.musicID = 24
	else
		betterSMWCamera.cameraData.targets = {v}
	end

	betterSMWCamera.settings.normalModes[2] = betterSMWCamera.MODE_NO_sCROLL


	-- Roll in
	v.speedX = -12
	data.rotation = 150

	while (math.abs(v.speedX) > 0.1) do
		v.speedX = v.speedX * 0.97
		data.rotationSpeed = v.speedX * 0.4

		Defines.earthquake = 2

		Routine.skip()
	end


	-- Jump up into proper position
	SFX.play(1)

	do
		local goalX,goalY = v.spawnX,v.spawnY

		v.speedX = 0.35 * math.sign(goalX - v.x)

		local t = (goalX - v.x) / v.speedX
        v.speedY = (goalY - v.y) / t - (INTRO_GRAVITY * t) / 2
	end

	while (v.y+v.speedY < v.spawnY or v.speedY < 0) do
		v.speedY = v.speedY + INTRO_GRAVITY

		data.rotation = math.anglelerp(data.rotation,0,0.125)
		data.rotationSpeed = 0

		Routine.skip()
	end

	v.x = v.spawnX
	v.y = v.spawnY

	v.speedX = 0
	v.speedY = 0
	
	data.rotation = 0

	Defines.earthquake = 5
	SFX.play(37)

	Routine.wait(0.5)


	-- Chatter
	local reznors = data.reznors

	if not GameData.watchedReznorIntro then
		do
			local boxList = {}

			reznorSpeak(reznors[1],boxList,"We're the reznors!")
			Routine.wait(1,true)

			reznorSpeak(reznors[4],boxList,"Yeah!")
			Routine.wait(0.4,true)

			reznorSpeak(reznors[2],boxList,"Yeah!!")
			Routine.wait(1.2,true)

			reznors[3].direction = DIR_RIGHT
			reznorSpeak(reznors[3],boxList,"(WE HAVE AN INTRO??)")
			Routine.wait(0.2,true)

			waitForBoxesEnd(boxList)


			for _,npc in ipairs(reznors) do
				npc.direction = DIR_LEFT
				npc.data.state = reznorController.UNIT_STATE.ANIM_IDLE
				reznorController.updateUnitAnimation(reznors[3])
			end
		end

		Routine.skip(true)
		Misc.pause(true)
		Routine.wait(0.5,true)

		do
			local boxList = {}

			reznorSpeak(reznors[1],boxList,"Get ready,")
			Routine.wait(1,true)

			reznorSpeak(reznors[4],boxList,"This won't be steady,")
			Routine.wait(0.7,true)

			reznorSpeak(reznors[2],boxList,"You'll need to",32)
			Routine.wait(1.5,true)

			reznors[3].direction = DIR_RIGHT
			reznorSpeak(reznors[3],boxList,"(RHYMES???)")
			Routine.wait(0.2,true)

			waitForBoxesEnd(boxList)
		end

		Routine.wait(0.5)
	end


	for _,npc in ipairs(reznors) do
		if npc.isValid then
			npc.direction = DIR_LEFT
			npc.data.state = reznorController.UNIT_STATE.NORMAL
		end
	end


	if not GameData.watchedReznorIntro then
		v.sectionObj.musicID = 24
		GameData.watchedReznorIntro = true

		betterSMWCamera.cameraData.targets = {}
	end


	setState(v,reznorController.WHEEL_STATE.NORMAL)
end)



stateTickFunctions[reznorController.WHEEL_STATE.NORMAL] = (function(v,data,config)
	data.rotationSpeed = math.min(1,data.rotationSpeed + 0.02)
end)

stateRoutines[reznorController.WHEEL_STATE.NORMAL] = (function(v,data,config)
	Routine.wait(1)

	-- Shoot some fireballs!
	local properties = fireballShotProperties[data.hits]


	for i = 1,properties.shots do
		for _,reznor in ipairs(data.reznors) do
			if reznor.isValid then
				reznor.data.state = properties.reznorStates[((i-1) % #properties.reznorStates) + 1]
				reznor.data.timer = 0

				Routine.wait(math.lerp(properties.waitStart,properties.waitEnd, (i - 1) / (properties.shots - 1)))
			end
		end

		if i < properties.shots then
			Routine.wait(properties.betweenShotsWait)
		end
	end

	Routine.wait(0.6)


	-- If the best reznor is too high/too far, just wait for a bit
	while (true) do
		local chosenReznor = getBigShotReznor(v,data.reznors)

		if (chosenReznor.y + chosenReznor.height) < (v.y + v.height - 64) or (chosenReznor.x) < (v.x + v.width*0.5 - 32) or (data.hits >= 2 and (chosenReznor.x + chosenReznor.width) < (v.x + 40)) then
			Routine.skip()
		else
			break
		end
	end
	

	setState(v,reznorController.WHEEL_STATE.BIG_SHOT)
end)


stateRoutines[reznorController.WHEEL_STATE.BIG_SHOT] = (function(v,data,config)
	while (data.rotationSpeed > 0) do
		data.rotationSpeed = math.max(data.rotationSpeed - 0.02)
		Routine.skip()
	end

	Routine.wait(0.5)

	-- Pick the reznor closest to the left
	local chosenReznor = getBigShotReznor(v,data.reznors)

	chosenReznor.data.state = reznorController.UNIT_STATE.SHELL_PREPARE

	while (chosenReznor.data.state ~= reznorController.UNIT_STATE.NORMAL) do
		Routine.skip()
	end

	setState(v,reznorController.WHEEL_STATE.NORMAL)
end)


local dontDisappearIDs = table.map{13,265, npcID,reznorID,blockID}

stateRoutines[reznorController.WHEEL_STATE.REZNOR_KILLED] = (function(v,data,config)
	data.hits = data.hits + 1


	for _,npc in NPC.iterate(-1,v.section) do
		if not dontDisappearIDs[npc.id] then
			npc:kill(HARM_TYPE_VANISH)

			local e = Effect.spawn(10, npc.x + npc.width*0.5,npc.y + npc.height*0.5)

			e.x = e.x - e.width *0.5
			e.y = e.y - e.height*0.5
		end
	end

	for _,reznor in ipairs(data.reznors) do
		if reznor.isValid then
			reznor.data.state = reznorController.UNIT_STATE.ANIM_IDLE
			reznor.data.timer = 0
		end
	end


	SFX.play(fallSound)


	if data.hits >= REZNOR_COUNT then
		v.sectionObj.musicID = 0

		while (data.rotationSpeed > 0) do
			data.rotationSpeed = math.max(0,data.rotationSpeed - 0.03)
			Routine.skip()
		end

		Routine.wait(0.8)

		for time = 1,224 do
			if time%32 == 0 then
				local e = Effect.spawn(952,v.x + RNG.random(0,v.width),v.y + RNG.random(0,v.height))

				e.width = e.width * 3
				e.height = e.height * 3
				
				e.x = e.x - e.width*0.5
				e.y = e.y - e.height*0.5

				SFX.play(4)
			end

			Defines.earthquake = 2

			Routine.skip()
		end

		SFX.play(fallSound)

		v.speedX = 1
		v.speedY = -5
		data.rotationSpeed = 0.4

		data.disableThatCutoffStuff = true

		while (v.y+v.height <= v.sectionObj.boundary.bottom-LAVA_HEIGHT) do
			v.speedY = v.speedY + INTRO_GRAVITY
			Routine.skip()
		end

		SFX.play(16)

		progressStuff.onReznorBeat()

		v.speedX = 0
		v.speedY = 0.5
		data.rotationSpeed = 0.2

		Routine.wait(3)

		goalTape.startExit{id = ORB_ID}

		return
	end


	Routine.wait(0.8)


	-- Bridge falling
	local bridgeLayerName = ("bridge ".. data.hits)
	local bridgeLayerObj = Layer.get(bridgeLayerName)

	if bridgeLayerObj ~= nil then
		SFX.play(fallSound)

		-- Make the layer fall
		local fallDistance = 0

		while (true) do
			if not bridgeLayerObj:isPaused() then
				bridgeLayerObj.speedY = bridgeLayerObj.speedY + 0.02

				fallDistance = fallDistance + bridgeLayerObj.speedY

				if fallDistance > (FLOOR_HEIGHT - LAVA_HEIGHT) + 16 then
					break
				end
			end
			
			Routine.skip()
		end

		Routine.skip()

		bridgeLayerObj.speedY = 0
		bridgeLayerObj:hide(true)

		-- Do lava splash
		SFX.play(16)

		-- Put some lava effects on the bridges
		for _,block in Block.iterateIntersecting(camera.x,camera.y,camera.x + camera.width,camera.y + camera.height) do
			if block.layerName == bridgeLayerName then
				local e = Effect.spawn(951, block.x + block.width*0.5, v.sectionObj.boundary.bottom - LAVA_HEIGHT)

				e.x = e.x - e.width*0.5
			end
		end
	end


	Routine.wait(0.7)

	-- You killed my brother! Prepare to die!
	for i = 1, 2 do
		for _,reznor in ipairs(data.reznors) do
			if reznor.isValid then
				reznor.data.state = reznorController.UNIT_STATE.ANIM_MOUTH
				reznor.data.timer = 0
			end
		end

		SFX.play(39)

		Routine.wait(0.2)

		for _,reznor in ipairs(data.reznors) do
			if reznor.isValid then
				reznor.data.state = reznorController.UNIT_STATE.ANIM_IDLE
				reznor.data.timer = 0
			end
		end

		Routine.wait(0.2)
	end

	setState(v,reznorController.WHEEL_STATE.NORMAL)
end)

stateTickFunctions[reznorController.WHEEL_STATE.REZNOR_KILLED] = (function(v,data,config)
	if data.hits < REZNOR_COUNT then
		data.rotationSpeed = math.max(0,data.rotationSpeed - 0.03)
	end
end)


function wheel.onTickNPC(v)
	if Defines.levelFreeze then return end
	
	local data = v.data
	
	if v.despawnTimer <= 0 then
		data.initialized = false

		reznorController.wheelNPC = nil

		return
	end

	local config = NPC.config[v.id]

	if not data.initialized then
		data.initialized = true

		setState(v,reznorController.WHEEL_STATE.INTRO)

		data.rotation = 0
		data.rotationSpeed = 0

		data.hits = 0


		data.disableThatCutoffStuff = false


		reznorController.wheelNPC = v


		-- Spawn blocks and reznors
		data.reznors = {}
		data.blocks = {}

		for i = 1, REZNOR_COUNT do
			data.reznors[i] = NPC.spawn(reznorID, v.x + v.width*0.5,v.y + v.height*0.5,v.section, false,false)
			data.reznors[i].direction = DIR_LEFT

			data.blocks[i] = NPC.spawn(blockID, v.x + v.width*0.5,v.y + v.height*0.5,v.section, false,false)

			if i > (REZNOR_COUNT - data.hits) then
				data.reznors[i]:kill(HARM_TYPE_NPC)
			end
		end

		-- Remove bridges if necessary
		for i = 1, data.hits do
			local bridgeLayerObj = Layer.get("bridge ".. i)

			if bridgeLayerObj ~= nil then
				bridgeLayerObj:hide(true)
			end
		end
	end
	

	if stateTickFunctions[data.state] ~= nil then
		stateTickFunctions[data.state](v,data,config)
	end


	data.rotation = data.rotation + data.rotationSpeed


	-- Update block positions
	for i = 1, REZNOR_COUNT do
		local reznor = data.reznors[i]
		local block = data.blocks[i]

		if block.isValid then
			local offset = vector(0,-112):rotate(data.rotation + ((i-1) / REZNOR_COUNT)*360)

			block.speedX = (v.x + v.speedX + v.width *0.5 + offset.x - block.width *0.5) - block.x
			block.speedY = (v.y + v.speedY + v.height*0.5 + offset.y - block.height*0.5) - block.y

			block.despawnTimer = 100

			if reznor.isValid then
				reznor.x = block.x + block.speedX + block.width*0.5 - reznor.width*0.5
				reznor.y = block.y + block.speedY - reznor.height

				reznor.despawnTimer = 100
			end
		end
	end


	if (player.section == v.section) and v.despawnTimer > 0 then
		v.despawnTimer = 180
	end


	reznorController.wheelState = data.state
end


local buffer = Graphics.CaptureBuffer(400 / RENDER_SCALE,400 / RENDER_SCALE)

function wheel.onDrawNPC(v)
	if v.despawnTimer <= 0 or v.isHidden then return end

	local config = NPC.config[v.id]
	local data = v.data

	if data.sprite == nil then
		data.sprite = Sprite{texture = Graphics.sprites.npc[v.id].img,pivot = Sprite.align.CENTRE}
	end

	local priority = -75

	buffer:clear(priority)

	--Graphics.drawBox{priority = priority,target = buffer,x = 0,y = 0,width = buffer.width,height = buffer.height}


	data.sprite.x = buffer.width*0.5
	data.sprite.y = buffer.height*0.5

	data.sprite.scale.x = (1 / RENDER_SCALE)
	data.sprite.scale.y = (1 / RENDER_SCALE)

	data.sprite.rotation = data.rotation or 0

	data.sprite:draw{target = buffer,priority = priority}


	-- Don't draw the wheel below the bridge or above the bricks
	-- Why? because, in theory, if this was on the snes, this wheel would be using BG mode 7.
	-- HDMA would probably be used to get the bridge and lava, and so mode 7 couldn't interact with anything below there.

	local mode7Start = (v.sectionObj.boundary.bottom - CEILING_HEIGHT - camera.y)
	local mode7End   = (v.sectionObj.boundary.bottom - FLOOR_HEIGHT - camera.y)


	if data.disableThatCutoffStuff then
		mode7Start = 0
		mode7End = 600
	end
	
	
	local fullWidth  = (buffer.width  * RENDER_SCALE)
	local fullHeight = (buffer.height * RENDER_SCALE)

	local originalY = (v.y + v.height*0.5 - fullHeight*0.5 - camera.y)

	local drawStartY = math.max(originalY             , mode7Start)
	local drawEndY   = math.min(originalY + fullHeight, mode7End  )

	local height = math.max(0, drawEndY - drawStartY)
	local sourceY = math.max(0, (drawStartY - originalY) / RENDER_SCALE)


	Graphics.drawBox{
		texture = buffer,priority = priority,
		x = (v.x + v.width*0.5 - fullWidth*0.5 - camera.x),y = drawStartY,width = fullWidth,height = height,
		sourceX = 0,sourceY = sourceY,sourceWidth = buffer.width,sourceHeight = (height / RENDER_SCALE),
	}

	--Text.print(drawStartY,32,96)
	--Text.print(drawEndY,32,128)
	--Text.print(sourceY,32,160)


	npcutils.hideNPC(v)
end


function wheel.onPostPlayerKill(p)
	if reznorController.wheelNPC ~= nil and reznorController.wheelNPC.isValid then
		reznorController.wheelNPC.sectionObj.musicID = 0
	end
end

function wheel.onPostNPCKill(v,reason)
	if v.id == npcID then
		setState(v,reznorController.WHEEL_STATE.UNINITIALISED)
	end
end

function wheel.onReset(fromRespawn)
	betterSMWCamera.settings.normalModes[2] = betterSMWCamera.MODE_CATCH_UP_CONDITIONAL
end


return wheel