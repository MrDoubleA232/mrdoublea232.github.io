local npcutils = require("npcs/npcutils")

local reznorController = {}


reznorController.WHEEL_STATE = {
    UNINITIALISED = -100,
    INTRO = -1,
    REZNOR_KILLED = -2,

    NORMAL = 0,
    BIG_SHOT = 1,
}

reznorController.UNIT_STATE = {
    NORMAL = 0,
    FIRE = 1,
    FIRE_BOUNCY = 2,

    SHELL_PREPARE = 3,
    SHELL_SHOOT = 4,
    SHELL_SPIT = 5,

    ANIM_IDLE = -1,
    ANIM_MOUTH = -2,
    ANIM_SCREAM = -3,
}


reznorController.wheelNPC = nil
reznorController.wheelState = reznorController.WHEEL_STATE.UNINITIALISED


function reznorController.updateUnitAnimation(v)
    local data = v.data

    local frame = 0

    if data.state == reznorController.UNIT_STATE.FIRE
    or data.state == reznorController.UNIT_STATE.FIRE_BOUNCY
    or data.state == reznorController.UNIT_STATE.SHELL_SHOOT
    or data.state == reznorController.UNIT_STATE.ANIM_MOUTH
    or (data.state == reznorController.UNIT_STATE.SHELL_SPIT and (data.timer >= 40 and data.timer <= 50))
    then
		frame = 1
	elseif data.state == reznorController.UNIT_STATE.ANIM_SCREAM then
		frame = math.floor(lunatime.tick() / 4) % 2
    elseif data.state == reznorController.UNIT_STATE.SHELL_PREPARE then
        frame = (math.floor(data.timer / 4) % 2) + 3
    elseif data.turnTimer > 0 then
        frame = 2
	end

    v.animationFrame = npcutils.getFrameByFramestyle(v,{frame = frame})
end


return reznorController