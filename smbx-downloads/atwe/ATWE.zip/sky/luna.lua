local extraNPCProperties = require("extraNPCProperties")
local globalStuff = require("globalStuff")
local rooms = require("rooms")


globalStuff.dontSetSectionBounds[4] = true


local platformUsualPosition = vector(-187680 + 16, -200256)
local layerPosition = vector(platformUsualPosition.x,platformUsualPosition.y)


local checkpointOnPlatform


local function handlePlatformStuff(npc)
    if npc.despawnTimer <= 0 then
        return false
    end


    local platforms = npc.data.platforms

    if platforms == nil then
        return false
    end
    
    local platform = platforms[1]

    if platform == nil or not platform.isValid then
        return false
    end

    if checkpointOnPlatform == nil or checkpointOnPlatform:isPaused() then
        return false
    end

    checkpointOnPlatform.speedX = (platform.x+platform.width*0.5 + platform.speedX) - layerPosition.x
    checkpointOnPlatform.speedY = (platform.y + platform.speedY) - layerPosition.y

    layerPosition.x = layerPosition.x + checkpointOnPlatform.speedX
    layerPosition.y = layerPosition.y + checkpointOnPlatform.speedY

    return true
end


function onStart()
    checkpointOnPlatform = Layer.get("checkpoint on platform")
end


function onTickEnd()
    for _,npc in ipairs(extraNPCProperties.getWithTag("checkpointPlatform")) do
        local setPosition = handlePlatformStuff(npc)

        if not setPosition and checkpointOnPlatform ~= nil and not checkpointOnPlatform:isPaused() then
            checkpointOnPlatform.speedX = platformUsualPosition.x - layerPosition.x
            checkpointOnPlatform.speedY = platformUsualPosition.y - layerPosition.y

            layerPosition.x = platformUsualPosition.x
            layerPosition.y = platformUsualPosition.y
        end
    end
end

function onReset(fromRespawn)
    layerPosition.x = platformUsualPosition.x
    layerPosition.y = platformUsualPosition.y
    checkpointOnPlatform = Layer.get("checkpoint on platform")

    -- reset the checkpoint NPC on it
    for _,npc in ipairs(extraNPCProperties.getWithTag("checkpoint2")) do
        npc.x = layerPosition.x - npc.width*0.5
        npc.y = layerPosition.y - npc.height
    end
end


function onTick()
    if player.sectionObj.backgroundID == 3 then
        local bg = player.sectionObj.background.layers[1]

        if lunatime.tick()%4 == 0 then
            bg.animationFrame = RNG.randomInt(0,1)
            bg.animationTimer = 100
        end
    end
end