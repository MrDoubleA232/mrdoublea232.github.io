local npcManager = require("npcManager")
local npcutils = require("npcs/npcutils")

local reznorController = require("reznorController")


local reznor = {}
local npcID = NPC_ID


local deathEffectID = (npcID - 1)

local fireID = (npcID + 2)
local bouncyID = (npcID + 3)


local reznorSettings = {
	id = npcID,
	
	gfxwidth = 64,
	gfxheight = 64,

	gfxoffsetx = 0,
	gfxoffsety = 0,
	
	width = 64,
	height = 64,
	
	frames = 5,
	framestyle = 1,
	framespeed = 8,
	
	speed = 1,
	
	npcblock = false,
	npcblocktop = false, --Misnomer, affects whether thrown NPCs bounce off the NPC.
	playerblock = false,
	playerblocktop = false, --Also handles other NPCs walking atop this NPC.

	nohurt = false,
	nogravity = true,
	noblockcollision = true,
	nofireball = true,
	noiceball = true,
	noyoshi = true,
	nowaterphysics = true,
	
	jumphurt = true,
	spinjumpsafe = false,
	harmlessgrab = false,
	harmlessthrown = false,
}

npcManager.setNpcSettings(reznorSettings)
npcManager.registerHarmTypes(npcID,
	{
		--HARM_TYPE_JUMP,
		--HARM_TYPE_FROMBELOW,
		HARM_TYPE_NPC,
		--HARM_TYPE_PROJECTILE_USED,
		--HARM_TYPE_LAVA,
		--HARM_TYPE_HELD,
		--HARM_TYPE_TAIL,
		--HARM_TYPE_SPINJUMP,
		--HARM_TYPE_OFFSCREEN,
		HARM_TYPE_SWORD
	},
	{
		--[HARM_TYPE_JUMP]            = 10,
		--[HARM_TYPE_FROMBELOW]       = 10,
		[HARM_TYPE_NPC]             = deathEffectID,
		--[HARM_TYPE_PROJECTILE_USED] = 10,
		--[HARM_TYPE_LAVA]            = {id=13, xoffset=0.5, xoffsetBack = 0, yoffset=1, yoffsetBack = 1.5},
		--[HARM_TYPE_HELD]            = 10,
		--[HARM_TYPE_TAIL]            = 10,
		--[HARM_TYPE_SPINJUMP]        = 10,
		--[HARM_TYPE_OFFSCREEN]       = 10,
		--[HARM_TYPE_SWORD]           = 10,
	}
)


local spatShells = {}
local spatShellMap = {}


local function getMouthPos(v)
	return v.x + v.width*0.5 + v.width*0.25*v.direction, v.y + v.height*0.5
end


function reznor.onInitAPI()
	npcManager.registerEvent(npcID, reznor, "onTickEndNPC")

	registerEvent(reznor,"onNPCHarm")

	registerEvent(reznor, "onTick")
end

function reznor.onTickEndNPC(v)
	if Defines.levelFreeze then return end
	
	local data = v.data
	
	if v.despawnTimer <= 0 then
		data.initialized = false
		return
	end

	if not data.initialized then
		data.initialized = true
		
		data.state = reznorController.UNIT_STATE.ANIM_IDLE
		data.timer = 0

		data.turnTimer = 0
	end

	

	-- Basic behaviour
	if data.state == reznorController.UNIT_STATE.FIRE or data.state == reznorController.UNIT_STATE.FIRE_BOUNCY then
		data.timer = data.timer + 1

		if data.timer == 20 then
			local npcID = (data.state == reznorController.UNIT_STATE.FIRE and fireID) or bouncyID

			local x,y = getMouthPos(v)
			local fireball = NPC.spawn(npcID, x,y, v.section, false,true)

			local distance = vector((player.x + player.width*0.5) - (fireball.x + fireball.width*0.5),(player.y + player.height*0.5) - (fireball.y + fireball.height*0.5))
			local speed = distance:normalise() * 4

			fireball.speedX = speed.x
			fireball.speedY = speed.y

			SFX.play(41)
		elseif data.timer >= 40 then
			data.state = reznorController.UNIT_STATE.NORMAL
		end
	elseif data.state == reznorController.UNIT_STATE.SHELL_PREPARE then
		data.timer = data.timer + 1

		if data.timer >= 120 then
			data.state = reznorController.UNIT_STATE.SHELL_SHOOT
			data.timer = 0
		end
	elseif data.state == reznorController.UNIT_STATE.SHELL_SHOOT then
		data.timer = data.timer + 1

		if data.timer >= 192 then
			data.state = reznorController.UNIT_STATE.SHELL_SPIT
			data.timer = 0
		elseif data.timer%6 == 0 then
			SFX.play(38)

			local x,y = getMouthPos(v)
			local shell = NPC.spawn(113, x,y, v.section, false,true)

			shell.speedX = 7.1 * v.direction
			shell.speedY = 0

			--shell.x = v.x + v.width*0.5 + (v.width*0.5 + shell.width)*v.direction

			shell:mem(0x136,FIELD_BOOL,true)

			table.insert(spatShells,shell)
			spatShellMap[shell] = true
		end
	elseif data.state == reznorController.UNIT_STATE.SHELL_SPIT then
		data.timer = data.timer + 1

		if data.timer == 40 then
			SFX.play(41)

			local x,y = getMouthPos(v)
			local shell = NPC.spawn(113, x,y, v.section, false,true)

			shell.speedX = 5 * v.direction
			shell.speedY = 0

			--shell.x = v.x + v.width*0.5 + (v.width*0.5 + shell.width)*v.direction

			shell.data.bouncing = true

			shell:mem(0x136,FIELD_BOOL,true)
			shell:mem(0x12E,FIELD_WORD,100)
			shell:mem(0x130,FIELD_WORD,1)

			table.insert(spatShells,shell)
			spatShellMap[shell] = true
		elseif data.timer >= 80 then
			data.state = reznorController.UNIT_STATE.NORMAL
			data.timer = 0
		end
	end


	-- Face player
	local distanceToPlayer = ((player.x + player.width*0.5) - (v.x + v.width*0.5))
	local newDirection = math.sign(distanceToPlayer)

	if math.abs(distanceToPlayer) > 24 and v.direction ~= newDirection then
		v.direction = newDirection
		data.turnTimer = 8
	elseif data.turnTimer > 0 then
		data.turnTimer = data.turnTimer - 1
	end


	-- Animation
	reznorController.updateUnitAnimation(v)
end


local invincibleWheelStates = table.map{reznorController.WHEEL_STATE.INTRO,reznorController.WHEEL_STATE.REZNOR_KILLED}

function reznor.onNPCHarm(eventObj,v,reason,culprit)
	if v.id == npcID then
		if (type(culprit) == "NPC" and (spatShellMap[culprit] or not NPC.SHELL_MAP[culprit.id])) or invincibleWheelStates[reznorController.wheelState] then
			eventObj.cancelled = true
			return
		end

		reznorController.setWheelState(reznorController.WHEEL_STATE.REZNOR_KILLED)
	end
end


function reznor.onTick()
	-- Prevent bouncing
	for i = #spatShells, 1, -1 do
		local shell = spatShells[i]

		if shell.isValid and shell.despawnTimer > 0 and shell:mem(0x136,FIELD_BOOL) and shell:mem(0x12C,FIELD_WORD) == 0 then
			if shell.collidesBlockBottom and not shell.data.bouncing then
				shell.speedY = -0.01
			end
		else
			table.remove(spatShells,i)
			spatShellMap[shell] = nil
		end
	end
end


return reznor