local letterWidths = {
    --     M  A  R  I  O  S  T  A  R  T  !
    {22,16,20,12,32,16,16,16,16,36,8},
    --     L  U  I  G  I  S  T  A  R  T  !
    {18,20,12,20,28,16,16,16,16,36,12},

    --     L  O  A  D  I  N  G  .  .  .
    {52,16,16,16,8, 20,16,10,10,46},
}


-- Address of the first player's character. Equivalent to 'player.character', except the player class doesn't exist in loading screens
local FIRST_PLAYER_CHARACTER_ADDR = mem(0x00B25A20,FIELD_DWORD) + 0x184 + 0xF0


local image = Graphics.loadImage("loadscreen.png")


local letterData = {}


local time = 0

local screenWidth,screenHeight,screenOffsetX,screenOffsetY

local function readNumberFromDataFile(f)
    if f == nil then
        return nil
    end
    
    return tonumber(f:read("l"))
end

local function loadLoadscreenData()
    local f = io.open(mem(0x00B2C61C,FIELD_STRING).. "loadscreenData.txt","r")

    screenWidth = readNumberFromDataFile(f) or 800
    screenHeight = readNumberFromDataFile(f) or 600
    screenOffsetX = readNumberFromDataFile(f) or 0
    screenOffsetY = readNumberFromDataFile(f) or -32

    if f ~= nil then
        f:close()
    end
end

function onDraw()
    if image == nil then -- this sometimes happens?
        return
    end

    local message = mem(FIRST_PLAYER_CHARACTER_ADDR,FIELD_WORD)
    local widths = letterWidths[message]

    if widths == nil then
        message = #letterWidths
        widths = letterWidths[message]
    end

    if time == 0 then
        loadLoadscreenData()
        Graphics.setMainFramebufferSize(screenWidth,screenHeight)
    end


    local opacity = math.min(1,time/32)

    local height = (image.height/#letterWidths)
    local sourceY = (message-1) * height

    local baseX = (screenWidth*0.5 - image.width*0.5 + screenOffsetX)
    local baseY = (screenHeight*0.5 - height*0.5 + screenOffsetY)
    local xOffset = 0

    local count = #widths

    for index,width in ipairs(widths) do
        letterData[index] = letterData[index] or {offset = 0,speed = 0}
        local data = letterData[index]

        if (time/4)%(count+8) == index-1 then
            data.speed = -2.5
        end

        data.speed = data.speed + 0.26
        data.offset = math.min(0,data.offset + data.speed)


        Graphics.drawImage(image,baseX+xOffset,baseY+data.offset,xOffset,sourceY,width,height,opacity)
        xOffset = xOffset + width
    end


    time = time + 1
end