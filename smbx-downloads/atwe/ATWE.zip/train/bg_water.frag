// This gets the parallax effect on the water, because no way am I placing however many layers

#version 120
uniform sampler2D iChannel0;

uniform float cameraX;
uniform float offset;
uniform vec2 imageSize;

uniform float focus;

const float stepThing = 12.0;

void main()
{
	vec2 xy = gl_TexCoord[0].xy;
	vec2 fullXY = xy*imageSize;

	// Calculate parallaxX
	float parallaxUseY = (floor(fullXY.y / stepThing) * stepThing) / imageSize.y;

	float depth = mix(150.0,20.0,parallaxUseY) / focus;

	depth++;
	depth = 1.0 / (depth*depth);


	// Apply movement and parallax
	xy.x = mod((fullXY.x + (cameraX - offset)*depth),imageSize.x) / imageSize.x;


	vec4 c = texture2D(iChannel0, xy);

	c *= parallaxUseY;
	
	gl_FragColor = c*gl_Color;
}