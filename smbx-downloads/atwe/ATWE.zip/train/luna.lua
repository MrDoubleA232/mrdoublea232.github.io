local blockutils = require("blocks/blockutils")
local paralx2 = require("paralx2")

local spikeAI = require("spike_ai")


spikeAI.ballRenderScale = 0.5


local backgroundSpeed = 0
local backgroundOffset = 0

local trainIsStopping = false


local trackBlocks = {}
local lastTrackSpeed = 0


local insideEffectFade = 1
local insideEffectFrames = 16
local insideEffectDuration = 16


local insideSections = table.map{1}


local function insideEffectFilter(v)
    return (v.layerName == "inside outside thing")
end


local function refreshStuff()
    trackBlocks = {}
    lastTrackSpeed = 0

    for _,b in Block.iterate() do
        if b.layerName == "track blocks" then
            table.insert(trackBlocks,b)
        end
    end
end


function onStart()
    refreshStuff()
end


function onReset(fromRespawn)
    if fromRespawn then
        backgroundSpeed = 0
        backgroundOffset = 0
    end

    refreshStuff()

    insideEffectFade = 1

    trainIsStopping = false
end


function onTick()
    if player.x > -159616 or trainIsStopping then
        if not Layer.isPaused() then
            backgroundSpeed = math.min(0,backgroundSpeed + 0.025)
        end

        trainIsStopping = true
    elseif player.section > 0 then
        backgroundSpeed = -14
    elseif backgroundOffset < 0 or player.x > -199648 then
        backgroundSpeed = math.max(-14,backgroundSpeed - 0.025)
    end

    backgroundOffset = backgroundOffset + backgroundSpeed



    local startLayer = Layer.get("starting ground")
    if backgroundOffset > -1800 then
        startLayer.speedX = backgroundSpeed
    elseif startLayer.speedX ~= 0 then
        startLayer.speedX = 0
    end


    if trainIsStopping then
        local endLayer = Layer.get("ending ground")

        endLayer.speedX = backgroundSpeed
    end


    -- Track block stuff
    if backgroundSpeed ~= lastTrackSpeed then
        for _,b in ipairs(trackBlocks) do
            b.speedX = backgroundSpeed
        end

        lastTrackSpeed = backgroundSpeed
    end

    if math.abs(backgroundSpeed) > 5 then
        if player.y+player.height >= player.sectionObj.boundary.bottom-33 and player:isOnGround() then
            player:harm()
        end

        for _,npc in NPC.iterateIntersecting(-math.huge,player.sectionObj.boundary.bottom-33,math.huge,player.sectionObj.boundary.bottom) do
            if Colliders.FILTER_COL_NPC_DEF(npc) and npc.despawnTimer > 0 and NPC.HITTABLE_MAP[npc.id] and not spikeAI.ballIDs[npc.id] and npc.collidesBlockBottom and (npc.collidesBlockLeft or npc.collidesBlockRight or npc:mem(0x120,FIELD_BOOL)) then
                npc:harm(HARM_TYPE_NPC)
            end
        end
    end
    


    if not insideSections[player.section] then
        if player.section == 0 then
            local b = player.sectionObj.boundary

            b.left = player.sectionObj.origBoundary.left + math.max(-800,backgroundOffset)

            player.sectionObj.boundary = b
        end

        insideEffectFade = 1
    else
        local playerHitbox = Colliders.getHitbox(player)

        playerHitbox.x = playerHitbox.x + 2
        playerHitbox.y = playerHitbox.y + 2
        playerHitbox.width = playerHitbox.width - 4
        playerHitbox.height = playerHitbox.height - 4

        local isInside = (#Colliders.getColliding{a = playerHitbox,btype = Colliders.BLOCK,filter = insideEffectFilter} > 0)


        if isInside then
            if insideEffectFade == 0 then
                SFX.play(41)
            end

            insideEffectFade = math.min(1,insideEffectFade + 1/insideEffectDuration)
        else
            if insideEffectFade == 1 then
                SFX.play(41)
            end

            insideEffectFade = math.max(0,insideEffectFade - 1/insideEffectDuration)
        end
    end
end


local frontBuffer = Graphics.CaptureBuffer()
local backBuffer = Graphics.CaptureBuffer()

local insideEffectBuffer = Graphics.CaptureBuffer()

local insideEffectShader = Shader()
insideEffectShader:compileFromFile(nil,Misc.resolveFile("insideEffect.frag"))

local insideEffectImage = Graphics.loadImageResolved("insideEffect.png")

local blockGlDrawArgs = {vertexCoords = {},textureCoords = {}}
local blockVC = blockGlDrawArgs.vertexCoords
local blockTC = blockGlDrawArgs.textureCoords

function onCameraDraw(camIdx)
    -- Update background
    local bg = player.sectionObj.background

    for _,layer in ipairs(bg.layers) do
        -- Handle shader uniforms and other layer properties
        local uniforms = layer.uniforms
        local image = layer.img

        if layer.name == "water" then
            uniforms.cameraX = Camera(camIdx).x - player.sectionObj.origBoundary.left
            uniforms.imageSize = vector(image.width,image.height)
            uniforms.focus = paralx2.focus
            uniforms.offset = backgroundOffset
        elseif layer.name == "starsFlipped" then
            uniforms.time = lunatime.tick()
            uniforms.imageSize = vector(image.width,image.height)
        elseif layer.name == "track" then
            --layer.hidden = (not not insideSections[player.section])
        elseif layer.name == "inside" then
            if insideSections[player.section] then
                layer.hidden = false

                frontBuffer:captureAt(-97.9)
                backBuffer:captureAt(-99)

                uniforms.frontBuffer = frontBuffer
                uniforms.backBuffer = backBuffer

                uniforms.flipActiveY = player.sectionObj.boundary.bottom - 64 - camera.y

                uniforms.cameraSize = vector(camera.width,camera.height)
            else
                layer.hidden = true
            end
        end
            

        local depth

        if layer.parallaxX ~= nil then
            depth = layer.parallaxX
        elseif layer.depth ~= nil then
            depth = layer.depth/paralx2.focus

            depth = depth + 1
            depth = 1/(depth*depth)
        end

        layer.x = backgroundOffset*depth
    end

    -- Inside/outside effect
    if insideSections[player.section] and insideEffectFade < 1 then
        blockGlDrawArgs.primitive = Graphics.GL_TRIANGLE_STRIP
        blockGlDrawArgs.sceneCoords = true
        blockGlDrawArgs.priority = -99
        blockGlDrawArgs.target = insideEffectBuffer

        insideEffectBuffer:clear(blockGlDrawArgs.priority)
        
        for _,b in Block.iterateIntersecting(camera.x,camera.y,camera.x+camera.width,camera.y+camera.height) do
            if b.layerName == "inside outside thing" then
                blockGlDrawArgs.texture = Graphics.sprites.block[b.id].img

                -- Setup vertex coords
                local x1 = b.x
                local y1 = b.y
                local x2 = x1 + b.width
                local y2 = y1 + b.height

                blockVC[1] = x1 -- top left
                blockVC[2] = y1
                blockVC[3] = x1 -- bottom left
                blockVC[4] = y2
                blockVC[5] = x2 -- top right
                blockVC[6] = y1
                blockVC[7] = x2 -- bottom right
                blockVC[8] = y2

                -- Setup texture coords
                local x1 = 0
                local y1 = 0
                local x2 = 1
                local y2 = 1

                blockTC[1] = x1 -- top left
                blockTC[2] = y1
                blockTC[3] = x1 -- bottom left
                blockTC[4] = y2
                blockTC[5] = x2 -- top right
                blockTC[6] = y1
                blockTC[7] = x2 -- bottom right
                blockTC[8] = y2

                Graphics.glDraw(blockGlDrawArgs)
            end
        end

        Graphics.drawScreen{
            texture = insideEffectBuffer,priority = -14,
            shader = insideEffectShader,uniforms = {
                cameraPosition = vector(camera.x,camera.y),
                cameraSize = vector(camera.width,camera.height),

                maskImage = insideEffectImage,
                maskImageSize = vector(insideEffectImage.width,insideEffectImage.height),
                maskFrames = insideEffectFrames,
                maskFrame = math.floor(insideEffectFade * insideEffectFrames),
            }
        }
    end
end

function onFramebufferResize(width,height)
    frontBuffer = Graphics.CaptureBuffer()
    backBuffer = Graphics.CaptureBuffer()
    insideEffectBuffer = Graphics.CaptureBuffer()
end


local WHEELS_ID = 1111

function onDraw()
    if backgroundSpeed ~= 0 then
        blockutils.setBlockFrame(WHEELS_ID,math.floor(lunatime.tick() * math.abs(backgroundSpeed / 48)) % 2)
    else
        blockutils.setBlockFrame(WHEELS_ID,0)
    end
end