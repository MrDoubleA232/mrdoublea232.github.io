// This creates a hole in the layer, where the pixel below is pink.

#version 120
uniform sampler2D iChannel0;

uniform sampler2D frontBuffer;
uniform sampler2D backBuffer;

uniform float flipActiveY;

uniform vec2 cameraSize;

#include "shaders/logic.glsl"

void main()
{
	vec2 xy = gl_FragCoord.xy/cameraSize;

	vec4 f = texture2D(frontBuffer, xy); // colour of just in front of the layer (used to see if it's pink)
	vec4 b = texture2D(backBuffer , xy); // colour of the actual BG
	vec4 l = texture2D(iChannel0  , xy); // colour of the layer

	float isInside = lt(f.r*f.b - f.g,1.0);
	isInside = mix(isInside,1.0 - isInside, ge(gl_FragCoord.y,flipActiveY));

	vec4 c = mix(b,l, isInside);
	
	gl_FragColor = c*gl_Color;
}