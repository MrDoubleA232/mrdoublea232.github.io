#version 120
uniform sampler2D iChannel0;


uniform sampler2D maskImage;
uniform float maskFrames;
uniform vec2 maskImageSize;

uniform vec2 cameraPosition;
uniform vec2 cameraSize;

uniform float maskFrame;

#include "shaders/logic.glsl"

void main()
{
	vec2 xy = gl_TexCoord[0].xy;

	float frameHeight = 1.0 / maskFrames;
	vec2 maskXY = mod((xy*cameraSize + cameraPosition) / maskImageSize,vec2(1.0,frameHeight)) + vec2(0.0,maskFrame*frameHeight);

	float maskBrightness = texture2D(maskImage, maskXY).r;

	vec4 c = texture2D(iChannel0, xy);

	c *= maskBrightness;

	gl_FragColor = c*gl_Color;
}