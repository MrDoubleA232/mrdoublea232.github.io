#version 120
uniform sampler2D iChannel0;

uniform vec4 crushColor1;
uniform vec4 crushColor2;

#include "shaders/logic.glsl"

void main()
{
	vec4 c = texture2D(iChannel0, gl_TexCoord[0].xy);

	float luminence = (0.2126*c.r + 0.7152*c.g + 0.0722*c.b);
	vec4 rawColor = mix(crushColor1,crushColor2, ge(luminence,0.2));

	c = vec4(rawColor.rgb,1.0) * rawColor.a * c.a;
	
	gl_FragColor = c*gl_Color;
}