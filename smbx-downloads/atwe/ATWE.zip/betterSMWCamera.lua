local betterSMWCamera = {}


local handycam = require("handycam")



local smallScreen
pcall(function() smallScreen = require("smallScreen") end)

if smallScreen ~= nil then
    smallScreen.positionChangingEnabled = false
end


local capeFeather
pcall(function() capeFeather = require("ap_cape_ai") end)

if capeFeather ~= nil then
    capeFeather.flightSettings.normalFlyingCamera = false 
end



betterSMWCamera.freeCamera = false



local SECTION_RESIZING_ADDR = 0x00B2B9E4


local cameraData = {targets = {}}
betterSMWCamera.cameraData = cameraData


function betterSMWCamera.getCameraSize(a)
    local width,height = camera.width,camera.height


    if smallScreen ~= nil and smallScreen.croppingEnabled then
        width  = smallScreen.width
        height = smallScreen.height
    end

    if a then Misc.dialog(require("smallScreen")) end

    local handyCamObj = rawget(handycam,1)

    if handyCamObj ~= nil and handyCamObj.zoom ~= nil and handyCamObj.zoom ~= 1 then
        width  = width /handyCamObj.zoom
        height = height/handyCamObj.zoom
    end


    return width,height
end

function betterSMWCamera.getCameraBounds()
    local width,height = betterSMWCamera.getCameraSize()

    local left   = camera.x + (camera.width *0.5) - (width *0.5)
    local top    = camera.y + (camera.height*0.5) - (height*0.5)
    local right  = left + width
    local bottom = top  + height

    return left,top,right,bottom
end


function betterSMWCamera.boundCameraPos(pos,b)
    b = b or player.sectionObj.boundary

    local width,height = betterSMWCamera.getCameraSize()

    local widthDifference   = (camera.width -width )*0.5
    local heightDifference  = (camera.height-height)*0.5

    return vector(
        math.clamp(pos.x,b.left-widthDifference ,b.right +widthDifference -camera.width ),
        math.clamp(pos.y,b.top -heightDifference,b.bottom+heightDifference-camera.height)
    )
end


local function getModes()
    --[[if player:mem(0x36,FIELD_BOOL) or player.climbing or player.forcedState ~= FORCEDSTATE_NONE then
        return betterSMWCamera.settings.specialModes
    else
        return betterSMWCamera.settings.normalModes
    end]]

    return betterSMWCamera.settings.normalModes
end

local function canSnapToIdeal() -- returns true if the camera is allowed to suddenly snap to the ideal position, in cases such as warping
    return (
        cameraData.currentSection ~= player.section
        or (player.forcedState == FORCEDSTATE_PIPE and player.forcedTimer == 101)
        or (player:mem(0x15C,FIELD_WORD) > cameraData.oldPlayerWarpCooldown)
    )
end


local function canDoLRScroll()
    return (
        cameraData.lrScrollDirection == 0
        and betterSMWCamera.settings.lrScrollOffset > 0
        and player.forcedState == FORCEDSTATE_NONE
        and player.deathTimer == 0
        and player:isOnGround()
    )
end


local function listsAreIdentical(a,b)
    local countA = #a
    local countB = #b

    if countA ~= countB then
        return false
    elseif countA == 0 and countB == 0 then
        return true
    end

    for i = 1, countA do
        local valueA = a[i]
        local valueB = b[i]

        if valueA ~= valueB then
            return false
        end
    end

    return true
end


-- Set up different modes
do
    local CATCHUP_STATE = {
        STILL       = 0,
        CATCHING_UP = 1,
        CAUGHT_UP   = 2,
    }

    local function catchUpGeneral(i,isSpecialMode)
        local distance = (cameraData.idealPos[i]-cameraData.currentPos[i])

        if cameraData.state[i] == CATCHUP_STATE.STILL then
            if math.abs(distance) > betterSMWCamera.settings.stayStillRange then
                cameraData.state[i] = CATCHUP_STATE.CATCHING_UP
            end
        elseif cameraData.state[i] == CATCHUP_STATE.CATCHING_UP then
            if math.abs(distance) > 1 then
                local speed
                if not isSpecialMode or cameraData.currentPos[i] < cameraData.idealPos[i] or (capeFeather ~= nil and capeFeather.ascentTimer ~= nil) then
                    speed = math.max(3,math.abs(cameraData.oldIdealPos[i]-cameraData.idealPos[i])*1.5)
                else
                    speed = 4.5
                end

                cameraData.currentPos[i] = cameraData.currentPos[i] + math.min(math.abs(distance),speed)*math.sign(distance)
            elseif isSpecialMode then
                cameraData.state[i] = CATCHUP_STATE.STILL
            else
                cameraData.state[i] = CATCHUP_STATE.CAUGHT_UP
            end
        elseif cameraData.state[i] == CATCHUP_STATE.CAUGHT_UP then
            if math.abs(distance) > 0.7 then
                cameraData.stateTimer[i] = betterSMWCamera.settings.movingTime
            end

            if cameraData.stateTimer[i] > 0 then
                cameraData.stateTimer[i] = cameraData.stateTimer[i] - 1
                cameraData.currentPos[i] = cameraData.idealPos[i]
            else
                cameraData.state[i] = CATCHUP_STATE.STILL
            end
        end
    end

    local function catchUpCondition(i)
        return (
            cameraData.state[i] ~= CATCHUP_STATE.STILL -- will continue scrolling if it started
            or player:isOnGround()
            or cameraData.currentPos[i] < cameraData.idealPos[i] -- moving down

            or player.climbing
            or player:mem(0x34,FIELD_WORD) > 0 -- water/quicksand
            or player:mem(0x16E,FIELD_BOOL) -- leaf flying

            or player.forcedState ~= FORCEDSTATE_NONE

            or (capeFeather ~= nil and capeFeather.ascentTimer ~= nil)
        )
    end


    function betterSMWCamera.MODE_CATCH_UP(i)
        catchUpGeneral(i,false)
    end

    function betterSMWCamera.MODE_CATCH_UP_CONDITIONAL(i)
        if catchUpCondition(i) then
            catchUpGeneral(i,true)
        end
    end


    function betterSMWCamera.MODE_NO_SCROLL(i)
        -- literally nothing
    end

    function betterSMWCamera.MODE_ALWAYS_IDEAL(i)
        cameraData.currentPos[i] = cameraData.idealPos[i]
    end
end


-- Camera lockers
local handleLockers

do
    local DIRECTION_UP    = 0
    local DIRECTION_RIGHT = 1
    local DIRECTION_DOWN  = 2
    local DIRECTION_LEFT  = 3

    local function getLockPushDirection(b,leniency,x1,y1,x2,y2)
        local settings = b.data._settings

        if x2 - math.max(0,cameraData.speed.x) - leniency <= b.x and settings.canLock_right then
            return DIRECTION_RIGHT
        elseif x1 - math.min(0,cameraData.speed.x) + leniency >= b.x + b.width and settings.canLock_left then
            return DIRECTION_LEFT
        elseif y1 - math.min(0,cameraData.speed.y) + leniency >= b.y + b.height and settings.canLock_up then
            return DIRECTION_UP
        elseif y2 - math.max(0,cameraData.speed.y) - leniency <= b.y and settings.canLock_down then
            return DIRECTION_DOWN
        end

        return nil
    end

    local function addBoundsFromLock(b,bounds,x1,y1,x2,y2)
        local pushDirection = getLockPushDirection(b,2,x1,y1,x2,y2) or getLockPushDirection(b,10,x1,y1,x2,y2)

        if pushDirection == nil then
            return
        end

        if pushDirection == DIRECTION_RIGHT then -- from the right
            bounds.right = math.min(bounds.right,b.x)
        elseif pushDirection == DIRECTION_LEFT then
            bounds.left = math.max(bounds.left,b.x + b.width)
        elseif pushDirection == DIRECTION_UP then
            bounds.top = math.max(bounds.top,b.y + b.height)
        elseif pushDirection == DIRECTION_DOWN then
            bounds.bottom = math.min(bounds.bottom,b.y)
        end
    end


    function handleLockers()
        cameraData.lockerBounds = {
            left   = -math.huge,
            right  =  math.huge,
            top    = -math.huge,
            bottom =  math.huge,
        }

        if betterSMWCamera.cameraLockerID == nil then
            return
        end

        local width,height = betterSMWCamera.getCameraSize()

        local x1 = cameraData.currentPos.x + camera.width *0.5 - width *0.5 - 1
        local y1 = cameraData.currentPos.y + camera.height*0.5 - height*0.5 - 1
        local x2 = x1 + width  + 2
        local y2 = y1 + height + 2
        
        for _,b in Block.iterateIntersecting(x1,y1,x2,y2) do
            if b.id == betterSMWCamera.cameraLockerID then
                local layerObj = b.data.layerObj

                if layerObj == nil or not layerObj.isHidden then
                    addBoundsFromLock(b,cameraData.lockerBounds,x1,y1,x2,y2)
                end

                --Colliders.Box(b.x - 8,b.y - 8,b.width + 16,b.height + 16):Draw()
            end
        end

        cameraData.currentPos = betterSMWCamera.boundCameraPos(cameraData.currentPos,cameraData.lockerBounds)
    end
end



local function getIdealPosition()
    -- Remove any invalid things
    for i = #cameraData.targets, 1, -1 do
        local obj = cameraData.targets[i]

        if obj.isValid == false then
            table.remove(cameraData.targets,i)
        end
    end


    local targetCount = #cameraData.targets

    local focusX,focusY

    if targetCount == 0 then
        focusX = player.x + player.width*0.5
        focusY = player.y + player.height
    else
        focusX = 0
        focusY = 0
        
        for _,obj in ipairs(cameraData.targets) do
            if obj.width ~= nil then
                focusX = focusX + (obj.x + obj.width*0.5)/targetCount
            else
                focusX = focusX + obj.x/targetCount
            end

            if obj.height ~= nil then
                focusY = focusY + (obj.y + obj.height*0.5)/targetCount
            else
                focusY = focusY + obj.y/targetCount
            end
        end
    end

    local idealPos = vector(focusX - camera.width*0.5 + betterSMWCamera.settings.offset.x,focusY - camera.height*0.5 + betterSMWCamera.settings.offset.y)

    if cameraData.lrScrollDirection == 0 then
        idealPos.x = idealPos.x + cameraData.lrScrollOffset
    elseif cameraData.lrScrollDirection ~= nil then
        idealPos.x = idealPos.x + cameraData.lrScrollSide*betterSMWCamera.settings.lrScrollOffset
    end

    if not betterSMWCamera.freeCamera then
        if cameraData.lockerBounds ~= nil then
            idealPos = betterSMWCamera.boundCameraPos(idealPos,cameraData.lockerBounds)
        end

        idealPos = betterSMWCamera.boundCameraPos(idealPos,player.sectionObj.boundary)
    end

    return idealPos
end


function betterSMWCamera.onInitAPI()
    registerEvent(betterSMWCamera,"onCameraUpdate")
    registerEvent(betterSMWCamera,"onReset")
end

function betterSMWCamera.onCameraUpdate()
    if not betterSMWCamera.settings.enabled then return end

    
    cameraData.idealPos = getIdealPosition()


    if cameraData.currentPos == nil then
        -- Initialise cameraData
        cameraData.currentPos = cameraData.idealPos

        cameraData.speed = vector.zero2
        
        cameraData.oldPos = cameraData.currentPos
        cameraData.oldIdealPos = cameraData.idealPos 

        cameraData.modes = getModes()
        cameraData.oldModes = getModes()

        cameraData.state = {0,0}
        cameraData.stateTimer = {0,0}


        cameraData.currentSection = player.section
        cameraData.oldPlayerWarpCooldown = player:mem(0x15C,FIELD_WORD)


        cameraData.oldTargets = table.iclone(cameraData.targets)


        cameraData.lockerBounds = nil


        cameraData.lrScrollDirection = 0
        cameraData.lrScrollSide = 0
        cameraData.lrScrollOffset = 0

        cameraData.lrScrollWaitTimer = 0


        cameraData.moveDuringPause = false
    end


    if cameraData.lrScrollDirection ~= 0 then
        local speed = betterSMWCamera.settings.lrScrollSpeed

        if cameraData.currentPos.x ~= cameraData.idealPos.x then
            cameraData.lrScrollOffset = cameraData.lrScrollOffset + cameraData.lrScrollDirection*speed
            cameraData.currentPos.x = cameraData.currentPos.x + cameraData.lrScrollDirection*speed

            handleLockers()

            if cameraData.lrScrollDirection < 0 then
                cameraData.currentPos.x = math.max(cameraData.currentPos.x,cameraData.idealPos.x)
            else
                cameraData.currentPos.x = math.min(cameraData.currentPos.x,cameraData.idealPos.x)
            end
        else
            cameraData.lrScrollDirection = 0

            if cameraData.lrScrollSide == 0 then
                cameraData.lrScrollOffset = 0
            end

            Misc.unpause()
        end
    elseif not Misc.isPaused() or mem(SECTION_RESIZING_ADDR,FIELD_BOOL) or cameraData.moveDuringPause then
        if canSnapToIdeal() then -- If we've just changed section, simply warp directly to the player
            cameraData.currentPos = cameraData.idealPos
            cameraData.lockerBounds = nil
            cameraData.lrScrollOffset = 0
            cameraData.lrScrollSide = 0
        end
        cameraData.currentSection = player.section
        cameraData.oldPlayerWarpCooldown = player:mem(0x15C,FIELD_WORD)


        local targetsHaventChanged = listsAreIdentical(cameraData.targets,cameraData.oldTargets)

        cameraData.modes = getModes()

        for i=1,2 do
            if cameraData.modes[i] ~= cameraData.oldModes[i] or not targetsHaventChanged then
                cameraData.state[i] = 0
                cameraData.stateTimer[i] = 0
            end

            if cameraData.modes[i] ~= nil then
                cameraData.modes[i](i)
            end
        end



        cameraData.speed = cameraData.currentPos-cameraData.oldPos

        -- The + 0's are to make sure that it is copied and not just moved
        cameraData.oldPos      = cameraData.currentPos+0
        cameraData.oldIdealPos = cameraData.idealPos+0

        for i=1,2 do
            cameraData.oldModes[i] = cameraData.modes[i]
        end
        --[[for direction = 1,4 do
            cameraData.oldGoalLimits[direction] = cameraData.goalLimits[direction]
        end]]

        cameraData.oldTargets = table.iclone(cameraData.targets)

        
        handleLockers()


        -- Handle L/R scrolling
        local holdingLeft = (player.rawKeys.left and cameraData.lrScrollOffset > -betterSMWCamera.settings.lrScrollOffset)
        local holdingRight = (player.rawKeys.right and cameraData.lrScrollOffset < betterSMWCamera.settings.lrScrollOffset)

        if canDoLRScroll() and player.keys.down and (holdingLeft or holdingRight) then
            cameraData.lrScrollWaitTimer = cameraData.lrScrollWaitTimer + 1

            if cameraData.lrScrollWaitTimer > betterSMWCamera.settings.lrScrollHoldTime then
                if holdingLeft then
                    cameraData.lrScrollDirection = -1
                    cameraData.lrScrollSide = math.max(-1,cameraData.lrScrollSide - 1)
                else
                    cameraData.lrScrollDirection = 1
                    cameraData.lrScrollSide = math.min(1,cameraData.lrScrollSide + 1)
                end

                cameraData.lrScrollWaitTimer = 0

                Misc.pause()
                SFX.play(13)
            end
        else
            cameraData.lrScrollWaitTimer = 0
        end

        if cameraData.lrScrollSide ~= 0 and cameraData.lrScrollDirection == 0 and (cameraData.idealPos.x - cameraData.currentPos.x)*cameraData.lrScrollSide < -betterSMWCamera.settings.stayStillRange*0.75 then
            cameraData.lrScrollSide = 0
            cameraData.lrScrollOffset = 0
        end
    end


    if not betterSMWCamera.freeCamera then
        cameraData.currentPos = betterSMWCamera.boundCameraPos(cameraData.currentPos)
    end


    --Text.print(cameraData.lrScrollOffset,32,96)
    --Text.print(cameraData.speed,32,32)


    camera.x = math.floor(cameraData.currentPos.x + 0.5)
    camera.y = math.floor(cameraData.currentPos.y + 0.5)

    --Graphics.drawBox{x = cameraData.idealPos.x - 8 + camera.width*0.5,y = cameraData.idealPos.y - 8 + camera.height*0.5,width = 16,height = 16,color = Color.blue.. 0.5,sceneCoords = true}
end


function betterSMWCamera.onReset(fromRespawn)
    if fromRespawn then
        cameraData.currentPos = nil
        cameraData.targets = {}
    end
end


betterSMWCamera.settings = {
    -- If false, this script will do nothing.
    enabled = true,

    -- SCROLLING MODES:
    -- MODE_CATCH_UP         : If the player is close enough to the centre of the camera, it will not scroll. Once the player is too far away, though, it'll start scrolling to catch up.
    -- MODE_CATCH_UP_CONDITIONAL : Same as MODE_CATCH_UP, but is only active if the player is certain states, such as standing on the ground, swimming, etc.
    -- MODE_NO_SCROLL        : Makes the camera not scroll at all in this direction.
    -- MODE_ALWAYS_IDEAL     : Makes the camera always exactly focus on the player, acting like SMBX's usual camera.

    -- The modes used when moving around normally. Each can be MODE_CATCH_UP. First is the horizontal mode, second is the vertical mode.
    normalModes = {
        betterSMWCamera.MODE_CATCH_UP,
        betterSMWCamera.MODE_CATCH_UP_CONDITIONAL,
    },


    offset = vector(0,0),


    -- If the player goes this distance from the current position, the camera will start moving.
    stayStillRange = 28,

    -- How long for the camera will continue to scroll after the player is still in range.
    movingTime = 6,


    -- How long you have to hold down left or right to acitvate the L/R scroll.
    lrScrollHoldTime = 64,
    -- How fast the camera scrolls during the L/R scroll transition.
    lrScrollSpeed = 4,
    -- How far the L/R scrolls offsets the camera.
    lrScrollOffset = 160,


    controllerScrollSpeed = 2.5,
}


return betterSMWCamera