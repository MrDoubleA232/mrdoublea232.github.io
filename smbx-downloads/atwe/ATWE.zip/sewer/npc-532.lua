local npcManager = require("npcManager")
local npcutils = require("npcs/npcutils")

local grrrol = {}
local npcID = NPC_ID


function grrrol.onInitAPI()
	npcManager.registerEvent(npcID, grrrol, "onTickNPC")
end

function grrrol.onTickNPC(v)
	if Defines.levelFreeze then return end
	
	local data = v.data
	
	if v.despawnTimer <= 0 then
		return
	end

	if v:mem(0x12C, FIELD_WORD) > 0    --Grabbed
	or v:mem(0x136, FIELD_BOOL)        --Thrown
	or v:mem(0x138, FIELD_WORD) > 0    --Contained within
	then return end
	
	
	local col = Colliders.getSpeedHitbox(v)
	local blocks = Colliders.getColliding{a = col,btype = Colliders.BLOCK}

	for _,block in ipairs(blocks) do
		local fromAbove = (v.y+v.height-v.speedY < block.y-block.speedY)

		block:hit(fromAbove)
	end
end

return grrrol