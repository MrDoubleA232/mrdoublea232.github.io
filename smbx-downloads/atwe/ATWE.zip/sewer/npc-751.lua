local npcManager = require("npcManager")
local npcutils = require("npcs/npcutils")

local expandedNets = require("expandedNets")


local fenceSideSwitcher = {}
local npcID = NPC_ID

local fenceSideSwitcherSettings = {
	id = npcID,
	
	gfxwidth = 128,
	gfxheight = 128,

	gfxoffsetx = 0,
	gfxoffsety = 0,
	
	width = 128,
	height = 128,
	
	frames = 9,
	framestyle = 0,
	framespeed = 8,
	
	speed = 1,
	
	npcblock = false,
	npcblocktop = false, --Misnomer, affects whether thrown NPCs bounce off the NPC.
	playerblock = false,
	playerblocktop = false, --Also handles other NPCs walking atop this NPC.

	nohurt = true,
	nogravity = true,
	noblockcollision = true,
	nofireball = true,
	noiceball = true,
	noyoshi = true,
	nowaterphysics = true,
	
	jumphurt = true,
	spinjumpsafe = false,
	harmlessgrab = false,
	harmlessthrown = false,

	ignorethrownnpcs = true,
	notcointransformable = true,

	isvine = true,


	hittableBoxWidth = 96,
	hittableBoxHeight = 96,
}

npcManager.setNpcSettings(fenceSideSwitcherSettings)
npcManager.registerHarmTypes(npcID,{HARM_TYPE_OFFSCREEN},{})


expandedNets.registerSwitcher(npcID)


function fenceSideSwitcher.onInitAPI()
	npcManager.registerEvent(npcID, fenceSideSwitcher, "onTickEndNPC")
	npcManager.registerEvent(npcID, fenceSideSwitcher, "onDrawNPC")
end

function fenceSideSwitcher.onTickEndNPC(v)
	if Defines.levelFreeze then return end
	
	local data = v.data
	
	if v.despawnTimer <= 0 then
		data.initialized = false
		return
	end

	if not data.initialized then
		data.initialized = true
	end


	local config = NPC.config[v.id]

	-- Find frame
	local frame = 0

	if expandedNets.playerData.swappingDepthTimer ~= nil and expandedNets.playerData.swappingDepthTimer > 0 and player.climbingNPC == v then
		-- Turn!
		frame = (expandedNets.playerData.swappingDepthTimer/expandedNets.swappingDepthLength)*2
		if frame > 1 then
			frame = 1-(frame-1)
		end

		frame = math.ceil(frame * (config.frames-1)) + 1
		frame = math.clamp(frame,1,config.frames-1)
	end

	v.animationFrame = npcutils.getFrameByFramestyle(v,{frame = frame})
end


function fenceSideSwitcher.onDrawNPC(v)
	if v.despawnTimer <= 0 or v.isHidden then return end

	npcutils.drawNPC(v,{priority = -75})
	npcutils.hideNPC(v)
end


return fenceSideSwitcher