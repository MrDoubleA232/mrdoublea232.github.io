local npcManager = require("npcManager")
local npcutils = require("npcs/npcutils")

local depthSwitching = require("depthSwitching")
local expandedNets = require("expandedNets")


local netKoopa = {}

netKoopa.sharedSettings = {
    gfxwidth = 32,
	gfxheight = 64,

	gfxoffsetx = 0,
	gfxoffsety = 0,
	
	width = 32,
	height = 32,
	
	frames = 7,
	framestyle = 1,
	framespeed = 8,
	
	speed = 1,
	
	npcblock = false,
	npcblocktop = false, --Misnomer, affects whether thrown NPCs bounce off the NPC.
	playerblock = false,
	playerblocktop = false, --Also handles other NPCs walking atop this NPC.

	nohurt = false,
	nogravity = true,
	noblockcollision = false,
	nofireball = false,
	noiceball = false,
	noyoshi = false,
	nowaterphysics = true,
	
	jumphurt = false,
	spinjumpsafe = false,
	harmlessgrab = false,
    harmlessthrown = false,
    
    luahandlesspeed = true,

	
    backClimbingFrames = 2,
    horizontalTurningFrames = 1,
    verticalTurningFrames = 2,

    turnLength = 18,
}


netKoopa.idList = {}
netKoopa.idMap  = {}

function netKoopa.register(npcID)
    npcManager.registerEvent(npcID, netKoopa, "onTickEndNPC")
    
    table.insert(netKoopa.idList,npcID)
    netKoopa.idMap[npcID] = true
end


local fenceBGOList = {}
local fenceNPCList = {}

local function findBGOSection(bgo)
    local sectionObj = Section.getFromCoords(bgo)
    if sectionObj ~= nil then
        return sectionObj.idx
    end

    local closestSection = 0
    local closestDistance = math.huge

    for _,sectionObj in ipairs(Section.get()) do
        local b = sectionObj.boundary

        local sectionX = (b.right + b.left) * 0.5
        local sectionY = (b.bottom + b.top) * 0.5

        local xDistance = sectionX - (v.x + v.width *0.5)
        local yDistance = sectionY - (v.y + v.height*0.5)
        local totalDistance = math.sqrt(xDistance*xDistance + yDistance*yDistance)

        if totalDistance < closestDistance then
            closestSection = sectionObj.idx
            closestDistance = totalDistance
        end
    end

    return closestSection
end


function netKoopa.refreshFenceList()
    fenceBGOList = {}
    fenceNPCList = {}


    for _,bgo in BGO.iterate() do
        local bgoConfig = BGO.config[bgo.id]

        if bgoConfig.climbable then
            local section = findBGOSection(bgo)

            fenceBGOList[section] = fenceBGOList[section] or {}
            table.insert(fenceBGOList[section],bgo)
        end
    end

    for _,npc in NPC.iterate(expandedNets.switcherIDList) do
        fenceNPCList[npc.section] = fenceNPCList[npc.section] or {}
        table.insert(fenceNPCList[npc.section],npc)
    end
end


local STATE = {
    CLIMB = 0,
    TURN  = 1,
}

local directions = {
    vector(-1,0),
    vector(0,-1),
    vector(1,0),
    vector(0,1),
}


local function getDepth(v)
    if v.data.depthSwitching ~= nil and v.data.depthSwitching.depth ~= nil then
        return v.data.depthSwitching.depth
    else
        return depthSwitching.depthValues.FRONT
    end
end

local function swapDepth(v)
    if v.data.depthSwitching ~= nil and v.data.depthSwitching.depth ~= nil then
        v.data.depthSwitching.depth = -v.data.depthSwitching.depth
    end
end


local function isOnFence(v,x1,y1,x2,y2)
    x1 = x1 or v.x + (v.width*0.5) - 1 + v.speedX
    y1 = y1 or v.y + v.speedY
    x2 = x2 or x1 + 2
    y2 = y2 or y1 + v.height

    -- Check for side switchers
    local npcList = fenceNPCList[v.section]

    if npcList ~= nil then
        for _,npc in ipairs(npcList) do
            if (x1 < npc.x+npc.width and x2 > npc.x and y1 < npc.y+npc.height and y2 > npc.y) and npc.despawnTimer > 0 and not npc.isGenerator and not npc.isHidden then
                return true
            end
        end
    end

    -- Check for BGO's
    local bgoList = fenceBGOList[v.section]

    if bgoList ~= nil then
        for _,bgo in ipairs(bgoList) do
            if (x1 < bgo.x+bgo.width and x2 > bgo.x and y1 < bgo.y+bgo.height and y2 > bgo.y) and not bgo.isHidden then
                return true
            end
        end
    end

    return false
end


local function handleAnimation(v,data,config)
    local frontClimbingFrames = (config.frames-config.backClimbingFrames-config.horizontalTurningFrames-config.verticalTurningFrames)

    local frame = 0

    if data.state == STATE.CLIMB then
        frame = math.floor(data.timer/config.framespeed)

        if getDepth(v) == depthSwitching.depthValues.FRONT then
            frame = frame%frontClimbingFrames
        else
            frame = (frame%config.backClimbingFrames)+frontClimbingFrames
        end
    elseif data.state == STATE.TURN then
        frame = (data.timer/config.turnLength)
        if not data.shouldSwapDepth then
            frame = (1-frame)
        end

        if data.direction.y ~= 0 then
            frame = math.floor(frame*config.verticalTurningFrames)+frontClimbingFrames+config.backClimbingFrames+config.horizontalTurningFrames
        else
            frame = math.floor(frame*config.horizontalTurningFrames)+frontClimbingFrames+config.backClimbingFrames
        end
    end

    v.animationFrame = npcutils.getFrameByFramestyle(v,{frame = frame})
end


function netKoopa.onTickEndNPC(v)
	if Defines.levelFreeze then return end
	
	local data = v.data
	
	if v.despawnTimer <= 0 then
		data.initialised = false
		return
    end
    
    local config = NPC.config[v.id]
    local settings = v.data._settings

	if not data.initialised then
        data.initialised = true

        data.state = STATE.CLIMB
        data.timer = 0

        data.shouldSwapDepth = false
        
        data.direction = directions[settings.direction+1]
	end

	if v:mem(0x12C, FIELD_WORD) > 0    --Grabbed
	or v:mem(0x136, FIELD_BOOL)        --Thrown
	or v:mem(0x138, FIELD_WORD) > 0    --Contained within
    then
        handleAnimation(v,data,config)
        return
    end
	
    
    data.timer = data.timer + 1

    if data.state == STATE.CLIMB then
        v.speedX = config.speed*data.direction.x
        v.speedY = config.speed*data.direction.y

        -- Side swapping
        if data.direction.y <= 0 and not isOnFence(v) then
            data.state = STATE.TURN
            data.timer = 0

            data.direction = -data.direction

            if getDepth(v) == depthSwitching.depthValues.BACK then
                swapDepth(v)
                data.shouldSwapDepth = false
            else
                data.shouldSwapDepth = true
            end

            v.speedX = 0
            v.speedY = 0
        elseif data.direction.y > 0 and not isOnFence(v,nil,v.y+v.height+v.speedY,nil,v.y+v.height+v.speedY+1) then
            data.direction.y = -data.direction.y
            v.speedY = 0
        -- Turn around after hitting a block
        elseif (v.collidesBlockLeft or v.collidesBlockRight) and v:mem(0x120,FIELD_BOOL) then
            data.direction.x = -data.direction.x
            v.speedX = 0

            v:mem(0x120,FIELD_BOOL,false)
        elseif v.collidesBlockUp or v.collidesBlockBottom then
            data.direction.y = -data.direction.y
            v.speedY = 0
        end
    elseif data.state == STATE.TURN then
        v.speedX = 0
        v.speedY = 0

        -- If completely off the fence, rever to a regular koopa
        local speedX = config.speed*data.direction.x
        local speedY = config.speed*data.direction.y

        if config.regularKoopaID ~= nil and not isOnFence(v,v.x + v.width*0.5 + speedX - 1,v.y + speedY,v.x + v.width*0.5 + speedX + 1,v.y + v.height + speedY) then
            v:transform(config.regularKoopaID)
            return
        end


        if data.timer >= config.turnLength then
            if data.shouldSwapDepth then
                swapDepth(v)
            end

            data.state = STATE.CLIMB
            data.timer = 0
        end
    end


    handleAnimation(v,data,config)
end


function netKoopa.onInitAPI()
    registerEvent(netKoopa,"onStart","refreshFenceList",false)
    registerEvent(netKoopa,"onReset","refreshFenceList",false)
end


return netKoopa