local betterSMWCamera = require("betterSMWCamera")


local hasDroppedIntoWater = false

function onReset(fromRespawn)
    if fromRespawn then
        hasDroppedIntoWater = false
    end
end

function onTick()
    if Checkpoint.getActive() ~= nil then
        hasDroppedIntoWater = true
    end
    
    if not hasDroppedIntoWater then
        for k,v in pairs(player.keys) do
            if k ~= "pause" and k ~= "dropItem" then
                player.keys[k] = false
            end
        end

        if player:mem(0x36,FIELD_BOOL) or player:isOnGround() then
            hasDroppedIntoWater = true
            SFX.play(72)
        end
    end
end


function onTickEnd()
    -- Make the camera focus on the dolphin during the dolphin surfing bit
    local targetCount = #betterSMWCamera.cameraData.targets

    if player.section == 3 then
        if targetCount == 0 then
            local standingNPC = player.standingNPC

            if standingNPC ~= nil and standingNPC.isValid and standingNPC.id == 460 and standingNPC.x > -132352 then
                betterSMWCamera.cameraData.targets = {standingNPC}
            end
        elseif player.deathTimer == 0 and player.forcedState == FORCEDSTATE_NONE then
            local cameraWidth,cameraHeight = betterSMWCamera.getCameraSize()

            local leftEdge  = betterSMWCamera.cameraData.currentPos.x + camera.width*0.5 - cameraWidth*0.5
            local rightEdge = leftEdge + cameraWidth - player.width

            if player.x <= leftEdge then
                player.x = leftEdge
                player.speedX = 3.1

                if player:mem(0x14C,FIELD_WORD) > 0 then
                    player:kill()
                end
            elseif player.x >= rightEdge then
                player.x = rightEdge
                player.speedX = -0.1

                if player:mem(0x148,FIELD_WORD) > 0 then
                    player:kill()
                end
            end
        end
    elseif targetCount > 0 then
        betterSMWCamera.cameraData.targets = {}
    end
end


--[[local depthSwitching = require("depthSwitching")

function onEvent(eventName)
    if eventName == "switch depth" then
        depthSwitching.setDepth(-depthSwitching.currentDepth)
    end
end



local IBLOCK_ADDR = mem(0x00B25798,FIELD_DWORD)
local IBLOCK_COUNT = 0x00B25784

local switchTimer = 0
local switchToHit

-- Change the value below to whatever you want (in ticks)
local switchDelay = 256


function onBlockHit(eventObj,v,fromTop,playerObj)
    if v.id ~= 173 then return end

    if switchTimer > 0 then
        -- Cancel the actual switch, but still do the animation + sound
        eventObj.cancelled = true

        -- Activate the offset
        v:mem(0x52,FIELD_WORD,-12)
        v:mem(0x54,FIELD_WORD,12)
        v:mem(0x56,FIELD_WORD,0)

        -- Add to redigit's 'intersesting blocks' array
        local iBlockCount = mem(IBLOCK_COUNT,FIELD_WORD)

        if iBlockCount == 0 or mem(IBLOCK_ADDR+(iBlockCount*0x02),FIELD_WORD) ~= v.idx then
            iBlockCount = iBlockCount + 1
            mem(IBLOCK_COUNT,FIELD_WORD,iBlockCount)

            mem(IBLOCK_ADDR+(iBlockCount*0x02),FIELD_WORD,v.idx)
        end


        SFX.play(32)
    end

    switchTimer = switchDelay
    switchToHit = v
end

function onTick()
    if switchTimer > 0 then
        switchTimer = switchTimer - 1

        if switchTimer == 0 and switchToHit ~= nil and switchToHit.isValid then
            switchToHit:hit()
            switchTimer = 0
        end
    end
end]]