local npcManager = require("npcManager")
local grabberAI = require("tedgrabber")
local npcID = NPC_ID
local torpedoTeds = {}

local gripSettings = table.join({
	id = npcID,

	gfxheight = 32,
	gfxwidth = 32,
	width = 32,
	height = 32,

	horizontal = false,
	direction = -1,
},grabberAI.sharedSettings)
npcManager.setNpcSettings(gripSettings)
grabberAI.register(npcID)
	
return torpedoTeds