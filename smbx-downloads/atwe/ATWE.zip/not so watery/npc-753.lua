local npcManager = require("npcManager")
local spawnerAI = require("tedspawner_custom")
local npcID = NPC_ID
local torpedoTeds = {}

local gripSettings = table.join({
	id = npcID,

	gfxheight = 32,
	gfxwidth = 32,
	width = 32,
	height = 32,

	traveldistance=-64,
	anchory=-1, -- -1 is top
	spawnid = 757,
	horizontal = true,
},spawnerAI.sharedSettings)
npcManager.setNpcSettings(gripSettings)
spawnerAI.register(npcID)
	
return torpedoTeds