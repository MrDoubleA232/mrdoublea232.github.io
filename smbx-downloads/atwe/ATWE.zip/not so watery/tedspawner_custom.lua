local npcManager = require("npcManager")
local npcutils = require("npcs/npcutils")

local torpedoTeds = {}

local STATE_WAIT = 0
local STATE_DOWN = 1
local STATE_RELEASE = 2
local STATE_UP = 3

local countDown = {}
countDown[STATE_WAIT] = true
countDown[STATE_RELEASE] = true

local anchors = {
	[-1] = -1,
	[1] = 0
}


local allThoseVariableNames = {
	[false] = {x = "x",y = "y",speedX = "speedX",speedY = "speedY",width = "width" ,height = "height",spawnX = "spawnX",spawnY = "spawnY"},
	[true]  = {x = "y",y = "x",speedX = "speedY",speedY = "speedX",width = "height",height = "width" ,spawnX = "spawnY",spawnY = "spawnX"},
}


torpedoTeds.sharedSettings = {
	framestyle = 0,
	jumphurt = 1,
	nogravity = 1,
	noblockcollision = 1,
	nofireball=1,
	noiceball=1,
	frames=2,
	ignorethrownnpcs = true,
	noyoshi=1,
	nohurt=1,
	spinjumpsafe = false,
	harmlessgrab=true,

	delay=40,
	force=0.5,
    spawnspeed=1.2,
	heldframe=0,
	spawnerpriority=-70,
}


local function initialise(v)
	local data = v.data._basegame
	local cfg = NPC.config[v.id]

	local names = allThoseVariableNames[cfg.horizontal]

	data.lastHeld = v:mem(0x12C,FIELD_WORD)
	data.gripTimer = cfg.delay
	data.gripState = STATE_WAIT
	data.animationFrame = 0
	local yMod = -cfg.traveldistance
	if v:mem(0x138, FIELD_WORD) > 0 or v:mem(0x12C,FIELD_WORD) > 0 then
		yMod = 0
	end
	data.startY = v[names.spawnY] + yMod
	if data.startY == 0 then data.startY = v[names.y] end
	v[names.y] = v[names.y] + yMod
	data.direction = v.direction
end


function torpedoTeds.register(id)
	npcManager.registerEvent(id, torpedoTeds, "onTickEndNPC", "onTickEndGrip", true)
	npcManager.registerEvent(id, torpedoTeds, "onDrawNPC", "onDrawGrip")
end

function torpedoTeds.onTickEndGrip(v)
	if Defines.levelFreeze or v:mem(0x138, FIELD_WORD) > 0 then return end
	
	local data = v.data._basegame
	
	if v.isHidden or v:mem(0x12A, FIELD_WORD) <= 0 then
		data.gripTimer = nil

		if data.grippedTed ~= nil and data.grippedTed.isValid then
			data.grippedTed:kill(HARM_TYPE_VANISH)
		end

		return
	end

	local cfg = NPC.config[v.id]
	local held = v:mem(0x12C, FIELD_WORD)

	local names = allThoseVariableNames[cfg.horizontal]

	if data.gripTimer == nil then
		initialise(v)
	end
	if data.lastHeld > 0 and held == 0 then
		data.startY = v[names.y]
	end
	data.lastHeld = held
	
	v.animationFrame = 500
	v.animationTimer = 500
	if v:mem(0x12C, FIELD_WORD) > 0  then return end
	local lSpeedX, lSpeedY = npcutils.getLayerSpeed(v)
    data.startY = data.startY + lSpeedY
	v.x = v.x + lSpeedX
	v.y = v.y + lSpeedY
	v[names.speedY] = 0
	if countDown[data.gripState] then
		data.gripTimer = data.gripTimer - 1
	end
	if data.gripState == STATE_DOWN then
        if cfg.traveldistance < 0 then
            v[names.y] = v[names.y] - cfg.spawnspeed
            if v[names.y] <= data.startY + cfg.traveldistance then
                data.gripState = (data.gripState + 1)%4
                data.gripTimer = cfg.delay
				if data.grippedTed.isValid then
					data.grippedTed:mem(0x12C, FIELD_WORD, 0)
				end
                data.grippedTed = nil
                v[names.y] = data.startY + cfg.traveldistance
            end
        else
            v[names.y] = v[names.y] + cfg.spawnspeed
            if v[names.y] >= data.startY + cfg.traveldistance then
                data.gripState = (data.gripState + 1)%4
                data.gripTimer = cfg.delay
				if data.grippedTed.isValid then
					data.grippedTed:mem(0x12C, FIELD_WORD, 0)
				end
                data.grippedTed = nil
                v[names.y] = data.startY + cfg.traveldistance
            end
        end
	elseif data.gripState == STATE_UP then
        if cfg.traveldistance < 0 then
            v[names.y] = v[names.y] + cfg.spawnspeed
            if v[names.y] >= data.startY then
                data.gripState = (data.gripState + 1)%4
                data.gripTimer = cfg.delay
                v[names.y] = data.startY
            end
        else
            v[names.y] = v[names.y] - cfg.spawnspeed
            if v[names.y] <= data.startY then
                data.gripState = (data.gripState + 1)%4
                data.gripTimer = cfg.delay
                v[names.y] = data.startY
            end
        end
	end
	if data.gripState < 2 then
		data.animationFrame = 0
	else
		data.animationFrame = 1
	end
	if data.gripTimer == 0 then
		if data.gripState == STATE_WAIT then
			--if v.direction == 0 then
			if v.dontMove then
				data.direction = -1
				if Player.getNearest(v.x + 0.5 * v.width, v.y + 0.5 * v.height).x > v.x + 0.5 * v.width then
					data.direction = 1
				end
			end
			local t = NPC.spawn(cfg.spawnid, v.x + 0.5 * v.width, v.y + v.height + NPC.config[cfg.spawnid].height * anchors[cfg.anchory], v:mem(0x146, FIELD_WORD), false, true)
			t.direction = data.direction
			t.friendly = v.friendly
			t[names.speedY] = cfg.force * math.sign(cfg.traveldistance)
			t:mem(0x12C, FIELD_WORD, -1)
			t.layerName = "Spawned NPCs"
			data.grippedTed = t
		end
		data.gripState = (data.gripState + 1)%4
		data.gripTimer = 100
	end
	if data.grippedTed ~= nil then
		if data.grippedTed.isValid then
			--data.grippedTed.x = v.x + 0.5 * v.width - 0.5 * data.grippedTed.width
			--data.grippedTed.y = v.y + 0.5 * v.height + data.grippedTed.height * anchors[cfg.anchory]
			data.grippedTed[names.x] = v[names.x] + 0.5 * v[names.width] - 0.5 * data.grippedTed[names.width]
			data.grippedTed[names.y] = v[names.y] + 0.5 * v[names.height] + data.grippedTed[names.height] * anchors[cfg.anchory]
		end
	end
end

function torpedoTeds.onDrawGrip(v)
	if v.isHidden or v:mem(0x138, FIELD_WORD) > 0 or v:mem(0x12A, FIELD_WORD) <= 0 then return end
	
	local cfg = NPC.config[v.id]
	
	local data = v.data._basegame
	if data.gripTimer == nil then
		initialise(v)
	end
	
	Graphics.drawImageToSceneWP(
		Graphics.sprites.npc[v.id].img,
		v.x + 0.5 * v.width - 0.5 * cfg.gfxwidth + cfg.gfxoffsetx,
		v.y + 0.5 * v.height - 0.5 * cfg.gfxheight + cfg.gfxoffsety,
		0,
		cfg.gfxheight * data.animationFrame,
		cfg.gfxwidth,
		cfg.gfxheight,
		cfg.spawnerpriority
    )
    npcutils.hideNPC(v)
    if data.grippedTed and data.grippedTed.isValid then
        local heldframe = cfg.heldframe
		cfg = NPC.config[data.grippedTed.id]

		local gfxwidth, gfxheight = cfg.gfxwidth, cfg.gfxheight
		if gfxwidth == 0 then gfxwidth = cfg.width end
		if gfxheight == 0 then gfxheight = cfg.height end

		Graphics.drawImageToSceneWP(
			Graphics.sprites.npc[data.grippedTed.id].img,
			data.grippedTed.x + 0.5 * data.grippedTed.width - 0.5 * gfxwidth + cfg.gfxoffsetx,
			data.grippedTed.y + 0.5 * data.grippedTed.height - 0.5 * gfxheight + cfg.gfxoffsety,
			0,
			(gfxheight + gfxheight * data.grippedTed.direction * cfg.framestyle) + gfxheight * heldframe,
			gfxwidth,
			gfxheight,
			cfg.spawnpriority
		)
		npcutils.hideNPC(data.grippedTed)
	end
end
	
return torpedoTeds