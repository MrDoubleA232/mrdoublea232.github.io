local npcManager = require("npcManager")
local npcutils = require("npcs/npcutils")

local betterSMWCamera = require("betterSMWCamera")


local cameraController = {}
local npcID = NPC_ID

local cameraControllerSettings = {
	id = npcID,
	
	gfxwidth = 32,
	gfxheight = 32,

	gfxoffsetx = 0,
	gfxoffsety = 0,
	
	width = 32,
	height = 32,
	
	frames = 1,
	framestyle = 0,
	framespeed = 8,
	
	speed = 1,
	
	npcblock = false,
	npcblocktop = false, --Misnomer, affects whether thrown NPCs bounce off the NPC.
	playerblock = false,
	playerblocktop = false, --Also handles other NPCs walking atop this NPC.

	nohurt = true,
	nogravity = true,
	noblockcollision = true,
	nofireball = true,
	noiceball = true,
	noyoshi = true,
	nowaterphysics = true,
	
	jumphurt = true,
	spinjumpsafe = false,
	harmlessgrab = false,
	harmlessthrown = false,

	ignorethrownnpcs = true,
	notcointransformable = true,
}

npcManager.setNpcSettings(cameraControllerSettings)
npcManager.registerHarmTypes(npcID,{HARM_TYPE_OFFSCREEN},{})


function cameraController.onInitAPI()
	npcManager.registerEvent(npcID, cameraController, "onTickNPC")
	--npcManager.registerEvent(npcID, cameraController, "onTickEndNPC")
	--npcManager.registerEvent(npcID, cameraController, "onDrawNPC")
	--registerEvent(cameraController, "onNPCKill")
end


local onScreenLeniency = 4

local DIRECTION = {
	UP = 1,
	RIGHT = 2,
	DOWN = 3,
	LEFT = 4,
}

local function getHitSide(v)
	local left,top,right,bottom = betterSMWCamera.getCameraBounds()
	local cameraData = betterSMWCamera.cameraData

	if (v.x-v.speedX) > (right-cameraData.speed.x) then
		return DIRECTION.LEFT
	elseif (v.x+v.width-v.speedX) < (left-cameraData.speed.x) then
		return DIRECTION.RIGHT
	elseif (v.y-v.speedY) > (bottom-cameraData.speed.y) then
		return DIRECTION.UP
	elseif (v.y+v.height-v.speedY) < (top-cameraData.speed.y) then
		return DIRECTION.DOWN
	end
end


function cameraController.onTickNPC(v)
	--if Defines.levelFreeze then return end
	
	local data = v.data
	
	if v.despawnTimer <= 0 then
		data.initialized = false
		return
	end

	if not data.initialized then
		data.initialized = true

		data.acitve = false
	end


	if betterSMWCamera.cameraData.currentPos ~= nil and betterSMWCamera.controllerIsOnScreen(v,onScreenLeniency) then
		v.despawnTimer = math.max(v.despawnTimer,100)

		if not data.active then
			local hitSide = getHitSide(v)

			local direction = v.data._settings.direction
			if direction == 0 then
				direction = hitSide
			elseif v.data._settings.directionSensitive and hitSide ~= direction then
				direction = nil
			end

			if direction ~= nil then
				betterSMWCamera.addController(v,direction)
			end

			data.active = true
		end
	elseif data.active then
		betterSMWCamera.removeController(v)
		
		data.active = false
	end
end


return cameraController