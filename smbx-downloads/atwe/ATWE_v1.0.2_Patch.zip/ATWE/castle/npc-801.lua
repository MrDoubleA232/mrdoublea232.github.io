local npcManager = require("npcManager")
local npcutils = require("npcs/npcutils")

local betterSMWCamera = require("betterSMWCamera")
local littleDialogue = require("littleDialogue")
local paletteChange = require("paletteChange")

local someWeatherStuff = require("someWeatherStuff")

local kamekController = require("bigBadBoss/controller")

local extendedPlayerStuff = require("extendedPlayerStuff")

local levels = require("levels")

local progressStuff = require("progressStuff")


local kamek = {}
local npcID = NPC_ID


local kamekSettings = {
	id = npcID,
	
	gfxwidth = 128,
	gfxheight = 96,

	gfxoffsetx = 0,
	gfxoffsety = 24,
	
	width = 48,
	height = 32,
	
	frames = 12,
	framestyle = 0,
	framespeed = 8,
	
	speed = 1,
	
	npcblock = false,
	npcblocktop = false, --Misnomer, affects whether thrown NPCs bounce off the NPC.
	playerblock = false,
	playerblocktop = false, --Also handles other NPCs walking atop this NPC.

	nohurt = false,
	nogravity = true,
	noblockcollision = true,
	nofireball = false,
	noiceball = true,
	noyoshi = true,
	nowaterphysics = true,
	
	jumphurt = false,
	spinjumpsafe = false,
	harmlessgrab = false,
	harmlessthrown = false,

	staticdirection = true,
	score = 0,
}

npcManager.setNpcSettings(kamekSettings)
npcManager.registerHarmTypes(npcID,
	{
		HARM_TYPE_JUMP,
		--HARM_TYPE_FROMBELOW,
		HARM_TYPE_NPC,
		--HARM_TYPE_PROJECTILE_USED,
		--HARM_TYPE_LAVA,
		--HARM_TYPE_HELD,
		--HARM_TYPE_TAIL,
		--HARM_TYPE_SPINJUMP,
		--HARM_TYPE_OFFSCREEN,
		HARM_TYPE_SWORD
	},
	{
		--[HARM_TYPE_JUMP]            = 10,
		--[HARM_TYPE_FROMBELOW]       = 10,
		--[HARM_TYPE_NPC]             = 10,
		--[HARM_TYPE_PROJECTILE_USED] = 10,
		--[HARM_TYPE_LAVA]            = {id=13, xoffset=0.5, xoffsetBack = 0, yoffset=1, yoffsetBack = 1.5},
		--[HARM_TYPE_HELD]            = 10,
		--[HARM_TYPE_TAIL]            = 10,
		--[HARM_TYPE_SPINJUMP]        = 10,
		--[HARM_TYPE_OFFSCREEN]       = 10,
		--[HARM_TYPE_SWORD]           = 10,
	}
)


local folderName = Misc.resolveDirectory("bigBadBoss").. "\\"

local mainImage = Graphics.loadImage(folderName.. "main.png")

local cardboardImage = Graphics.loadImage(folderName.. "cardboard.png")
local cardboardFrames = 3

local magicEffectImage = Graphics.loadImage(folderName.. "magic.png")

local rotatingPlatformImage = Graphics.loadImage(folderName.. "rotatingArena.png")

local wipeImage = Graphics.loadImage(folderName.. "wipe.png")

local thumpSound = Misc.resolveSoundFile("bowlingball")

local thatSound = Misc.resolveSoundFile("bigBadBoss/thatSound")
local growSound = Misc.resolveSoundFile("bigBadBoss/grow")
local flyInSound = Misc.resolveSoundFile("bigBadBoss/flyIn")

local defeatEffectSound = Misc.resolveSoundFile("bigBadBoss/defeatEffect")

local flyAwaySound = Misc.resolveSoundFile("bigBadBoss/flyAway")
local endFanfareSound = Misc.resolveSoundFile("bigBadBoss/endFanfare")


local lightningOpacity = 0
local playerInputDisabled = false
local playerForceHoldButtons = {}

local playerFrameX,playerFrameY

local wipeProgress = 0
local finalFadeOut = 0
local veryCoolEgg


local magicEffects = {}
local defeatEffects = {}


local stateRoutines = {}


local STATE = {
	INTRO   = 0,
	PHASE_1 = 1,
	PHASE_2 = 2,
	PHASE_3 = 3,
	PHASE_4 = 4,
	END     = 5,
}


local DISTANCE_FROM_CENTRE = 320
local FLOOR_HEIGHT = 416

local DEBUG_SKIP_INTRO = false
local DEBUG_START_PHASE = 1
local DEBUG_SHOW_ROTATING = false


local MAGIC_TYPE = kamekController.MAGIC_TYPE


local rotatingPlatformActive = false
local rotatingPlatformRotation = 0
local rotatingPlatformOldRotation = 0
local rotatingPlatformTimer = 0
local rotatingPlatformDirection = 0
local rotatingPlatformYOffset = 0
local rotatingPlatformRetracting = false

local rotatingPlatformSlope
local rotatingPlatformSecondaryBlock
local rotatingPlatformSprite

local ROTATINGPLAT_WIDTH = 480
local ROTATINGPLAT_HEIGHT = 192
local ROTATINGPLAT_START_Y = FLOOR_HEIGHT
local ROTATINGPLAT_Y_OFFSET = -64
local ROTATINGPLAT_MAXROTATION = 20


local phaseData = {
	[1] = {health = 5,state = STATE.PHASE_1},
	[2] = {health = 3,state = STATE.PHASE_2},
	[3] = {health = 3,state = STATE.PHASE_3},
	[4] = {health = 2,state = STATE.PHASE_4},
}


GameData.watchedKamekIntro = GameData.watchedKamekIntro or false


local animations = {
	idle = {1},
	talk = {1,2,3,2,1, frameDelay = 4,loops = true},

	raiseWand = {4,5, frameDelay = 4},
	lowerWand = {4,1, frameDelay = 2},

	fly = {8,9, frameDelay = 2,loops = true},
	stop = {6},
	REALLYStop = {7},

	tiny = {11,12, frameDelay = 2,loops = true},

	invisible = {-1},
}

local function handleAnimation(v,data,config)
	if data.animation ~= data.currentAnimation then
		data.currentAnimation = data.animation
		data.animationTimer = 0
	end

	local animationData = animations[data.animation]
	local frameCount = #animationData

	data.frameIndex = math.floor(data.animationTimer / (animationData.frameDelay or 1))

	if data.frameIndex >= frameCount then
		if animationData.loops then
			data.frameIndex = data.frameIndex % frameCount
		else
			data.frameIndex = frameCount - 1
		end
	end

	data.frameIndex = data.frameIndex + 1

	data.frame = animationData[data.frameIndex] or -1

	data.animationTimer = data.animationTimer + 1
end


local function createDialogueBox(speakerObj,text)
	local box = littleDialogue.create{text = text,speakerObj = speakerObj,pauses = false}

	while (box.state ~= littleDialogue.BOX_STATE.REMOVE) do
		Routine.skip()
	end
end


local function doMusicFadeOut(v,waitTime,minVolume)
	while (Audio.MusicVolume() > minVolume) do
		Audio.MusicVolume(Audio.MusicVolume() - 1)
		Routine.waitFrames(waitTime)
	end

	if minVolume == 0 then
		v.sectionObj.music = 0
		Audio.MusicVolume(64)
	end
end

local function getCentre(v)
	local b = v.sectionObj.boundary
	
	return (b.left + b.right) * 0.5
end


local function teleport(v,data,config, x,y,direction,waitTime)
	SFX.play(41)

	while (data.teleportFade < 1) do
		data.teleportFade = math.min(1,data.teleportFade + 0.08)
		Routine.skip()
	end

	Routine.wait(waitTime or 0.5)

	v.x = x - v.width*0.5
	v.y = y - v.height
	v.speedX = 0
	v.speedY = 0
	v.direction = direction

	data.palette = 0
	data.floatTimer = 0

	SFX.play(41)

	while (data.teleportFade > 0) do
		data.teleportFade = math.max(0,data.teleportFade - 0.08)
		Routine.skip()
	end

	Routine.wait(0.2)
end


local function shootMagic(v,data,config, type,angleOffset,speed)
	if data.animation ~= "raiseWand" then
		data.animation = "raiseWand"
		Routine.wait(0.35)
	end

	local offsetX = v.width*0.5 + 20
	local offsetY = -32

	local magic = NPC.spawn(kamekController.magicID, v.x + v.width*0.5 + offsetX*v.direction,v.y + v.height + offsetY, v.section, false,true)
	local magicData = magic.data

	magic.direction = v.direction
	magic.friendly = true

	magicData.parent = v
	magicData.offsetX = offsetX
	magicData.offsetY = offsetY

	magicData.type = type or MAGIC_TYPE.DIRECT
	magicData.angleOffset = (angleOffset or 0) * v.direction
	magicData.speed = speed or 5

	magicData.scale = 1
	magicData.timerPaused = false

	return magic,magicData
end


local function shootSpawningMagic(v,data,config, id,goalOffsetY)
	data.animation = "idle"
	data.floatActive = true

	teleport(v,data,config, getCentre(v) + 160*v.direction,v.sectionObj.boundary.top + 128,-v.direction)
	Routine.wait(0.3)


	local magic,magicData = shootMagic(v,data,config, MAGIC_TYPE.SPAWNER,0,3)
		
	magicData.goalX = getCentre(v)
	magicData.goalY = v.sectionObj.boundary.top + FLOOR_HEIGHT - magic.height*2 + goalOffsetY
	magicData.spawnID = id

	magicData.timerPaused = true

	Routine.wait(0.2)

	for i = 1,2 do
		SFX.play(growSound)

		local growSpeed = 0.05

		for j = 0,math.floor(0.5 / growSpeed) do
			magicData.scale = math.min(1 + i*0.5,magicData.scale + growSpeed)
			Routine.skip()
		end

		Routine.wait(0.4)
	end

	magicData.timerPaused = false

	while (magic.isValid and not magicData.hasBeenShot) do
		Routine.skip()
	end

	data.animation = "lowerWand"

	while (magic.isValid) do
		Routine.skip()
	end

	SFX.play(41)
end


local function doTalkThing(v,data,config)
	data.animation = "talk"

	for i = 1,2 do
		SFX.play(thatSound)

		Routine.wait(0.5)
	end

	while (data.frameIndex > 1) do
		Routine.skip()
	end

	data.animation = "idle"
end


local function doNewPhaseThing(v,data,config)
	v.speedX = 0
	v.speedY = 0
	data.floatActive = true
	data.isInvincible = true

	doTalkThing(v,data,config)

	Routine.wait(0.15)

	data.animation = "REALLYStop"
	Routine.wait(0.08)

	v.direction = -v.direction
	Routine.wait(0.08)

	data.animation = "stop"
	Routine.wait(0.16)

	local b = v.sectionObj.origBoundary
	local speed = 11

	data.floatActive = false
	v.speedY = 0

	while (v.x+v.width >= b.left and v.x <= b.right) do
		speed = math.max(8.5,speed - 0.1)
		v.speedX = speed * v.direction

		data.animation = "fly"

		Routine.skip()
	end

	data.isInvincible = false
end


local function stopRoutine(v,data)
	if data.stateRoutine ~= nil and data.stateRoutine.isValid and data.stateRoutine:getTime() > 0 then
		data.stateRoutine:abort()
	end

	data.stateRoutine = nil
end

local function setState(v,data,config,newState)
	stopRoutine(v,data)

	local routineFunc = stateRoutines[newState]

	if routineFunc ~= nil then
		data.stateRoutine = Routine.run(routineFunc,v,data,config)
	end

	data.state = newState
end


local function npcIDExists(id)
	for _,npc in NPC.iterate(id,Section.getActiveIndices()) do
		if npc.despawnTimer > 0 and not npc.isGenerator and not npc.friendly then
			return true
		end
	end

	return false
end



local function clearNPCs()
	local removeIDs = table.map{kamekController.magicID,kamekController.iggyID}

	for _,npc in NPC.iterate() do
		if npc.despawnTimer > 0 and removeIDs[npc.id] then
			local e = Effect.spawn(10,npc.x + npc.width*0.5,npc.y + npc.height*0.5)

			e.x = e.x - e.width *0.5
			e.y = e.y - e.height*0.5

			npc:kill(HARM_TYPE_VANISH)
		end
	end
end




stateRoutines[STATE.INTRO] = (function(v,data,config)
	someWeatherStuff.rainIntensity = 1
	someWeatherStuff.lightningActive = true

	betterSMWCamera.cameraData.targets = {}

	data.isInvincible = true

	local b = v.sectionObj.boundary

	local centre = (b.left + b.right) * 0.5


	if not GameData.watchedKamekIntro then
		data.cardboardX = centre
		data.cardboardY = b.top + 128
		data.cardboardAngle = 0
		data.cardboardShadow = true
	end


	while (player.y+player.height > b.top+416) do
		Routine.skip()
	end

	betterSMWCamera.cameraData.targets = {vector(centre,b.top)}


	someWeatherStuff.lightningActive = false


	if not GameData.watchedKamekIntro then
		Routine.wait(2)


		playerInputDisabled = true

		createDialogueBox(vector(data.cardboardX,data.cardboardY + 144),"Gwahaha, you've finally arrived!|I knew you'd get here, considering how little level design there was...|<size 0.75>(I should really stop letting my level builders sleep on the job...)</size>|BUT NOW! It's time for us to begin...")

		
		-- Lightning
		do
			SFX.play(43)

			while (lightningOpacity < 1) do
				lightningOpacity = lightningOpacity + 0.15
				Routine.skip()
			end

			Routine.wait(0.6)

			doMusicFadeOut(v,2,0)

			while (someWeatherStuff.rainIntensity > 0) do
				someWeatherStuff.rainIntensity = math.max(0,someWeatherStuff.rainIntensity - 0.05)
				Routine.skip()
			end

			data.cardboardShadow = false

			while (lightningOpacity > 0) do
				lightningOpacity = lightningOpacity - 0.05
				Routine.skip()
			end


			Routine.wait(1)
		end


		-- Cardboard falls over
		do
			local rotationSpeed = 0

			while (true) do
				rotationSpeed = rotationSpeed + 0.05
				data.cardboardAngle = math.min(90,data.cardboardAngle + rotationSpeed)

				if data.cardboardAngle >= 90 then
					if rotationSpeed > 0.5 then
						rotationSpeed = -rotationSpeed * 0.5
						SFX.play(thumpSound)
					else
						data.cardboardX = nil
						break
					end
				end

				Routine.skip()
			end

			Routine.wait(0.2)

			Layer.get("boss - cutscene platform"):hide(false)
		end

		Routine.wait(0.6)

		v.sectionObj.music = "music/Yoshi's Island - Kamek's Theme.spc|0;g=2.4;"

		Routine.wait(0.8)
	else
		Layer.get("boss - cutscene platform"):hide(false)

		Routine.wait(2)

		Routine.run(doMusicFadeOut,v,1,32)

		while (someWeatherStuff.rainIntensity > 0) do
			someWeatherStuff.rainIntensity = math.max(0,someWeatherStuff.rainIntensity - 0.05)
			Routine.skip()
		end
	end


	-- Change section bounds
	do
		b.bottom = b.top + 450

		v.sectionObj.boundary = b

		betterSMWCamera.cameraData.targets = {}
	end
	


	v.x = b.right + 64
	v.y = b.top + 96

	v.speedX = -7

	data.animation = "fly"
	data.floatActive = false


	while (v.x+v.width*0.5 > centre+224) do
		Routine.skip()
	end

	while (v.speedX ~= 0) do
		if math.abs(v.speedX) > 4 then
			data.animation = "stop"
			data.shake = 1
			v.speedX = math.min(0,v.speedX + 0.1)
		else
			data.animation = "REALLYStop"
			data.shake = 0
			v.speedX = math.min(0,v.speedX + 0.2)
		end

		Routine.skip()
	end

	Routine.wait(0.2)

	data.animation = "idle"
	data.floatActive = true


	if not DEBUG_SKIP_INTRO then
		if not GameData.watchedKamekIntro then
			Routine.wait(0.1)

			doTalkThing(v,data,config)

			createDialogueBox(vector(v.x+v.width*0.5,v.y+v.height+192),"<boxStyle yi><size 3>IT'S ME!!!</size>|Err, yes, it's me... not... that piece of cardboard.|Regardless, I think it's about time that you go now.|<size 2>Goodbye!!</size>")
		end


		Routine.wait(0.2)

		playerInputDisabled = false

		for i = 1,2 do
			data.animation = "raiseWand"

			Routine.wait(0.2)
			
			data.animation = "lowerWand"

			table.insert(magicEffects,{
				x = v.x + v.width*0.5,
				y = v.y + v.height,
				timer = 0,
			})

			SFX.play(59)

			Routine.wait(0.6)

			if i == 1 then
				data.palette = 1
				Routine.run(doMusicFadeOut,v,1,0)
			end

			Routine.wait(0.8)
		end
	end


	Routine.wait(0.3)
	

	v.sectionObj.music = "music/Hollow Knight - Mantis Lords - Ported by Maxodex.spc|0;g=2.7;"
	Audio.MusicVolume(64)

	GameData.watchedKamekIntro = true

	data.isInvincible = false

	setState(v,data,config,phaseData[data.phase].state)
	--teleport(v,data,config, centre + 256 + 64,b.top + 384 - 32)
end)

stateRoutines[STATE.PHASE_1] = (function(v,data,config)
	local b = v.sectionObj.boundary

	while (true) do
		-- Shoot from right
		teleport(v,data,config, getCentre(v) + DISTANCE_FROM_CENTRE,b.top + FLOOR_HEIGHT - 64,DIR_LEFT)
		Routine.wait(0.3)

		for i = 1,3 do
			shootMagic(v,data,config, MAGIC_TYPE.DIRECT,(i - 2)*15)
			Routine.wait(0.6)
		end

		data.animation = "lowerWand"

		-- Shoot from left
		teleport(v,data,config, getCentre(v) - DISTANCE_FROM_CENTRE,b.top + FLOOR_HEIGHT - 64,DIR_RIGHT)
		Routine.wait(0.3)

		for i = 1,6 do
			shootMagic(v,data,config, MAGIC_TYPE.DIRECT,(i - 3.5)*20,4)
			Routine.wait(0.15)
		end

		data.animation = "lowerWand"

		-- Shoot from above
		teleport(v,data,config, getCentre(v) - 160,b.top + 128,DIR_RIGHT)
		Routine.wait(0.1)

		for i = 1,3 do
			shootMagic(v,data,config, MAGIC_TYPE.AT_PLAYER,(i - 2)*10)
			Routine.wait(0.3)
		end

		data.animation = "lowerWand"

		-- just sitting here
		teleport(v,data,config, getCentre(v),b.top + FLOOR_HEIGHT - 64,DIR_LEFT)
		Routine.wait(0.3)

		doTalkThing(v,data,config)
		Routine.wait(0.2)
	end
end)

stateRoutines[STATE.PHASE_2] = (function(v,data,config)
	local b = v.sectionObj.boundary

	doNewPhaseThing(v,data,config)

	shootSpawningMagic(v,data,config, kamekController.ludwigID,0)

	Routine.wait(3)


	while (true) do
		for _,direction in ipairs{DIR_LEFT,DIR_RIGHT} do
			local exists = npcIDExists(kamekController.ludwigID)

			if exists then
				teleport(v,data,config, getCentre(v) - DISTANCE_FROM_CENTRE*direction,b.top + FLOOR_HEIGHT - 80,direction)
				Routine.wait(2)
			else
				teleport(v,data,config, getCentre(v) - DISTANCE_FROM_CENTRE*direction,b.top + FLOOR_HEIGHT - 48,direction)

				for i = 1,3 do
					shootMagic(v,data,config, MAGIC_TYPE.AT_PLAYER,0,4.5)
					Routine.wait(0.2)
				end

				Routine.wait(1.1)
			end

			data.animation = "lowerWand"
		end
	end
end)

stateRoutines[STATE.PHASE_3] = (function(v,data,config)
	local b = v.sectionObj.boundary

	doNewPhaseThing(v,data,config)
	data.animation = "idle"
	data.floatActive = true

	for j = 1,2 do
		teleport(v,data,config, getCentre(v) + DISTANCE_FROM_CENTRE*v.direction,b.top + FLOOR_HEIGHT - 64,-v.direction)
		Routine.wait(0.2)

		for i = 1,8 do
			shootMagic(v,data,config, MAGIC_TYPE.DIRECT,(i - 4.5) * 15)
			Routine.wait(0.1)
		end

		Routine.wait(0.2)
		data.animation = "lowerWand"
	end

	while (true) do
		teleport(v,data,config, getCentre(v),b.top + 128,-v.direction)
		Routine.wait(0.3)

		npcutils.faceNearestPlayer(v)

		for i = 1,14 do
			shootMagic(v,data,config, MAGIC_TYPE.AT_PLAYER,0)
			Routine.wait(0.1)
		end

		Routine.wait(0.4)
		data.animation = "lowerWand"

		npcutils.faceNearestPlayer(v)

		doNewPhaseThing(v,data,config)
		Routine.wait(0.5)

		data.floatActive = false

		do
			SFX.play(flyInSound)
			data.animation = "fly"

			v.direction = -v.direction

			v.x = getCentre(v) - 848*v.direction
			v.y = player.y + player.height*0.5 - v.height*0.5 - 16
			v.speedX = 10 * v.direction

			while (math.sign((player.x + player.width*0.5) - (v.x + v.width*0.5)) == v.direction) do
				Routine.skip()
			end

			while (v.speedX ~= 0) do
				local deceleration

				if math.abs(v.speedX) > 4 then
					data.animation = "stop"
					data.shake = 1
					deceleration = 0.2
				else
					data.animation = "REALLYStop"
					data.shake = 0
					deceleration = 0.3
				end

				if v.speedX > 0 then
					v.speedX = math.max(0,v.speedX - deceleration)
				elseif v.speedX < 0 then
					v.speedX = math.min(0,v.speedX + deceleration)
				end
		
				Routine.skip()
			end

			Routine.wait(0.2)

			v.direction = -v.direction
			Routine.wait(0.3)
		end

		do
			local speed = vector((player.x + player.width*0.5) - (v.x + v.width*0.5),(player.y + player.height*0.5 - 16) - (v.y + v.height*0.5)):normalise() * 8

			v.speedX = speed.x
			v.speedY = speed.y
			v.direction = math.sign(v.speedX)

			data.animation = "fly"

			SFX.play(flyInSound)

			while (v.x+v.width > b.left and v.x < b.right and v.y+v.height > b.top and v.y < b.bottom) do
				Routine.skip()
			end

			Routine.wait(1)

			data.animation = "idle"
			data.floatActive = true
		end
	end
end)

stateRoutines[STATE.PHASE_4] = (function(v,data,config)
	local b = v.sectionObj.boundary

	doNewPhaseThing(v,data,config)

	shootSpawningMagic(v,data,config, kamekController.iggyID,0)

	rotatingPlatformActive = true


	Routine.wait(1.5)

	teleport(v,data,config, getCentre(v) - DISTANCE_FROM_CENTRE,b.top + FLOOR_HEIGHT - 256,1)

	while (npcIDExists(kamekController.iggyID)) do
		Routine.skip()
	end

	Routine.wait(1)

	rotatingPlatformRetracting = true

	doTalkThing(v,data,config)

	while (true) do
		for _,direction in ipairs{DIR_LEFT,DIR_RIGHT} do
			teleport(v,data,config, getCentre(v) - DISTANCE_FROM_CENTRE*direction,b.top + FLOOR_HEIGHT - 64,direction)

			for i = 1,3 do
				shootMagic(v,data,config, MAGIC_TYPE.DIRECT,(i - 2)*20)
				Routine.wait(0.2)
			end

			data.animation = "lowerWand"

			Routine.wait(3)
		end
	end
end)


stateRoutines[STATE.END] = (function(v,data,config)
	local b = v.sectionObj.boundary

	data.shake = 1

	data.frame = 3
	data.animation = "talk"

	v.sectionObj.music = 0

	Misc.pause(true)

	for i = 1,3 do
		table.insert(defeatEffects,{
			x = v.x + v.width*0.5,
			y = v.y + v.height*0.5,

			timer = 0,
			radius = 0,
			opacity = 1,
		})

		SFX.play(defeatEffectSound)

		Routine.wait(1.3,true)
	end

	Routine.wait(0.7,true)

	Misc.unpause()


	while (not player:isOnGround()) do
		Routine.skip()
	end
	playerInputDisabled = true


	data.floatActive = false
	SFX.play(flyAwaySound)


	local rotation = 295
	local i = 1

	while (i <= 96) do
		local speed = vector(0,-i*0.3):rotate(rotation)

		v.speedX = speed.x
		v.speedY = speed.y

		v.direction = math.sign(speed.x)

		rotation = math.max(80,rotation - i*0.15)

		i = i + 1

		Routine.skip()
	end

	v.x = b.right
	v.y = b.top + FLOOR_HEIGHT - 48
	v.direction = DIR_LEFT

	data.shake = 0.75
	data.animation = "tiny"

	v.speedX = -8 * 0.3
	v.speedY = -2 * 0.3


	Routine.wait(1)

	playerFrameX,playerFrameY = 2,3

	Routine.wait(3)

	playerFrameX,playerFrameY = nil,nil

	Routine.wait(3)

	

	SFX.play(endFanfareSound)

	local direction
	if player.x+player.width*0.5 > getCentre(v) then
		direction = 1
	else
		direction = -1
	end

	local goalX = getCentre(v) + direction*16

	while (true) do
		local distance = (goalX - (player.x + player.width*0.5))

		if math.abs(distance) <= 2 then
			playerForceHoldButtons = {"up"}

			player.speedX = 0
			player.direction = -direction
			
			break
		end

		if distance < 0 then
			playerForceHoldButtons = {"left"}
		else
			playerForceHoldButtons = {"right"}
		end

		Routine.skip()
	end


	veryCoolEgg = NPC.spawn(154,getCentre(v),b.top - 64,v.section,false,true)
	veryCoolEgg.speedY = 1.5

	Routine.wait(0.4)

	for i = 1,2 do
		playerForceHoldButtons = {"jump"}
		Routine.waitFrames(20)
		playerForceHoldButtons = {"up"}

		while (not player:isOnGround()) do
			Routine.skip()
		end
		
		Routine.wait(0.1)
	end

	Routine.wait(0.2)

	playerForceHoldButtons = {"jump"}

	while (player.y > veryCoolEgg.y+veryCoolEgg.height or not veryCoolEgg.isValid) do
		Routine.skip()
	end

	Misc.pause(true)

	SFX.play(91)

	while (wipeProgress < 1) do
		wipeProgress = math.min(1,wipeProgress + 0.005)
		Routine.skip(true)
	end

	Routine.wait(7.5,true)

	while (finalFadeOut < 1) do
		finalFadeOut = math.min(1,finalFadeOut + 0.01)
		Routine.skip(true)
	end

	GameData.inCreditsMode = true
	Level.load(levels.names.yoshisHouse)
	Level.exit(LEVEL_WIN_TYPE_SMB3ORB)
	Misc.unpause()
end)




function kamek.onInitAPI()
	npcManager.registerEvent(npcID, kamek, "onTickNPC")
	npcManager.registerEvent(npcID, kamek, "onDrawNPC")

	registerEvent(kamek,"onTick")
	registerEvent(kamek,"onTickEnd")
	registerEvent(kamek,"onDraw")

	registerEvent(kamek,"onNPCHarm")
	registerEvent(kamek,"onPostNPCKill")

	registerEvent(kamek,"onReset")
end


function kamek.onTickNPC(v)
	local data = v.data
	
	if v.despawnTimer <= 0 then
		data.initialized = false
		return
	end

	if player.section ~= v.section then
		return
	end

	local config = NPC.config[v.id]

	if not data.initialized then
		data.initialized = true

		data.animation = "invisible"

		data.currentAnimation = data.animation
		data.animationTimer = 0
		data.frameIndex = 1

		data.frame = -1

		data.palette = 0
		data.teleportFade = 0
		data.isInvincible = true

		data.shake = 0

		data.scale = 1


		data.hits = 0
		data.phase = DEBUG_START_PHASE


		data.floatActive = false
		data.floatTimer = 0


		data.cardboardX = nil
		data.cardboardY = nil
		data.cardboardAngle = nil
		data.cardboardShadow = nil

		setState(v,data,config,STATE.INTRO)
	end

	local isFrozen = Defines.levelFreeze

	if data.stateRoutine ~= nil and data.stateRoutine.isValid then
		if isFrozen then
			data.stateRoutine:pause()
		else
			data.stateRoutine:resume()
		end
	end

	if not isFrozen then
		if data.palette > 0 and lunatime.tick()%6 == 0 then
			data.palette = (data.palette % 15) + 1
		end

		if data.floatActive then
			v.speedY = math.cos(data.floatTimer / 32) * 0.3
			data.floatTimer = data.floatTimer + 1
		else
			data.floatTimer = 0
		end

		v.friendly = (data.teleportFade > 0 or data.state == STATE.END)

		handleAnimation(v,data,config)
	end
end


local scalingBuffer = Graphics.CaptureBuffer(64,64)

local RENDER_SCALE = 0.5

local mainShader = Shader()
mainShader:compileFromFile(nil, folderName.. "main.frag")

function kamek.onDrawNPC(v)
	if v.despawnTimer <= 0 or v.isHidden then return end

	local data = v.data

	if not data.initialized then return end

	local config = NPC.config[v.id]

	if data.cardboardX ~= nil then
		-- Cardboard fake
		local frameHeight = (cardboardImage.height / cardboardFrames)
		local frontHeight = math.cos(math.rad(data.cardboardAngle)) * frameHeight
		local sideHeight  = math.sin(math.rad(data.cardboardAngle)) * frameHeight

		Graphics.drawBox{
			texture = cardboardImage,sceneCoords = true,priority = -66,
			sourceHeight = frameHeight,height = frontHeight,sourceY = (data.cardboardShadow and 2*frameHeight) or 0,
			x = data.cardboardX - cardboardImage.width*0.5,y = data.cardboardY - frontHeight + 4,
		}

		--[[Graphics.drawBox{
			texture = cardboardImage,sceneCoords = true,priority = -66,
			sourceHeight = frameHeight,height = sideHeight,sourceY = frameHeight,
			x = data.cardboardX - cardboardImage.width*0.5,y = data.cardboardY - frontHeight - sideHeight*0.5,
		}]]
	end


	if data.frame <= 0 or data.teleportFade >= 1 then
		return
	end


	if data.sprite == nil then
		data.sprite = Sprite{texture = mainImage,frames = config.frames,pivot = Sprite.align.CENTRE}
	end

	local priority = -44
	if data.animation == "tiny" then
		priority = -95.1
	end

	
	local noiseTexture = Graphics.sprites.hardcoded["53-0"].img


	scalingBuffer:clear(priority)
	--Graphics.drawBox{target = scalingBuffer,x = 0,y = 0,width = scalingBuffer.width,height = scalingBuffer.height,priority = priority,color = Color.purple}

	data.sprite.x = scalingBuffer.width * 0.5
	data.sprite.y = scalingBuffer.height * 0.5
	data.sprite.scale = vector(RENDER_SCALE * data.scale,RENDER_SCALE * data.scale)

	data.sprite:draw{frame = data.frame,priority = priority,target = scalingBuffer,shader = mainShader,uniforms = {
		noiseTexture = noiseTexture,
		noiseSize = vector(noiseTexture.width,noiseTexture.height),
		teleportFade = data.teleportFade,

		imageSize = vector(mainImage.width,mainImage.height),
		frames = vector(1,data.sprite.frames),
	}}


	local shader,uniforms = paletteChange.getShaderAndUniforms(data.palette,folderName.. "palette.png")

	Graphics.drawBox{
		texture = scalingBuffer,centred = true,sceneCoords = true,priority = priority,
		x = v.x + v.width*0.5 + config.gfxoffsetx,
		y = v.y + v.height - (mainImage.height / config.frames)*0.5 + config.gfxoffsety + ((lunatime.tick() % 2) - 0.5)*2*data.shake,
		width = (scalingBuffer.width / RENDER_SCALE) * -v.direction,height = scalingBuffer.height / RENDER_SCALE,
		sourceWidth = scalingBuffer.width,sourceHeight = scalingBuffer.height,
		shader = shader,uniforms = uniforms,
	}


	--data.sprite.x = v.x + v.width*0.5 + config.gfxoffsetx
	--data.sprite.y = v.y + v.height - (mainImage.height / config.frames)*0.5 + config.gfxoffsety + ((lunatime.tick() % 2) - 0.5)*2*data.shake

	--data.sprite:draw{frame = data.frame,priority = -44,sceneCoords = true,shader = shader,uniforms = uniforms}
end


local function applyPlatformRotation(o,centre,base)
	local offset = vector((o.x + o.width*0.5) - centre,(o.y + o.height) - base):rotate(rotatingPlatformRotation - rotatingPlatformOldRotation)

	o.x = centre + offset.x - o.width*0.5
	o.y = base + offset.y - o.height

	if type(o) == "NPC" then
		for _,p in ipairs(Player.get()) do
			if p.standingNPC == o then
				applyPlatformRotation(p,centre,base)
			end
		end
	end

	if DEBUG_SHOW_ROTATING then
		Graphics.drawBox{x = o.x + o.width*0.5 - 4,y = o.y + o.height - 4,width = 8,height = 8,color = Color.blue,sceneCoords = true}
	end
end


function kamek.onTick()
	if playerInputDisabled then
		for k,_ in pairs(player.keys) do
			player.keys[k] = false
		end

		for _,name in ipairs(playerForceHoldButtons) do
			player.keys[name] = true
		end
	end

	for i = #magicEffects, 1, -1 do
		local effect = magicEffects[i]

		effect.timer = effect.timer + 1

		if effect.timer > 256 then
			table.remove(magicEffects,i)
		end
	end

	-- Rotating platform
	local originalLayer = Layer.get("boss - rotating")
	local pinkLayer = Layer.get("boss - extra pink")

	if rotatingPlatformActive then
		local b = player.sectionObj.boundary

		if not originalLayer.isHidden then
			originalLayer:hide(true)
		end
		if pinkLayer.isHidden then
			pinkLayer:show(true)
		end


		if not Layer.isPaused() then
			if rotatingPlatformRetracting then
				if rotatingPlatformRotation > 0 then
					rotatingPlatformRotation = math.max(0,rotatingPlatformRotation - 0.3)
				elseif rotatingPlatformRotation < 0 then
					rotatingPlatformRotation = math.min(0,rotatingPlatformRotation + 0.3)
				elseif rotatingPlatformYOffset ~= 0 then
					rotatingPlatformYOffset = math.min(0,rotatingPlatformYOffset + 1)
				else
					rotatingPlatformActive = false
				end
			elseif rotatingPlatformDirection == 0 then
				rotatingPlatformYOffset = math.max(ROTATINGPLAT_Y_OFFSET,rotatingPlatformYOffset - 1)

				if rotatingPlatformYOffset <= ROTATINGPLAT_Y_OFFSET then
					rotatingPlatformDirection = -1
					rotatingPlatformTimer = 24
				end
			elseif rotatingPlatformTimer > 0 then
				rotatingPlatformTimer = rotatingPlatformTimer - 1
			else
				rotatingPlatformRotation = rotatingPlatformRotation + 0.2*rotatingPlatformDirection

				if rotatingPlatformRotation*rotatingPlatformDirection >= ROTATINGPLAT_MAXROTATION then
					rotatingPlatformRotation = ROTATINGPLAT_MAXROTATION * rotatingPlatformDirection
					rotatingPlatformDirection = -rotatingPlatformDirection
					rotatingPlatformTimer = 24
				end
			end
		end


		-- Create collision
		local isNewBlock = (rotatingPlatformSlope == nil or not rotatingPlatformSlope.isValid)

		if isNewBlock then
			rotatingPlatformSlope = Block.spawn(1,0,0)
		end

		if rotatingPlatformSecondaryBlock == nil or not rotatingPlatformSecondaryBlock.isValid then
			rotatingPlatformSecondaryBlock = Block.spawn(1,0,0)
		end


		local block = rotatingPlatformSlope
		local secondaryBlock = rotatingPlatformSecondaryBlock

		local centre = (b.right + b.left) * 0.5
		local base = b.top + ROTATINGPLAT_START_Y + rotatingPlatformYOffset + ROTATINGPLAT_HEIGHT

		local left  = vector(-ROTATINGPLAT_WIDTH*0.5,-ROTATINGPLAT_HEIGHT):rotate(rotatingPlatformRotation)
		local right = vector( ROTATINGPLAT_WIDTH*0.5,-ROTATINGPLAT_HEIGHT):rotate(rotatingPlatformRotation)

		local minX = math.min(left.x,right.x)
		local minY = math.min(left.y,right.y)
		local maxX = math.max(left.x,right.x)
		local maxY = math.max(left.y,right.y)

		local x = minX + centre
		local y = minY + base
		local width = maxX - minX
		local height = maxY - minY

		local id

		if left.y > right.y then
			id = 341
		elseif left.y < right.y then
			id = 343
		else
			id = 1006
			height = ROTATINGPLAT_HEIGHT
		end


		if left.y == right.y and not isNewBlock and rotatingPlatformOldRotation == 0 then
			block.speedX = x - block.x
			block.speedY = y - block.y
		else
			block.speedX,block.speedY = 0,0
		end



		block.id = id
		block.width = width
		block.height = height
		block:translate(x - block.x,y - block.y)


		local secondaryX = block.x
		local secondaryY = block.y + block.height
		local secondaryWidth = block.width
		local secondaryHeight = ROTATINGPLAT_HEIGHT - block.height

		secondaryBlock.speedX = secondaryX - secondaryBlock.x
		secondaryBlock.speedY = secondaryY - secondaryBlock.y

		secondaryBlock.width = secondaryWidth
		secondaryBlock.height = secondaryHeight

		secondaryBlock.id = 1006

		secondaryBlock:translate(secondaryBlock.speedX,secondaryBlock.speedY)


		-- Move players/NPC's on it
		if left.y ~= right.y then
			for _,p in ipairs(Player.get()) do
				if p:mem(0x48,FIELD_WORD) == rotatingPlatformSlope.idx then
					applyPlatformRotation(p,centre,base)
				end
			end

			for _,npc in NPC.iterate(-1,Section.getActiveIndices()) do
				if npc:mem(0x22,FIELD_WORD) == rotatingPlatformSlope.idx and npc:mem(0x12C,FIELD_WORD) == 0 then
					applyPlatformRotation(npc,centre,base)
				end
			end
		end

		rotatingPlatformOldRotation = rotatingPlatformRotation

		
		if DEBUG_SHOW_ROTATING then
			local config = Block.config[block.id]

			if config.floorslope < 0 then
				Graphics.glDraw{
					vertexCoords = {
						block.x + block.width,block.y,
						block.x,block.y + block.height,
						block.x + block.width,block.y + block.height,
					},
					color = Color.green.. 0.5,sceneCoords = true,
				}
			elseif config.floorslope > 0 then
				Graphics.glDraw{
					vertexCoords = {
						block.x,block.y,
						block.x + block.width,block.y + block.height,
						block.x,block.y + block.height,
					},
					color = Color.red.. 0.5,sceneCoords = true,
				}
			else
				Graphics.drawBox{x = block.x,y = block.y,width = block.width,height = block.height,color = Color.blue.. 0.5,sceneCoords = true}
			end

			Graphics.drawBox{x = secondaryBlock.x,y = secondaryBlock.y,width = secondaryBlock.width,height = secondaryBlock.height,color = Color.blue.. 0.5,sceneCoords = true}

			Text.print(rotatingPlatformRotation,32,96)
		end
	else
		if originalLayer.isHidden then
			originalLayer:show(true)
		end
		if not pinkLayer.isHidden then
			pinkLayer:hide(true)
		end
	end
end


function kamek.onTickEnd()
	if playerFrameY ~= nil then
		extendedPlayerStuff.customFrameX = playerFrameX
		extendedPlayerStuff.customFrameY = playerFrameY
	end
end


local magicEffectShader = Shader()
magicEffectShader:compileFromFile(nil, folderName.. "magic.frag")

local wipeShader = Shader()
wipeShader:compileFromFile(nil, folderName.. "wipe.frag")

function kamek.onDraw()
	if lightningOpacity > 0 then
		Graphics.drawScreen{color = Color.white.. lightningOpacity}
	end

	for _,effect in ipairs(magicEffects) do
		local image = magicEffectImage

		Graphics.drawBox{
			texture = image,sceneCoords = true,priority = -4,
			color = Color.fromHSV((lunatime.tick()/224) % 1,0.8,0.9),
			x = effect.x - image.width*0.5,y = effect.y - 96,
			height = image.height*2,sourceHeight = image.height,sourceY = 0,
			shader = magicEffectShader,uniforms = {
				imageSize = vector(image.width,image.height),
				time = effect.timer,
			},
		}
	end

	for i = #defeatEffects, 1, -1 do
		local effect = defeatEffects[i]

		if effect.emitter == nil then
			effect.emitter = Particles.Emitter(effect.x,effect.y,Misc.resolveFile("bigBadBoss/defeatParticle.ini"))
			effect.emitter.enabled = false

			effect.emitter:emit(25)

			local particles = effect.emitter.particles

			for index,particle in ipairs(particles) do
				local speed = vector(0,-9):rotate((index-1) / (#particles) * 360)

				particle.initSpeedX = speed.x
				particle.initSpeedY = speed.y
			end
		end

		effect.timer = effect.timer + 1

		effect.radius = effect.radius + (68 - effect.timer) * 0.2
		effect.opacity = math.clamp((68 - effect.timer) / 24)

		if effect.opacity > 0 then
			local color = Color.fromHSV((lunatime.drawtick()/224) % 1,0.8,0.9).. (effect.opacity * 0.5)

			Graphics.drawCircle{
				x = effect.x,y = effect.y,radius = effect.radius,priority = -4,sceneCoords = true,color = color,
			}
		end

		effect.emitter:Draw(-4,true,nil,true,nil,nil,true)


		if effect.opacity == 0 and effect.emitter:Count() == 0 then
			table.remove(defeatEffects,i)
		end
	end


	-- Rotating platform
	if rotatingPlatformActive then
		if rotatingPlatformSprite == nil then
			rotatingPlatformSprite = Sprite{texture = rotatingPlatformImage,pivot = Sprite.align.BOTTOM}
		end

		local sprite = rotatingPlatformSprite

		local b = player.sectionObj.boundary

		sprite.x = (b.left + b.right) * 0.5
		sprite.y = b.top + ROTATINGPLAT_START_Y + rotatingPlatformYOffset + ROTATINGPLAT_HEIGHT

		sprite.rotation = rotatingPlatformRotation

		sprite:draw{priority = -66,sceneCoords = true}
	end

	if wipeProgress > 0 then
		Graphics.drawScreen{
            priority = 0.1,shader = wipeShader,uniforms = {
                transitionTexture = wipeImage,
                progress = wipeProgress,
            },
        }

		if veryCoolEgg ~= nil and veryCoolEgg.isValid then
			npcutils.drawNPC(veryCoolEgg,{priority = 0.1})
		end

		player:render{priority = 0.1,ignorestate = true}
	end

	if finalFadeOut > 0 then
		Graphics.drawScreen{priority = 10,color = Color.black.. finalFadeOut}
	end
end


function kamek.onNPCHarm(eventObj,v,reason,culprit)
	if v.id ~= npcID or reason == HARM_TYPE_VANISH then return end

	local config = NPC.config[v.id]
	local data = v.data

	eventObj.cancelled = true

	if config.jumphurt then
		return
	end

	local fromFireball = (reason == HARM_TYPE_NPC and type(culprit) == "NPC" and culprit.id == 13)
	local fromHammer = (reason == HARM_TYPE_NPC and type(culprit) == "NPC" and culprit.id == 171)

	if (reason == HARM_TYPE_JUMP or reason == HARM_TYPE_SPINJUMP) and type(culprit) == "Player" then
		if culprit.x+culprit.width*0.5 < v.x+v.width*0.5 then
			culprit.speedX = -4.5
		else
			culprit.speedX = 4.5
		end
	end

	if fromHammer then
		culprit.speedX = math.sign((culprit.x + culprit.width*0.5) - (v.x + v.width*0.5)) * 8
		culprit.speedY = -3
	end


	local damage = 0

	if not data.isInvincible then
		if fromFireball then
			damage = 0.3
		elseif fromHammer then
			damage = 0.75
		else
			damage = 1
		end
	end

	if fromFireball then
		SFX.play(9)
	else
		SFX.play(39)
	end

	data.hits = data.hits + damage

	if data.hits >= phaseData[data.phase].health and damage > 0 then
		data.shake = 0

		clearNPCs()

		if data.phase < #phaseData then
			data.phase = data.phase + 1
			data.hits = 0
			
			setState(v,data,config, phaseData[data.phase].state)
		else
			data.isInvincible = true
			setState(v,data,config, STATE.END)

			if (reason == HARM_TYPE_JUMP or reason == HARM_TYPE_SPINJUMP) and type(culprit) == "Player" then
				if culprit.x+culprit.width*0.5 > getCentre(v) then
					culprit.speedX = -8
				else
					culprit.speedX = 8
				end
			end
		end
	end
end


function kamek.onPostNPCKill(v,reason)
	if v.id == npcID then
		stopRoutine(v,v.data)
	end
end


function kamek.onReset(fromRespawn)
	rotatingPlatformActive = false
	rotatingPlatformRotation = 0
	rotatingPlatformOldRotation = 0
	rotatingPlatformTimer = 0
	rotatingPlatformDirection = 0
	rotatingPlatformYOffset = 0
	rotatingPlatformRetracting = false

	if rotatingPlatformSlope ~= nil and rotatingPlatformSlope.isValid then
		rotatingPlatformSlope:delete()
	end
	if rotatingPlatformSecondaryBlock ~= nil and rotatingPlatformSecondaryBlock.isValid then
		rotatingPlatformSecondaryBlock:delete()
	end

	playerInputDisabled = false
	playerForceHoldButtons = {}

	playerFrameX,playerFrameY = nil,nil
end


return kamek