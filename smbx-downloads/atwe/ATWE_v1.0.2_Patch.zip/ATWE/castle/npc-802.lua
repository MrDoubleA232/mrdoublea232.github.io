local npcManager = require("npcManager")
local npcutils = require("npcs/npcutils")

local kamekController = require("bigBadBoss/controller")


local magic = {}
local npcID = NPC_ID

local effectID = (npcID - 1)

kamekController.magicID = npcID

local magicSettings = {
	id = npcID,
	
	gfxwidth = 32,
	gfxheight = 32,

	gfxoffsetx = 0,
	gfxoffsety = 8,
	
	width = 24,
	height = 24,
	
	frames = 12,
	framestyle = 0,
	framespeed = 2,
	
	speed = 1,
	
	npcblock = false,
	npcblocktop = false, --Misnomer, affects whether thrown NPCs bounce off the NPC.
	playerblock = false,
	playerblocktop = false, --Also handles other NPCs walking atop this NPC.

	nohurt = false,
	nogravity = true,
	noblockcollision = true,
	nofireball = true,
	noiceball = true,
	noyoshi = true,
	nowaterphysics = true,
	
	jumphurt = true,
	spinjumpsafe = true,
	harmlessgrab = false,
	harmlessthrown = false,
}

npcManager.setNpcSettings(magicSettings)
npcManager.registerHarmTypes(npcID,
	{
		--HARM_TYPE_JUMP,
		--HARM_TYPE_FROMBELOW,
		--HARM_TYPE_NPC,
		--HARM_TYPE_PROJECTILE_USED,
		--HARM_TYPE_LAVA,
		--HARM_TYPE_HELD,
		--HARM_TYPE_TAIL,
		--HARM_TYPE_SPINJUMP,
		--HARM_TYPE_OFFSCREEN,
		--HARM_TYPE_SWORD
	},
	{
		--[HARM_TYPE_JUMP]            = 10,
		--[HARM_TYPE_FROMBELOW]       = 10,
		--[HARM_TYPE_NPC]             = 10,
		--[HARM_TYPE_PROJECTILE_USED] = 10,
		--[HARM_TYPE_LAVA]            = {id=13, xoffset=0.5, xoffsetBack = 0, yoffset=1, yoffsetBack = 1.5},
		--[HARM_TYPE_HELD]            = 10,
		--[HARM_TYPE_TAIL]            = 10,
		--[HARM_TYPE_SPINJUMP]        = 10,
		--[HARM_TYPE_OFFSCREEN]       = 10,
		--[HARM_TYPE_SWORD]           = 10,
	}
)


local spawnedEffects = {}

function magic.onInitAPI()
	npcManager.registerEvent(npcID, magic, "onTickEndNPC")
	npcManager.registerEvent(npcID, magic, "onDrawNPC")

	registerEvent(magic, "onTick")
end

function magic.onTickEndNPC(v)
	if Defines.levelFreeze then return end
	
	local data = v.data
	
	if v.despawnTimer <= 0 then
		data.initialized = false
		return
	end

	local config = NPC.config[v.id]

	if not data.initialized then
		data.initialized = true

		data.timer = 0

		data.hasBeenShot = false

		data.reachedGoal = false
	end


	-- Scaling
	local newWidth = config.width * data.scale
	local newHeight = config.height * data.scale

	if math.floor(v.width + 0.5) ~= newWidth or math.floor(v.height + 0.5) ~= newHeight then
		v.x = v.x + v.width*0.5 - newWidth*0.5
		v.width = newWidth

		v.y = v.y + v.height*0.5 - newHeight*0.5
		v.height = newHeight
	end


	if not data.timerPaused then
		data.timer = data.timer + 1
	end
	
	if data.timer < 16 then
		if data.parent ~= nil and data.parent.isValid then
			v.x = data.parent.x + data.parent.width*0.5 + data.offsetX*data.parent.direction - v.width*0.5
			v.y = data.parent.y + data.parent.height + data.offsetY - v.height*0.5
			v.direction = data.parent.direction
		end

		v.friendly = true
	elseif data.timer == 16 then
		local speed

		if data.type == kamekController.MAGIC_TYPE.AT_PLAYER then
			speed = vector((player.x + player.width*0.5) - (v.x + v.width*0.5),(player.y + player.height*0.5) - (v.y + v.height*0.5)):normalise()
		elseif data.type == kamekController.MAGIC_TYPE.SPAWNER and (data.goalX ~= nil and data.goalY ~= nil) then
			speed = vector(data.goalX - (v.x + v.width*0.5),data.goalY - (v.y + v.height*0.5)):normalise()
		else
			speed = vector(v.direction,0)
		end

		speed = speed:rotate(data.angleOffset * v.direction) * data.speed

		v.speedX = speed.x
		v.speedY = speed.y
		
		v.friendly = false

		data.hasBeenShot = true

		SFX.play(18,0.75)
	else
		if data.timer%8 == 0 then
			local e = Effect.spawn(effectID,v.x + v.width*0.5,v.y + v.height*0.5)

			e.width  = e.width  * data.scale
			e.height = e.height * data.scale

			e.x = e.x - e.width *0.5
			e.y = e.y - e.height*0.5

			table.insert(spawnedEffects,e)
		end

		if data.type == kamekController.MAGIC_TYPE.SPAWNER and (data.goalX ~= nil and data.goalY ~= nil and data.spawnID ~= nil) then
			if  math.abs(data.goalX - (v.x + v.width *0.5)) <= math.abs(v.speedX)+4
			and math.abs(data.goalY - (v.y + v.height*0.5)) <= math.abs(v.speedY)+4
			then
				v.x = data.goalX - v.width*0.5
				v.y = data.goalY - v.height*0.5
				v.speedX = 0
				v.speedY = 0

				local npc = NPC.spawn(data.spawnID,v.x + v.width*0.5,v.y + v.height - NPC.config[data.spawnID].height*0.5, v.section, false,true)

				npc.direction = v.direction

				local e = Effect.spawn(952,v.x + v.width*0.5,v.y + v.height*0.5)

				e.width  = e.width  * data.scale
				e.height = e.height * data.scale

				e.x = e.x - e.width *0.5
				e.y = e.y - e.height*0.5

				table.insert(spawnedEffects,e)

				v:kill(HARM_TYPE_VANISH)
			end
		end
	end

	v.animationFrame = npcutils.getFrameByFramestyle(v,{frame = math.floor(lunatime.tick() / config.framespeed) % config.frames})

	if v.x+v.width < camera.x or v.x > camera.x+camera.width or v.y+v.height < camera.y or v.y > camera.y+camera.height then
		v:kill(HARM_TYPE_VANISH)
	end

	--Colliders.Box(v.x,v.y,v.width,v.height):Draw()
end

function magic.onDrawNPC(v)
	if v.despawnTimer <= 0 or v.isHidden then return end

	local config = NPC.config[v.id]
	local data = v.data

	if data.sprite == nil then
		data.sprite = Sprite{texture = Graphics.sprites.npc[v.id].img,frames = npcutils.getTotalFramesByFramestyle(v),pivot = Sprite.align.CENTRE}
	end

	data.sprite.scale = vector(data.scale,data.scale)

	data.sprite.x = v.x + v.width*0.5
	data.sprite.y = v.y + v.height*0.5

	data.sprite:draw{frame = v.animationFrame+1,priority = -15,sceneCoords = true}

	npcutils.hideNPC(v)
end


function magic.onTick()
	for i = #spawnedEffects, 1, -1 do
		local spawner = spawnedEffects[i]
		local effects = spawner.effects

		if effects[1] ~= nil then
			local canRemove = true

			for _,e in ipairs(spawner.effects) do
				if e.timer > 0 then
					canRemove = false
					break
				end
			end

			if canRemove then
				spawner:kill()
			end
		end
	end
end


return magic