local npcManager = require("npcManager")
local npcutils = require("npcs/npcutils")

local bouncy = {}
local npcID = NPC_ID

local bouncySettings = {
	id = npcID,
	
	gfxwidth = 32,
	gfxheight = 32,

	gfxoffsetx = 0,
	gfxoffsety = 0,
	
	width = 32,
	height = 32,
	
	frames = 3,
	framestyle = 0,
	framespeed = 8,
	
	speed = 1.5,
	
	npcblock = false,
	npcblocktop = false, --Misnomer, affects whether thrown NPCs bounce off the NPC.
	playerblock = false,
	playerblocktop = false, --Also handles other NPCs walking atop this NPC.

	nohurt = true,
	nogravity = false,
	noblockcollision = false,
	nofireball = true,
	noiceball = true,
	noyoshi = true,
	nowaterphysics = false,
	
	jumphurt = true,
	spinjumpsafe = false,
	harmlessgrab = false,
	harmlessthrown = false,

	luahandlesspeed = true,
	staticdirection = true,
}

npcManager.setNpcSettings(bouncySettings)
npcManager.registerHarmTypes(npcID,
	{
		HARM_TYPE_NPC,
		HARM_TYPE_LAVA,
	},
	{
		[HARM_TYPE_NPC] = 10,
		[HARM_TYPE_LAVA] = {id=13, xoffset=0.5, xoffsetBack = 0, yoffset=1, yoffsetBack = 1.5},
	}
)


function bouncy.onInitAPI()
	npcManager.registerEvent(npcID, bouncy, "onTickEndNPC")
end

function bouncy.onTickEndNPC(v)
	if Defines.levelFreeze then return end
	
	local data = v.data
	
	if v.despawnTimer <= 0 then
		data.initialized = false
		return
	end

	
	local config = NPC.config[v.id]

	if not data.initialized then
		data.initialized = true

		data.bounceTimer = 0

		data.animationTimer = 0
	end

	
	local useBounceFrame = false


	if v.collidesBlockBottom then
		data.bounceTimer = data.bounceTimer + 1

		useBounceFrame = true

		if data.bounceTimer >= 1 then
			if v:mem(0x22,FIELD_WORD) > 0 then
				local slopeBlock = Block(v:mem(0x22,FIELD_WORD))
				local slopeDirection = Block.config[slopeBlock.id].floorslope
	
				v.speedX = v.speedX + (slopeDirection * (slopeBlock.height / slopeBlock.width))*3
			end
			
			v.speedY = -1.5
		end
	end


	-- Hit the player
	for _,p in ipairs(Player.getIntersecting(v.x,v.y,v.x + v.width,v.y + v.height)) do
		if p.forcedState == FORCEDSTATE_NONE and p.deathTimer == 0 then
			local distance = vector((player.x + player.width*0.5) - (v.x + v.width*0.5),(player.y + player.height*0.5) - (v.y + v.height*0.5))

			p.speedX = (distance.x / v.width ) * 8
			p.speedY = (distance.y / v.height) * 4

			useBounceFrame = true

			SFX.play(24)
		end
	end


	local frame = 0

	if useBounceFrame then
		frame = config.frames - 1
		data.animationTimer = 0
	else
		frame = math.floor(data.animationTimer / config.framespeed) % (config.frames - 1)
		data.animationTimer = data.animationTimer + 1
	end

	v.animationFrame = npcutils.getFrameByFramestyle(v,{frame = frame})

	v:mem(0x120,FIELD_BOOL,false)
end


return bouncy