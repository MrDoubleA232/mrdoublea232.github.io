local smwMap = require("smwMap")

-- Force the SMW costumes, 'cause why not
Player.setCostume(CHARACTER_MARIO,"SMW-Mario",true)
Player.setCostume(CHARACTER_LUIGI,"SMW-Luigi",true)