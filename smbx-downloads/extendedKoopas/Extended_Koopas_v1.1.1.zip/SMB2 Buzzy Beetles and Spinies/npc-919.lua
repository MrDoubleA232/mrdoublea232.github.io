--[[

	Extended Koopas
	Made by MrDoubleA

	See extendedKoopas.lua for full credits

]]

local npcManager = require("npcManager")
local npcutils = require("npcs/npcutils")

local spinyEgg = {}
local npcID = NPC_ID


local transformID = (npcID - 3)
local deathEffectID = (npcID - 5)


local spinyEggSettings = {
	id = npcID,
	
	gfxwidth = 32,
	gfxheight = 32,

	gfxoffsetx = 0,
	gfxoffsety = 0,
	
	width = 32,
	height = 24,
	
	frames = 2,
	framestyle = 0,
	framespeed = 8,
	
	speed = 1,
	
	npcblock = false,
	npcblocktop = false, --Misnomer, affects whether thrown NPCs bounce off the NPC.
	playerblock = false,
	playerblocktop = false, --Also handles other NPCs walking atop this NPC.

	nohurt = false,
	nogravity = false,
	noblockcollision = false,
	nofireball = false,
	noiceball = false,
	noyoshi = false,
	nowaterphysics = false,
	
	jumphurt = true,
	spinjumpsafe = true,
	harmlessgrab = false,
	harmlessthrown = false,


	transformid = transformID,
}

npcManager.setNpcSettings(spinyEggSettings)
npcManager.registerHarmTypes(npcID,
	{
		HARM_TYPE_FROMBELOW,
		HARM_TYPE_NPC,
		HARM_TYPE_PROJECTILE_USED,
		HARM_TYPE_LAVA,
		HARM_TYPE_HELD,
		HARM_TYPE_TAIL,
		HARM_TYPE_OFFSCREEN,
		HARM_TYPE_SWORD,
	},
	{
		[HARM_TYPE_JUMP]            = deathEffectID,
		[HARM_TYPE_FROMBELOW]       = deathEffectID,
		[HARM_TYPE_NPC]             = deathEffectID,
		[HARM_TYPE_PROJECTILE_USED] = deathEffectID,
		[HARM_TYPE_HELD]            = deathEffectID,
		[HARM_TYPE_TAIL]            = deathEffectID,
		[HARM_TYPE_LAVA]            = {id=13, xoffset=0.5, xoffsetBack = 0, yoffset=1, yoffsetBack = 1.5},
	}
)

function spinyEgg.onInitAPI()
	npcManager.registerEvent(npcID, spinyEgg, "onTickNPC")
end

function spinyEgg.onTickNPC(v)
	if v.despawnTimer <= 0
	or Defines.levelFreeze
	or v:mem(0x12C, FIELD_WORD) > 0    --Grabbed
	or v:mem(0x136, FIELD_BOOL)        --Thrown
	or v:mem(0x138, FIELD_WORD) > 0    --Contained within
	then return end
	
	if v.collidesBlockBottom then
		local newID = v.ai1

		if newID == 0 then
			newID = NPC.config[v.id].transformid
		end

		v:transform(newID)

		npcutils.faceNearestPlayer(v)
	end
end

return spinyEgg