local serializer = require("ext/serializer")


local filename = "save-global.dat"


local function load()
    local f = io.open(Misc.episodePath().. filename,"r")
    if f == nil then
        return {}
    end


    local content = f:read("*a")

    f:close()

    if content == "" then
        return {}
    end


    local s,e = pcall(serializer.deserialize, content, filename)
    if s then
        return e
    else
        pcall(Misc.dialog,"Error loading episode-wide save data. Your save file may be corrupted. Please try reloading the game.\n(NOTE: This is a message produced by the episode, not the engine.)\n\n=============\n".. e)
        return {}
    end
end

local function flush()
    local f = io.open(Misc.episodePath().. filename,"w")

    if f == nil then
        return
    end

    local data = serializer.serialize(GameData.tempGlobalData)

    f:write(data)
    f:flush()
    f:close()
end


-- Events/library
do
    local globalDataLib = {}

    function globalDataLib.onExit()
        flush()
    end

    registerEvent(globalDataLib,"onExit","onExit",false)
end

-- Metatable stuff
local metatable = {}

do
    GameData.tempGlobalData = GameData.tempGlobalData or load()
    local tempData = GameData.tempGlobalData


    function metatable.__index(tbl,key)
        if key == "flush" then
            return flush
        else
            return tempData[key]
        end
    end

    function metatable.__newindex(tbl,key,value)
        if key == "flush" then
            error("Cannot overwrite '".. key.. "' function",2)
        else
            tempData[key] = value
        end
    end

    function metatable.__ipairs(tbl)
        return ipairs(tempData)
    end

    function metatable.__pairs(tbl)
        return next,tempData,nil
    end
end


local GlobalData = setmetatable({},metatable)

return GlobalData