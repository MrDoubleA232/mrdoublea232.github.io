if isOverworld then
    return {}
end

GameData.levelData = GameData.levelData or {}
local allLevelsData = GameData.levelData

allLevelsData[Level.filename()] = allLevelsData[Level.filename()] or {}
local currentLevelData = allLevelsData[Level.filename()]



local function clearCurrent()
    allLevelsData[Level.filename()] = {}
    currentLevelData = allLevelsData[Level.filename()]
end

local function clearRest()
    for k,v in pairs(allLevelsData) do
        if k ~= Level.filename() then
            allLevelsData[k] = nil
        end
    end
end


-- Events
do
    local levelDataLib = {}

    function levelDataLib.onExitLevel(winType)
        if winType > 0 then
            clearCurrent()
        end
    end

    function levelDataLib.onCheckpoint()
        clearRest()
    end

    registerEvent(levelDataLib,"onExitLevel","onExitLevel",false)
    registerEvent(levelDataLib,"onCheckpoint","onCheckpoint",false)
end


-- Metatable stuff
local metatable = {}

do
    function metatable.__index(tbl,key)
        if key == "clearCurrent" then
            return clearCurrent
        elseif key == "clearRest" then
            return clearRest
        else
            return currentLevelData[key]
        end
    end

    function metatable.__newindex(tbl,key,value)
        if key == "clearCurrent" or key == "clearRest" then
            error("Cannot overwrite '".. key.. "' function",2)
        else
            currentLevelData[key] = value
        end
    end

    function metatable.__ipairs(tbl)
        return ipairs(currentLevelData)
    end

    function metatable.__pairs(tbl)
        return next,currentLevelData,nil
    end
end


local LevelData = setmetatable({},metatable)

return LevelData