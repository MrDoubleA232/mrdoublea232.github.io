-- When you freeze a player inside of an ice block, there still needs to be an NPC inside of the ice block.
-- This NPC is purely used for that purpose.

local onlinePlayNPC = require("scripts/onlinePlay_npc")

local npcManager = require("npcManager")

local nothingNPC = {}
local npcID = NPC_ID

local nothingNPCSettings = {
	id = npcID,

	gfxwidth = 32,
	gfxheight = 32,

	width = 32,
	height = 32,

	gfxoffsetx = 0,
	gfxoffsety = 0,

	frames = 1,
	framestyle = 0,
	framespeed = 8,

	luahandlesspeed = false,
	nowaterphysics = false,
	cliffturn = false,
	staticdirection = false,

	npcblock = false,
	npcblocktop = false,
	playerblock = false,
	playerblocktop = false,

	nohurt = true,
	nogravity = true,
	noblockcollision = true,
	notcointransformable = true,
	nofireball = true,
	noiceball = true,
	noyoshi = true,

	jumphurt = true,
	spinjumpsafe = true,
	harmlessgrab = true,
	harmlessthrown = true,
	nowalldeath = false,

	linkshieldable = false,
	noshieldfireeffect = false,

	ignorethrownnpcs = true,
}

npcManager.setNpcSettings(nothingNPCSettings)

function nothingNPC.onInitAPI()
	npcManager.registerEvent(npcID, nothingNPC, "onTickNPC")
end

function nothingNPC.onTickNPC(v)
	onlinePlayNPC.forceKillNPC(v,HARM_TYPE_VANISH)
end

return nothingNPC