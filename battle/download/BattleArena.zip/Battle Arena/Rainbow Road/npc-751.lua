local thwomps = {}

local npcManager = require("npcManager")
local thwompAI = require("rainbowThwomps")

local npcID = NPC_ID

local settings = {
	id = npcID, staticdirection = true, harmTypes = {}
}

thwompAI.registerThwomp(settings)

return thwomps