-- Prevent the rolling chain chomps (reskinned grrrols) from dying to anything other than a starman
local function isTouchingStarmanPlayer(v)
    for _,p in ipairs(Player.getIntersecting(v.x,v.y,v.x + v.width,v.y + v.height)) do
        if p.hasStarman then
            return true
        end
    end

    return false
end

function onNPCHarm(eventObj, v, reason, culprit)
    if v.id == 532 and reason == HARM_TYPE_NPC and not isTouchingStarmanPlayer(v) then
        eventObj.cancelled = true
    end
end