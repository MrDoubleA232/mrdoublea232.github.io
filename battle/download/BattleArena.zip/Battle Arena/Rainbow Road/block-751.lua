local blockManager = require("blockManager")

local blockShockwaves = require("blockShockwaves")

local shockwaveableBlock = {}
local blockID = BLOCK_ID

local shockwaveableBlockSettings = {
	id = blockID,
	
	semisolid = true,
}

blockManager.setBlockSettings(shockwaveableBlockSettings)

blockShockwaves.registerBlock(blockID)

return shockwaveableBlock