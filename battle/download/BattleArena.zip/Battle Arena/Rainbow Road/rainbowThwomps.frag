#version 120
uniform sampler2D iChannel0;

uniform float frames;
uniform float time;

vec3 hsv2rgb(vec3 c)
{
    vec4 K = vec4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
    vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www);
    return c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y);
}

void main()
{
	vec2 xy = gl_TexCoord[0].xy;
	vec4 c = texture2D(iChannel0, xy);

	//c = vec4(hsv2rgb(vec3(0, 1.0, 1.0)),1.0)*c.a;
	c.rgb *= hsv2rgb(vec3(mod(xy.y*frames,1.0)*0.25 + time/192.0 + xy.x*0.05, 0.75, 1.0))*1.5;
	c.r = min(1.0, c.r);
	c.g = min(1.0, c.g);
	c.b = min(1.0, c.b);
	
	gl_FragColor = c * gl_Color;
}