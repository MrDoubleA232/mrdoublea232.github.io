local battleMap = require("scripts/battleMap")

battleMap.blacklistedTerrainLayerMap["[Classic] lava"] = true