local battleGeneral = require("scripts/battleGeneral")
local blockRespawning = require("scripts/blockRespawning")

--require("game/repl").activeInEpisode = true

require("scripts/playerphysicspatch")

function onStart()
    if not GameData.hasSetWindowStuff then
        if Misc.setWindowTitle ~= nil then
            Misc.setWindowTitle("Battle Arena (".. battleGeneral.versionNames[battleGeneral.gameVersion].. ")")
        end
        if Misc.setWindowIcon ~= nil then
            Misc.setWindowIcon(Graphics.loadImageResolved("resources/windowIcon.png"))
        end

        GameData.hasSetWindowStuff = true
    end
end

function onTick()
    --player.sectionObj.musicID = 0
end