function onStart()

local currentDate = os.date("*t")
local decemberLayer = Layer.get("december")

   if currentDate.month == 12 or currentDate.month == 1 then
   decemberLayer:show(true)
   --triggerEvent("december")
   Section(0).music = "Snowy Scuffle/Sherbet Land (alt version).ogg"
   end 
end