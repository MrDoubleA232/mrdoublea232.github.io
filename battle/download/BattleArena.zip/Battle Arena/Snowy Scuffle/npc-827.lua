local smwfuzzy = {}

local npcManager = require("npcManager")

local onlinePlayNPC = require("scripts/onlinePlay_npc")

local npcID = NPC_ID

npcManager.registerDefines(npcID, {NPC.HITTABLE})

-- settings
local config = {
	id = npcID, 
	width = 20, 
    height = 20,
    gfxwidth = 24,
    gfxheight = 24,
    frames = 1,
    nogravity = false,
    spinjumpsafe = false,
    noblockcollision = false,
	jumphurt = true,
    framestyle = 0,
}
npcManager.setNpcSettings(config)

--Register events
function smwfuzzy.onInitAPI()
	npcManager.registerEvent(npcID, smwfuzzy, "onTickNPC")
end

function smwfuzzy.onTickNPC(v)
	if v.collidesBlockBottom or v.collidesBlockLeft or v.collidesBlockRight or v.collidedBlockUp then
		onlinePlayNPC.forceKillNPC(v,HARM_TYPE_NPC)
		SFX.play(2)
		Effect.spawn(230, v.x, v.y - 6, player.section, true)
	end
end

return smwfuzzy