#version 120
uniform sampler2D iChannel0;

uniform vec3 colors[MAX_COLORS];
uniform float colorCount;

uniform float baseX;
uniform float baseY;
uniform float time;

uniform vec2 imageSize;

#define MAX_COLORS 1
#define THICKNESS 0


float findOutlineOpacity(float outlineOpacity,vec2 direction)
{
	float newOutlineOpacity = outlineOpacity;

	for (float i = 1.0; i <= THICKNESS; i++)
	{
		vec2 xy = gl_TexCoord[0].xy + i*direction/imageSize;
		vec4 c = texture2D(iChannel0, xy);

		newOutlineOpacity = max(newOutlineOpacity, c.a);
	}

	return newOutlineOpacity;
}


void main()
{
	float outlineOpacity = 0.0;

	outlineOpacity = findOutlineOpacity(outlineOpacity,vec2(0.0,-1.0));
	outlineOpacity = findOutlineOpacity(outlineOpacity,vec2(0.0,1.0));
	outlineOpacity = findOutlineOpacity(outlineOpacity,vec2(-1.0,0.0));
	outlineOpacity = findOutlineOpacity(outlineOpacity,vec2(1.0,0.0));

	outlineOpacity *= 1.0 - texture2D(iChannel0, gl_TexCoord[0].xy).a;

    float colorIndex = mod((gl_FragCoord.y - baseY)/96.0 + (gl_FragCoord.x - baseX)/256.0 - time/128.0,1.0)*colorCount;
    int indexA = int(mod(floor(colorIndex),colorCount));
    int indexB = int(mod(ceil(colorIndex),colorCount));

    vec3 c = mix(colors[indexA],colors[indexB],min(1.0,2.0*mod(colorIndex,1.0)));

	gl_FragColor = vec4(outlineOpacity)*vec4(c,1.0)*gl_Color*0.75;
    // gl_FragColor = vec4(c,1.0)*gl_Color;
}