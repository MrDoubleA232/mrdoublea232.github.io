#version 120
uniform sampler2D iChannel0;

uniform vec4 outlineColor;
uniform vec2 imageSize;

#include "shaders/logic.glsl"

float getOpacity(vec2 xy)
{
	return texture2D(iChannel0,xy).a*ge(xy.x,0.0)*le(xy.x,1.0)*ge(xy.y,0.0)*le(xy.y,1.0);
}

void main()
{
	vec2 xy = gl_TexCoord[0].xy;
	vec4 c = texture2D(iChannel0, xy)*ge(xy.x,0.0)*le(xy.x,1.0)*ge(xy.y,0.0)*le(xy.y,1.0);

	float outlineRight = getOpacity(xy + vec2(2.0/imageSize.x,0.0));
	float outlineLeft = getOpacity(xy + vec2(-2.0/imageSize.x,0.0));
	float outlineDown = getOpacity(xy + vec2(0.0,2.0/imageSize.y));
	float outlineUp = getOpacity(xy + vec2(0.0,-2.0/imageSize.y));
	float outlineOpacity = max(max(max(outlineUp,outlineDown),outlineLeft),outlineRight);

	c = mix(c,outlineColor*vec4(vec3(outlineColor.a),1.0),outlineOpacity*(1.0 - c.a));
	
	gl_FragColor = c * gl_Color;
}