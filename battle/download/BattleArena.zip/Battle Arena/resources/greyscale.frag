#version 120
uniform sampler2D iChannel0;

uniform float fade = 1.0;

void main()
{
	vec4 c = texture2D(iChannel0, gl_TexCoord[0].xy);
	float luminance = (0.2126*c.r + 0.7152*c.g + 0.0722*c.b);

	c.rgb = mix(c.rgb,vec3(luminance*c.a),fade);
	
	gl_FragColor = c*gl_Color;
}