#version 120
uniform sampler2D iChannel0;

uniform vec4 backColor;
uniform vec4 solidBlockColor;
uniform vec4 sizeableColor;

void main()
{
	vec4 b = texture2D(iChannel0, gl_TexCoord[0].xy);

	vec4 c = mix(mix(backColor, sizeableColor, b.g), solidBlockColor, b.r);

	c.rgb *= c.a;
	
	gl_FragColor = c * gl_Color;
}