#version 120
uniform sampler2D iChannel0;

uniform vec4 color;
uniform float extremity;

void main()
{
	vec4 c = texture2D(iChannel0, gl_TexCoord[0].xy);

	c = mix(c,vec4(color.rgb,1.0) * color.a * c.a,extremity);
	
	gl_FragColor = c*gl_Color;
}