#version 120
uniform sampler2D iChannel0;

uniform vec3 colors[MAX_COLORS];
uniform float colorCount;

uniform float baseX;
uniform float baseY;
uniform float time;

uniform vec2 imageSize;

#define MAX_COLORS 1


void main()
{
    float colorIndex = mod((gl_FragCoord.y - baseY)/96.0 + (gl_FragCoord.x - baseX)/256.0 - time/192.0,1.0)*colorCount;
    int indexA = int(mod(floor(colorIndex),colorCount));
    int indexB = int(mod(ceil(colorIndex),colorCount));

    vec3 tintColor = mix(colors[indexA],colors[indexB],min(1.0,2.0*mod(colorIndex,1.0)));

	vec4 c = texture2D(iChannel0, gl_TexCoord[0].xy);

	gl_FragColor = c*vec4(tintColor,1.0)*gl_Color;
}