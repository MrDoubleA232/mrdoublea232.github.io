#version 120
uniform sampler2D iChannel0;

uniform vec2 imageSize;

#define THICKNESS 0


float findOutlineOpacity(float outlineOpacity,vec2 direction)
{
	float newOutlineOpacity = outlineOpacity;

	for (float i = 1.0; i <= THICKNESS; i++)
	{
		vec2 xy = gl_TexCoord[0].xy + i*direction/imageSize;
		vec4 c = texture2D(iChannel0, xy);

		newOutlineOpacity = max(newOutlineOpacity, c.a);
	}

	return newOutlineOpacity;
}


void main()
{
	float outlineOpacity = 0.0;

	outlineOpacity = findOutlineOpacity(outlineOpacity,vec2(0.0,-1.0));
	outlineOpacity = findOutlineOpacity(outlineOpacity,vec2(0.0,1.0));
	outlineOpacity = findOutlineOpacity(outlineOpacity,vec2(-1.0,0.0));
	outlineOpacity = findOutlineOpacity(outlineOpacity,vec2(1.0,0.0));

	outlineOpacity *= 1.0 - texture2D(iChannel0, gl_TexCoord[0].xy).a;
	
	gl_FragColor = vec4(outlineOpacity)*gl_Color;
}