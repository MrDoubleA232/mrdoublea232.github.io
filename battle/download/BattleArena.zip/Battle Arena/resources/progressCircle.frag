#version 120
uniform sampler2D iChannel0;

uniform sampler2D fillImage;

uniform vec4 outlineColor;
uniform vec4 backColor;
uniform vec4 fillColor;

uniform float progress;

#include "shaders/logic.glsl"


vec4 alphaMultiply(vec4 c)
{
	return vec4(c.rgb*c.a,c.a);
}

void main()
{
	vec4 b = texture2D(iChannel0,gl_TexCoord[0].xy);
	vec4 f = texture2D(fillImage,gl_TexCoord[0].xy);

	float fillAppear = lt(f.r,progress)*f.a;

	vec4 c = mix(alphaMultiply(outlineColor),alphaMultiply(backColor),b.r)*b.a;

	c = mix(c,alphaMultiply(fillColor),fillAppear);
	
	gl_FragColor = c*gl_Color;
}