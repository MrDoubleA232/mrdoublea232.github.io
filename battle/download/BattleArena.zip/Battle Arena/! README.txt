--- CREDITS ---

Levels credits can be found in their respective folders.

playerphysicspatch by Emral
SMB3 World Name Font: by rixithechao, Quine, Squish Rex and Murphmario
SMAS-styled SMA music: by LadiesMan217, Vitor Vilela and musicalman
Expanded font: by Euly



Hub music:
- Numberless Moments: by Jazzman287
- Abstract Map - VLDC9: https://www.smwcentral.net/?p=section&a=details&id=14805
- Alterna Site 6 - Splatoon 3
- Waiting to Join - Mario Kart Wii
- Dreamy Wakeport Repose - Mario & Luigi Dream Team

Tested with:
- Supermario1313
- Starshi
- Novarender
- KateBulka
- Euly

--- ONLINE INSTRUCTIONS ---

Instructions for setting up the online component can be found at: https://mrdoublea232.github.io/battle