local battleTimer = require("scripts/battleTimer")
local lineguide = require("lineguide")
local alwaysSpawnedMap = table.map{204,580,428,429}

lineguide.registerNpcs(582)

function onStart()
    battleTimer.set(10*60)
end


function onTick()
    for _,v in NPC.iterateByFilterMap(alwaysSpawnedMap) do
        v.despawnTimer = math.max(v.despawnTimer, 100)
        v:mem(0x124,FIELD_BOOL,true)
    end
end