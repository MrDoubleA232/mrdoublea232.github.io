local battlePlayer = require("scripts/battlePlayer")
local npcManager = require("npcManager")

local startPoint = {}
local npcID = NPC_ID

local startPointSettings = {
	id = npcID,
	
	gfxwidth = 32,
	gfxheight = 64,

	gfxoffsetx = 0,
	gfxoffsety = 0,
	
	width = 32,
	height = 64,
	
	frames = 1,
	framestyle = 0,
	framespeed = 8,
	
	speed = 1,
	
	npcblock = false,
	npcblocktop = false, --Misnomer, affects whether thrown NPCs bounce off the NPC.
	playerblock = false,
	playerblocktop = false, --Also handles other NPCs walking atop this NPC.

	nohurt = true,
	nogravity = true,
	noblockcollision = true,
	nofireball = true,
	noiceball = true,
	noyoshi = true,
	nowaterphysics = true,
	
	jumphurt = true,
	spinjumpsafe = false,
	harmlessgrab = true,
	harmlessthrown = true,

	ignorethrownnpcs = true,
	notcointransformable = true,
}

npcManager.setNpcSettings(startPointSettings)
npcManager.registerHarmTypes(npcID,{},{})

battlePlayer.startPointNPCID = npcID

return startPoint