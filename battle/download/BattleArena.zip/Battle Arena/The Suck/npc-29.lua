local onlinePlayNPC = require("scripts/onlinePlay_npc")

local battleGeneral = require("scripts/battleGeneral")

local npcManager = require("npcManager")
local npcutils = require("npcs/npcutils")

local hammerBrx = {}
local npcID = NPC_ID


local heldDuration = 12*64


function hammerBrx.onInitAPI()
	npcManager.registerEvent(npcID, hammerBrx, "onTickNPC")
	npcManager.registerEvent(npcID, hammerBrx, "onCameraDrawNPC")
end


function hammerBrx.onTickNPC(v)
	local data = v.data

	if v.despawnTimer <= 0 then
		data.heldLifetime = nil
		return
	end

	if v.heldIndex <= 0 then
		return
	end

	if data.heldLifetime == nil then
		data.heldLifetime = heldDuration
	end

	data.heldLifetime = math.max(0,data.heldLifetime - 1)

	if data.heldLifetime <= 0 and onlinePlayNPC.ownsNPC(v) then
		-- Poof out of existance
		v:kill(HARM_TYPE_NPC)
	end
end


function hammerBrx.onCameraDrawNPC(v,camIdx)
	if v.despawnTimer <= 0 or v.heldIndex <= 0 then
		return
	end

	local data = v.data

	if data.heldLifetime == nil then
		return
	end

	battleGeneral.drawProgressCircle{
		progress = data.heldLifetime/heldDuration,
		
		priority = -0.1,sceneCoords = true,

		x = v.x + v.width*0.5,
		y = v.y - 40,
	}
end


onlinePlayNPC.onlineHandlingConfig[npcID] = {
	getExtraData = function(v)
		local data = v.data

		return {
			heldLifetime = data.heldLifetime,
		}
	end,
	setExtraData = function(v,receivedData)
		local data = v.data

		data.heldLifetime = receivedData.heldLifetime or data.heldLifetime
	end,
}


return hammerBrx