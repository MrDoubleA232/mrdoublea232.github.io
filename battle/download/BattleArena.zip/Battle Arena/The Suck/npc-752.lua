local npcManager = require("npcManager")
local npcutils = require("npcs/npcutils")

local ai = require("bigShyGuy_ai")


local bigShyGuy = {}
local npcID = NPC_ID

local deathEffectID = 751

local bigShyGuySettings = table.join({
	id = npcID,

	cliffturn = true,
},ai.sharedSettings)

npcManager.setNpcSettings(bigShyGuySettings)
npcManager.registerHarmTypes(npcID,
	{
		HARM_TYPE_JUMP,
		HARM_TYPE_FROMBELOW,
		HARM_TYPE_NPC,
		--HARM_TYPE_PROJECTILE_USED,
		HARM_TYPE_LAVA,
		--HARM_TYPE_HELD,
		HARM_TYPE_TAIL,
		HARM_TYPE_SPINJUMP,
		HARM_TYPE_OFFSCREEN,
		HARM_TYPE_SWORD
	}, 
	{
		[HARM_TYPE_JUMP] = deathEffectID,
		[HARM_TYPE_FROMBELOW] = deathEffectID,
		[HARM_TYPE_NPC] = deathEffectID,
		[HARM_TYPE_PROJECTILE_USED] = deathEffectID,
		[HARM_TYPE_LAVA] = {id=13, xoffset=0.5, xoffsetBack = 0, yoffset=1, yoffsetBack = 1.5},
		[HARM_TYPE_HELD] = deathEffectID,
		[HARM_TYPE_TAIL] = deathEffectID,
		[HARM_TYPE_SPINJUMP] = 10,
	}
)


ai.register(npcID)


return bigShyGuy