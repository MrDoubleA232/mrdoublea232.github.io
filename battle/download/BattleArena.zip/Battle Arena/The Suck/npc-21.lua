local npcManager = require("npcManager")
local npcutils = require("npcs/npcutils")

local billBlaster = {}
local npcID = NPC_ID


function billBlaster.onInitAPI()
	npcManager.registerEvent(npcID, billBlaster, "onTickNPC")
end


function billBlaster.onTickNPC(v)
	if v.despawnTimer <= 0 or Defines.levelFreeze then
		return
	end

	-- Allow it to despawn sooner
	if v:mem(0x126,FIELD_BOOL) and v:mem(0x128,FIELD_BOOL) then
		v.despawnTimer = math.min(v.despawnTimer,10)
	end
end


return billBlaster