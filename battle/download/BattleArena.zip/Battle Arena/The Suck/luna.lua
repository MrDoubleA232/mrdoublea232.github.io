function onNPCTransform(v,oldID,reason)
    -- Force any Billy Guns pulled from SMB2 grass to have a set number of shots
    if v.id == 22 and oldID == 91 then
        v.data._settings.shots = 30

        v.data.oldTimer = nil
		v.data.vanishTimer = nil
		v.data.shotsLeft = nil
    end
end