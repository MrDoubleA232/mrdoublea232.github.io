#define SURFACE default_surf

uniform sampler2D iChannel0;

#define UNLIT 1.0
#define TONEMAP 0.0

#define TILE_SIZE 0.0

#include "shaders/logic.glsl"

void default_surf(in fragdata data, inout surfdata o)
{
	/*float onUpper = le(data.uv.y,data.uv.x);

	o.albedo = vec4(onUpper,onUpper,onUpper,1.0);*/

	float isFront = le(data.worldnormal.z,-1.0);
	vec2 uv = data.uv;

	#if TILE_SIZE > 0.0
		uv.x = mix(uv.x,mod(data.worldposition.x/TILE_SIZE,1.0),eq(data.worldnormal.x,0.0));
	#endif

	o.albedo = texture2D(iChannel0,uv)*data.color;

	//o.albedo.rgb = vec3(data.uv.xy,0.0)*o.albedo.a;

	// Get darker
	float depthDarken = (clamp(0.5 + abs(data.worldposition.z)/128.0,0.0,1.0))*ge(abs(data.worldposition.z + 1.0),16.0)*mix(1.0,0.25,le(data.worldposition.z,0.0));
	float normalDarken = 1.0 - abs(data.worldnormal.z);

	o.albedo.rgb *= mix(0.9,0.6,normalDarken)*mix(0.9,0.4,depthDarken*(1.0 - normalDarken*0.5));
}