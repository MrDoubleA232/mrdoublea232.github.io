#define SURFACE default_surf

uniform sampler2D iChannel0;

uniform float whiten;

#define UNLIT 1
#define TONEMAP 0

void default_surf(in fragdata data, inout surfdata o)
{
	o.albedo = texture2D(iChannel0,data.uv)*data.color;
	o.albedo.rgb = mix(o.albedo.rgb,vec3(1.0),whiten);
}