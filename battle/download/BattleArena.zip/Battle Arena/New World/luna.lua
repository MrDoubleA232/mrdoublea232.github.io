local basic3DWorld = require("basic3DWorld")
local blockRespawning = require("scripts/blockRespawning")

blockRespawning.defaultRespawnTime = 64*120
blockRespawning.maxPlayersRespawnTimeMultiplier = 0.75