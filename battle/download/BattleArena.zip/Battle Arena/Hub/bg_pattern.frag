#version 120
uniform sampler2D iChannel0;

uniform sampler2D patternImage;
uniform vec2 patternSize;
uniform float cameraX;
uniform float cameraY;

uniform vec2 layerSize;

uniform vec4 cloudColor;

uniform float focus;
uniform float time;

void main()
{
	vec2 layerXY = gl_TexCoord[0].xy;

	// Find parallax value
	float depth = mix(250.0,150.0,layerXY.y)/focus;

	depth++;
	depth = 1.0/(depth*depth);

	//float depth = mix(0.25,0.5,layerXY.y);

	// Find XY position
	vec2 xy;

	xy.x = ((layerXY.x - 0.5)/depth*layerSize.x + cameraX)/patternSize.x;
	xy.y = layerXY.y*layerSize.y/patternSize.y;

	xy = mod(xy,1.0);


	vec4 c = texture2D(patternImage, xy);

	float fadeDist = 5.0 + cos(time/32.0)*0.75;
	float fade = min(layerXY.y*fadeDist,1.0);

	c.rgb = mix(vec3(cloudColor),c.rgb,fade);
	
	gl_FragColor = c*gl_Color;
}