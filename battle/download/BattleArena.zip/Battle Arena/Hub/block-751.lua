local perPlayerCostumes = require("scripts/perPlayerCostumes")
local playerManager = require("playerManager")

local blockManager = require("blockManager")

local costumeBlock = {}
local blockID = BLOCK_ID

local costumeBlockSettings = {
	id = blockID,
	
	frames = 1,
	framespeed = 8,

	bumpable = true,
}

blockManager.setBlockSettings(costumeBlockSettings)

function costumeBlock.onInitAPI()
	registerEvent(costumeBlock, "onPostBlockHit")
end

--[[function costumeBlock.onPostBlockHit(v,fromTop,playerObj)
	if v.id ~= blockID or playerObj == nil then
		return
	end

	local costumeList = playerManager.getCostumes(playerObj.character)

	if #costumeList == 0 then
		return
	end

	-- Find the next costume in the list
	local currentCostume = playerObj:getCostume()
	local newCostume

	if currentCostume == nil then
		newCostume = costumeList[1]
	else
		local costumeIndex = table.ifind(costumeList,currentCostume)

		if costumeIndex ~= nil then
			newCostume = costumeList[(costumeIndex + 1)%(#costumeList + 1)]
		end
	end

	-- Set accordingly
	playerObj:setCostume(newCostume)

	Effect.spawn(10,playerObj.x + playerObj.width*0.5 - 16,playerObj.y + playerObj.height*0.5 - 16)
	SFX.play(32)
end]]

return costumeBlock