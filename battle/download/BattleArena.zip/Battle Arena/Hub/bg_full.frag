#version 120
uniform sampler2D iChannel0;

uniform vec2 bufferSize;
uniform float time;

#include "shaders/logic.glsl"

void main()
{
    vec2 xy = gl_FragCoord.xy;

    //xy.x += cos(time*0.01 + xy.y*0.07)*2.0;
    //xy.y += cos(time*0.03 + xy.y*0.08)*2.0;

	vec4 c = texture2D(iChannel0, xy/bufferSize);

    //c.rgb *= 0.85 - 0.05*cos(xy.y/2.0 - time/16.0);
    //c.rgb *= 0.9 - 0.1*le(mod(xy.y,8.0),4.0);
    c.rgb *= 0.95 - 0.05*cos(xy.y/2.0 - time/16.0);

	gl_FragColor = c*gl_Color;
}