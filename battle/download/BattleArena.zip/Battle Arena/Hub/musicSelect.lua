local battleMenu = require("scripts/battleMenu")
local textFiles = require("scripts/textFiles")

local battleGeneral = require("scripts/battleGeneral")

local playerSelect = require("playerSelect")

local musicSelect = {}


musicSelect.songPaths = {
    numberlessMoments = "resources/hubMusic/Numberless Moments - by Jazzman287.spc|0;g=2.4;",
    abstractMap = "resources/hubMusic/Abstract Map - VLDC9.spc|0;g=1.7;",
    alternaSite6 = "resources/hubMusic/Alterna Site 6 (Full Version) - Splatoon 3.ogg",
    regret = "resources/hubMusic/#8 Regret - Splatoon 2 Octo Expansion.ogg",
    waitingRoom = "resources/hubMusic/Waiting To Join - Mario Kart Wii.ogg",
    dreamyWakeport = "resources/hubMusic/Dreamy Wakeport Repose.ogg",
}

musicSelect.songList = {
    "numberlessMoments","abstractMap","alternaSite6","regret","waitingRoom","dreamyWakeport",
}



battleGeneral.saveData.hubMusic = battleGeneral.saveData.hubMusic or "random"


local changeSound = Misc.resolveSoundFile("resources/songChange")

local changeSongRoutine


local function setSong()
    local name = battleGeneral.saveData.hubMusic

    if name == "random" then -- if random, pick one
        if playerSelect.titleMenu.isOpen and battleGeneral.saveData.playSessions == 1 then -- for your first ever start up...
            name = "alternaSite6"
        else
            name = RNG.irandomEntry(musicSelect.songList)
        end
    elseif name == "none" then
        player.sectionObj.music = 0
        return
    end

    player.sectionObj.music = musicSelect.songPaths[name]
end

local function changeSong(newName)
    SFX.play(14)
    
    if battleGeneral.saveData.hubMusic == newName then
        return
    end

    if changeSongRoutine ~= nil and changeSongRoutine.isValid then
        -- If already doing this, stop it
        changeSongRoutine:abort()
    end
    
    -- Set it
    battleGeneral.saveData.hubMusic = newName

    -- Fade out previous song
    while (Audio.MusicVolume() > 0) do
        Audio.MusicVolume(math.max(0,Audio.MusicVolume() - 2))
        Routine.waitFrames(1,true)
    end

    player.sectionObj.music = 0
    Audio.MusicVolume(51)

    if newName ~= "none" and not battleGeneral.musicMuted() then
        -- Let the sound effect play
        SFX.play(changeSound)

        Routine.wait(1.5,true)
    end

    -- Change path
    setSong()
end


-- Menu
local function addSongOption(menu,name)
    local text = textFiles.hubMusic[name]

    local fullText = text.name
    if text.source ~= nil then
        fullText = fullText.. "\n<color lightgrey>".. text.source.. "</color>"
    end

    menu:addOption{text = fullText,runFunction = function(option)
        changeSongRoutine = Routine.run(changeSong,name)
        battleMenu.closeAll()
    end}
end

musicSelect.menu = battleMenu.createMenu{
    format = {
        hasBackground = true,hasBox = true,elementGapY = 12,
        offsetX = 384,offsetY = 96,rotation = 10,scale = 0.75,
    },
    optionFormat = {hasBox = false,textScale = 2},
    textFormat = {hasBox = false,textScale = 2,textMaxWidth = 384,textColor = Color.lightgrey},
}
musicSelect.menu.openFunc = function(menu)
    -- Select a song! text
    menu:addText{text = textFiles.hubMusic.header}

    -- Other options
    addSongOption(menu,"random")
    addSongOption(menu,"none")

    -- Actual songs
    for _,name in ipairs(musicSelect.songList) do
        addSongOption(menu,name)
    end
end


function musicSelect.onStart()
    setSong()
end

function musicSelect.onInitAPI()
    registerEvent(musicSelect,"onStart")
end


return musicSelect