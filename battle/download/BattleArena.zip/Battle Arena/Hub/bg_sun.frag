#version 120
uniform sampler2D iChannel0;

uniform sampler2D cutoutImage;

uniform vec2 layerSize;
uniform float time;

uniform vec4 topColor;
uniform vec4 bottomColor;

#include "shaders/logic.glsl"

void main()
{
	vec2 effectiveSize = layerSize*0.5;
	vec2 layerXY = gl_TexCoord[0].xy;

	layerXY = floor(layerXY*effectiveSize);
	layerXY.x += floor(cos(time*0.03 + layerXY.y)*3.0);

	vec4 c = mix(topColor,bottomColor,clamp(layerXY.y/effectiveSize.y*2.0,0.0,1.0));

	// float inCircle = 1.0 - (length(layerXY - effectiveSize*0.5) - (layerSize.y*0.25 - circleFadeDist))/circleFadeDist;

	c *= lt(length(layerXY - effectiveSize*0.5), layerSize.y*0.25); // Cut out if not in circle
	c *= texture2D(cutoutImage,vec2(0.0,gl_TexCoord[0].y)).r;

	//c = texture2D(cutoutImage,vec2(0.0,gl_TexCoord[0].y));
	
	gl_FragColor = c*gl_Color;
}