local battleGeneral = require("scripts/battleGeneral")

function onStart()
    if battleGeneral.mode == battleGeneral.gameMode.CLASSIC then
        triggerEvent("Water - Still A")
    end
end